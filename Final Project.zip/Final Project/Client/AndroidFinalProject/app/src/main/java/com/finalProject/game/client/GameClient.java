package com.finalProject.game.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.finalProject.game.actions.handlers.InitializeGame;
import com.finalProject.game.events.GameServiceEvents;
import com.finalProject.game.services.GameService;
import com.finalProject.game.structures.MakeMoveData;
import com.finalProject.game.structures.PlayGameData;
import com.finalProject.objects.User;

import org.json.JSONException;

import okhttp3.Request;

public class GameClient {
    private static GameClient currentInstance = null;

    private User user;
    private GameService gameService;
    private PlayGameData playGameData = null;
    private boolean isConnected = false;

    public GameClient(User user, GameServiceEvents gameServiceEvents) {
        super();
        this.user = user;
        gameService = new GameService(gameServiceEvents, this::createRequest);
        registerActionsHandlers();
        currentInstance = this;
    }

    private void registerActionsHandlers() {
        gameService.addActionHandler("initializeGame", InitializeGame::handle);
    }

    public Request createRequest() {
        String websocketURL = "ws://10.0.2.2:3000";

        return new Request.Builder()
                .url(websocketURL)
                .build();
    }

    public void play(PlayGameData playGameData) throws JSONException, JsonProcessingException {
       this.gameService.send("/play", playGameData.toJson());
    }

    public void makeMove(MakeMoveData makeMoveData) throws JSONException, JsonProcessingException {
        this.gameService.send("/make-move", makeMoveData.toJson());
    }

    public static GameClient getCurrentInstance() {
        return currentInstance;
    }

    public static void setCurrentInstance(GameClient instance) {
        GameClient.currentInstance = currentInstance;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public GameService getGameService() {
        return gameService;
    }

    public void setGameService(GameService gameService) {
        this.gameService = gameService;
    }

    public void disconnect() {
     this.gameService.disconnect();
     currentInstance = null;
    }

    public PlayGameData getPlayGameData() {
        return playGameData;
    }

    public void setPlayGameData(PlayGameData playGameData) {
        this.playGameData = playGameData;
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void setConnected(boolean connected) {
        isConnected = connected;
    }

}
