package com.finalProject.rest.authorization;

import com.finalProject.rest.server.ServerResponse;

public class UserAuthorization {
    private ServerResponse serverResponse;
    private String accessToken;
    private String refreshToken;

    public UserAuthorization(ServerResponse serverResponse, String accessToken, String refreshToken) {
        this.serverResponse = serverResponse;
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
    }

    public ServerResponse getServerResponse() {
        return serverResponse;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    @Override
    public String toString() {
        return "UserAuthorization{" +
                "serverResponse='" + serverResponse + '\'' +
                "accessToken='" + accessToken + '\'' +
                ", refreshToken='" + refreshToken + '\'' +
                '}';
    }
}
