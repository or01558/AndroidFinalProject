package com.finalProject.rest;

import com.finalProject.rest.client.RestClient;

public class RestApi {
    RestClient restClient;

    public RestApi() {
        this.restClient = new RestClient("f88da1cc-6b3c-405e-99a4-fefb01553b7f", "e906a5f7-c30a-403e-a02b-7d772daadf60");
        restClient.setHost("http://10.0.2.2");
    }

    public RestClient getRestClient() {
        return restClient;
    }
}
