package com.finalProject.game.services;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.finalProject.game.events.GameServiceEvents;
import com.finalProject.game.events.MultiplayerModeEvents;
import com.finalProject.rest.authorization.UserAuthorization;
import com.finalProject.rest.server.ServerResponse;
import com.finalProject.storage.UserManager;
import com.finalProject.utils.App;
import com.finalProject.utils.Services;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class GameService extends WebSocketListener {
    private OkHttpClient httpClient;
    private WebSocket ws;
    private GameServiceEvents gameServiceEvents;
    private HashMap<String, List<Consumer<JSONObject>>> actionHandlers = new HashMap<>();
    private List<MultiplayerModeEvents> multiplayerModeEventsListeners = new ArrayList<>();

    public GameService(GameServiceEvents gameServiceEvents, Supplier<Request> createRequestSupplier) {
        super();
        httpClient = new OkHttpClient();
        ws = httpClient.newWebSocket(createRequestSupplier.get(), this);
        this.gameServiceEvents = gameServiceEvents;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        return super.equals(obj);
    }

    @NonNull
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }

    public void disconnect() {
        this.ws.close(0, "The player wants to exit an game");
    }

    @Override
    public void onClosed(@NonNull WebSocket webSocket, int code, @NonNull String reason) {
        super.onClosed(webSocket, code, reason);
    }

    @Override
    public void onClosing(@NonNull WebSocket webSocket, int code, @NonNull String reason) {
        super.onClosing(webSocket, code, reason);
    }

    @Override
    public void onFailure(@NonNull WebSocket webSocket, @NonNull Throwable t, @Nullable Response response) {
        super.onFailure(webSocket, t, response);
        try {
            throw t;
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMessage(@NonNull WebSocket webSocket, @NonNull String text) {
        super.onMessage(webSocket, text);
        System.out.println("websocket got message " + text);
        try {
            JSONObject responseJson = new JSONObject(text);
            System.out.println(responseJson);
            if (responseJson.has("data")) {
                JSONObject data = responseJson.getJSONObject("data");
                if (data.has("message")) {
                    String message = data.getString("message");
                    if (message.contains("Websocket Client and the game client has been successfuly connected!")) {
                        gameServiceEvents.onGameClientConnection();
                    } else if (message.contains("Game Room has successfully created!")) {
                        multiplayerModeEventsListeners.forEach(MultiplayerModeEvents::onGameRoomCreated);
                    } else if (message.contains("You have been successfully joined to an existing game room!")) {
                        multiplayerModeEventsListeners.forEach(MultiplayerModeEvents::onGameRoomJoined);
                    } else if (message.contains("A player has joined your game room!")) {
                        multiplayerModeEventsListeners.forEach(MultiplayerModeEvents::onPlayerJoined);
                    }else if(message.contains("No Players are online right now")) {
                        multiplayerModeEventsListeners.forEach(MultiplayerModeEvents::onMatchCanceled);

                    }
                } else if (responseJson.has("action")) {
                    JSONObject action = responseJson.getJSONObject("action");
                    String actionName = action.getString("name");

                    if (actionHandlers.containsKey(actionName)) {
                        actionHandlers.get(actionName).forEach(consumer -> {
                            consumer.accept(data);
                        });
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onMessage(@NonNull WebSocket webSocket, @NonNull ByteString bytes) {
        super.onMessage(webSocket, bytes);
    }

    @Override
    public void onOpen(@NonNull WebSocket webSocket, @NonNull Response response) {
        try {
            UserManager userManager = (UserManager) App.get().getManager("user_storage");
            UserAuthorization userAuth = userManager.getAuthorization();
            assert userAuth != null;
            JSONObject gameClientJson = Services.getGameService().getGameClientJson(userAuth).getJSONObject("gameClient");
            JSONObject gameClientInformation = new JSONObject();
            JSONObject gameClient = new JSONObject();

            gameClient.put("id", gameClientJson.get("id"));
            gameClient.put("secret", gameClientJson.get("secret"));
            gameClient.put("playerId", gameClientJson.getJSONObject("userEntity").get("id"));

            gameClientInformation.put("gameClient", gameClient);

            this.ws.send(gameClientInformation.toString());

        } catch (Exception | ServerResponse e) {
            e.printStackTrace();
        }

        super.onOpen(webSocket, response);
    }

    public void send(String path, JSONObject data) throws JSONException {
        JSONObject requestData = new JSONObject();
        requestData.put("path", path);
        requestData.put("data", data);
        System.out.println("requestData " + requestData);
        this.ws.send(requestData.toString());
    }

    public HashMap<String, List<Consumer<JSONObject>>> getActionHandlers() {
        return actionHandlers;
    }

    public void addActionHandler(String name, Consumer<JSONObject> consumer) {
        if (this.actionHandlers.containsKey(name)) this.actionHandlers.get(name).add(consumer);
        this.actionHandlers.put(name, new ArrayList<>(Arrays.asList(consumer)));
    }

    public void removeActionHandler(String name, Consumer<JSONObject> consumer) {
        if (this.actionHandlers.containsKey(name)) this.actionHandlers.get(name).remove(consumer);
    }

    public List<MultiplayerModeEvents> getMultiplayerModeEventsListeners() {
        return multiplayerModeEventsListeners;
    }

    public void addMultiplayerModeEventListener(MultiplayerModeEvents listener) {
        this.multiplayerModeEventsListeners.add(listener);
    }

    public void removeMultiplayerModeEventListener(MultiplayerModeEvents listener) {
        this.multiplayerModeEventsListeners.remove(listener);
    }
}
