package com.finalProject.rest.server;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.Serializable;

public abstract class Server {
    private Client client;

    public Server(Client client) {
        this.client = client;
    }

    public Server() {
        this.client = null;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    abstract public boolean connect();

    abstract public boolean disconnect();

    public abstract ServerResponse send(JSONObject data);



    public abstract static class Client {
        protected Server server;
        protected String id;
        protected String secret;
        protected String host;

        public Client(String id, String secret) {
            this.server = null;
            this.id = id;
            this.secret = secret;
            this.host = null;
        }

        public Client(String id, String secret, String host) {
            this(id, secret);
            this.host = host;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getSecret() {
            return secret;
        }

        public void setSecret(String secret) {
            this.secret = secret;
        }

        public Server getServer() {
            return server;
        }

        public String getHost() {
            return this.host;
        }

        public void setServer(Server server) {
            this.server = server;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public ServerResponse send(JSONObject data) throws IOException, JSONException, ServerResponse {
            if (server == null) throw new ServerResponse("Cannot send request to this specific server", HttpStatus.NOT_FOUND, ResponseTypes.Error, 1000, "Server is null - dosen't exists.", "null", "Server", null);
            return this.server.send(data);
        }

        abstract public JSONObject sendRequest(JSONObject data, String path, String method, String contentType) throws Exception;

        abstract public JSONObject sendRequest(String link, JSONObject data, String method, String contentType) throws IOException, JSONException;

        public boolean connect(Server server) {
            this.setServer(server);
            server.setClient(this);
            return server.connect();
        }

        public boolean disconnect(Server server) {
            this.setServer(server);
            server.setClient(this);
            return server.disconnect();
        }
    }

}