package com.finalProject.utils;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;

import com.finalProject.events.EventsLoader;
import com.finalProject.events.EventsManager;
import com.finalProject.storage.Manager;
import com.finalProject.storage.Storage;
import java.lang.reflect.InvocationTargetException;


public class App {
    private static App currentApp;

    private Context context;
    private AppCompatActivity activity;

    public App(Context context) throws ClassNotFoundException {
        currentApp = this;
        this.context = context;
        this.activity = null;
        Storage.registerManagers();
        EventsManager.registerEvents();
        EventsLoader.registerHandlers();
    }


    public static App getAndInitialize(Context context) throws ClassNotFoundException {
        currentApp = new App(context);
        return currentApp;
    }

    public static App get() {
        return currentApp;
    }

    public Context getContext() {
        return context;
    }

    public AppCompatActivity getActivity() {
        return activity;
    }

    public static void setCurrentApp(App currentApp) {
        App.currentApp = currentApp;
    }

    public void setActivity(AppCompatActivity activity) {
        this.activity = activity;
    }

    public void startActivity(Class<?> activityClass) {
        Intent intent = new Intent(context, activityClass);
        if (activity != null) activity.finish();
        context.startActivity(intent);
    }

    public SharedPreferences getSharedPreferences(String name) {
        return context.getSharedPreferences(name, MODE_PRIVATE);
    }

    public Manager getManager(String name) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException, InstantiationException {
        return Storage.getManager(name, getSharedPreferences(name));
    }
}
