package com.finalProject.objects.game;

public class Item {
    private String name;
    private String id;
    private String title;
    private String description;
    private int price;
    private String shopId;
    private int amount;
    private int usesPerOne;

    public Item() {
        this.name = "";
        this.id = "";
        this.title = "";
        this.description = "";
        this.price = -1;
        this.shopId = "";
        this.amount = 1;
        this.usesPerOne = 1;
    }

    public Item(String name, String id, String title, String description, int price, String shopId, int amount, int usesPerOne) {
        this.name = name;
        this.id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.shopId = shopId;
        this.amount = amount;
        this.usesPerOne = usesPerOne;
    }

    public Item(String name, String id, String title, String description, int price, String shopId) {
        this(name, id, title, description, price, shopId, 1, 1);
    }

    public Item(String name, String id, String title, String description, int price, String shopId, int amount) {
       this(name, id, title, description, price, shopId, amount, 1);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getUsesPerOne() {
        return usesPerOne;
    }

    public void setUsesPerOne(int usesPerOne) {
        this.usesPerOne = usesPerOne;
    }

    @Override
    public String toString() {
        return "Item{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", shopId='" + shopId + '\'' +
                ", amount=" + amount +
                ", usesPerOne=" + usesPerOne +
                '}';
    }
}
