package com.finalProject.storage;

import android.content.SharedPreferences;

import com.finalProject.rest.authorization.UserAuthorization;

public class UserManager extends Manager {

    public UserManager(SharedPreferences sharedPreferences) {
        super(sharedPreferences);
    }

    public void deleteAuthorization() {
        this.delete("u_a_t");
        this.delete("u_r_t");
        this.applyChanges();
    }

    public void saveAuthorization(UserAuthorization userAuth) {
       this.save("u_a_t", userAuth.getAccessToken() );
       this.save("u_r_t", userAuth.getRefreshToken() );
       this.applyChanges();
    }

    public UserAuthorization getAuthorization() {
        boolean authExists = this.has(new String[]{"u_a_t", "u_r_t"});
        if(!authExists)  return null;
        String accessToken = (String) this.get("u_a_t");
        String refreshToken = (String) this.get("u_r_t");
        return new UserAuthorization(null, accessToken, refreshToken);
    }
}
