package com.finalProject.objects.game;

import java.util.List;

public class Shop {
    private String id;
    private List<Item> items;

    public Shop(String id, List<Item> items) {
        this.id = id;
        this.items = items;
    }

    public String getId() {
        return id;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public void addItem(Item item) {
        this.items.add(item);
    }

    public void removeItem(Item item) {
        this.items.remove(item);
    }

    public void addItems(List<Item> items) {
        items.forEach((item) -> this.addItem(item));
    }

    public void removeItems(List<Item> items) {
        items.forEach((item) -> this.removeItem(item));
    }

    @Override
    public String toString() {
        return "Shop{" +
                "id='" + id + '\'' +
                ", items=" + items +
                '}';
    }
}
