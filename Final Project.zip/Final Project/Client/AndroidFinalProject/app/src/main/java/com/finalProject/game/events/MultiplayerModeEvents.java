package com.finalProject.game.events;

public interface MultiplayerModeEvents {
    void onGameRoomCreated();
    void onGameRoomJoined();
    void onPlayerJoined();
    void onMatchCanceled();
}
