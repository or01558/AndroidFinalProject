package com.finalProject.events;

import com.finalProject.annotations.EventHandler;
import com.finalProject.events.handlers.UserChangeHandler;
import com.finalProject.structures.Event;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.function.Consumer;

public class EventsLoader {

    public static void registerHandlers(Class eventClass){
        registerMethods(eventClass.getMethods());
    }

    public static void registerHandlers() {
        registerHandlers(UserChangeHandler.class);
    }

    public static void registerMethods(Method[] methods){
        for(Method method : methods) {
             if(method.isAnnotationPresent(EventHandler.class)) registerMethod(method);
        }
    }

    private static void registerMethod(Method method) {
        Parameter[] params = method.getParameters();
        Class c = params[0].getType();
        EventsManager.getEventBus(c).addMethod(method);
    }

    public static <T extends Event> void addHandler(Class<T> eventClass, Consumer<T> consumer){
        EventsManager.getEventBus(eventClass).addConsumer(consumer);
    }
}
