package com.finalProject;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.finalProject.game.client.GameClient;
import com.finalProject.game.structures.MakeMoveData;
import com.finalProject.game.structures.PlayerMove;
import com.finalProject.objects.User;
import com.finalProject.structures.BaseActivity;
import com.finalProject.utils.App;
import com.finalProject.utils.Session;


import org.json.JSONException;
import org.json.JSONObject;


public class GameActivity extends BaseActivity {
    Button submitButton;
    EditText textInput;


    @Override
    protected void onCreate(Bundle savedInstance) {
        this.loadUser = false;
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_game);
        submitButton = findViewById(R.id.makeMove);
        textInput = findViewById(R.id.guessInput);
        User user = Session.getCurrentUser();
        JSONObject matchJson = Session.getMatchJson();
        GameClient gameClient = GameClient.getCurrentInstance();

        gameClient.getGameService().addActionHandler("makeMove", this::onPlayerMove);
        gameClient.getGameService().addActionHandler("endGame", this::onGameEnded);
        gameClient.getGameService().addActionHandler("playerLeave", this::onPlayerLeave);

        try {
            JSONObject currentPlayerTurn = matchJson.getJSONObject("currentPlayerTurn");
            String currentPlayerTurnId = currentPlayerTurn.getString("id");

            if(!(currentPlayerTurnId.equals(user.getId()))) submitButton.setEnabled(false);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void onPlayerLeave(JSONObject userDataJson) {
        try {
            String playerUsername = userDataJson.getJSONObject("user").getString("username");
            String message = "The player " + playerUsername + "has left the game";
            showDialog("Player Left the game", message, "Leave The Game", "Continue", (dialog, which) -> leaveGame(), (dialog, which) -> dialog.cancel());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void leaveGame() {
        GameClient.getCurrentInstance().disconnect();
        showMainDialog("You Left the game", "What do you want to do right now?");
    }

    public void makeMove(View v) throws JSONException, JsonProcessingException {


        submitButton.setEnabled(false);

        GameClient.getCurrentInstance().makeMove(new MakeMoveData(new PlayerMove(Integer.parseInt(String.valueOf(textInput.getText())))));
    }

    public void onPlayerMove(JSONObject matchJson) {
        runOnUiThread(() -> {
            Session.setMatchJson(matchJson);
                try {
                    JSONObject currentPlayerTurn = matchJson.getJSONObject("currentPlayerTurn");
                    String currentPlayerTurnId = currentPlayerTurn.getString("id");
                    User user = Session.getCurrentUser();
                    if(currentPlayerTurnId.equals(user.getId())) {
                        submitButton.setEnabled(true);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            });
    }

   public void onGameEnded(JSONObject matchJson) {
       runOnUiThread(() -> {
           Session.setMatchJson(matchJson);
           try {
               if(!matchJson.getJSONObject("game").getBoolean("gameEnded")) return;

                   if(matchJson.has("winner")) {
                   showWinnerScreen(matchJson);
               } else {
                   showMaxRoundsLimitScreen(matchJson);
               }
           } catch (JSONException e) {
               e.printStackTrace();
           }
       });
   }

    public void showDialog(String title, String message, String firstButtonText, String secondButtonText, android.content.DialogInterface.OnClickListener firstButtonCallback, android.content.DialogInterface.OnClickListener secondButtonCallback) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)

                .setPositiveButton(firstButtonText, firstButtonCallback)

                .setNegativeButton(secondButtonText, secondButtonCallback)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    public void showMainDialog(String title, String message) {
       showDialog(title, message, "Exit Game", "Back to main menu", (dialog, which) -> {
           App.get().startActivity(UserActivity.class);
       }, (dialog, which) -> {
           GameClient.getCurrentInstance().disconnect();
           android.os.Process.killProcess(android.os.Process.myPid());
           System.exit(1);
       });
    }

   private void showWinnerScreen(JSONObject matchJson) throws JSONException {
       JSONObject winner = matchJson.getJSONObject("winner");
       String winnerId = winner.getString("id");
       User user = Session.getCurrentUser();
       boolean isWinner = winnerId.equals(user.getId());
       String title = isWinner ? "You won!" : "You lost...";
       String message = isWinner ? "You are the winner!" : String.format("The player %s has won game!", winner.getString("username"));

       showMainDialog(title, message);
   }

    private void showMaxRoundsLimitScreen(JSONObject matchJson) throws JSONException {
        String title = "Max Round limit achieved!";
        String message = "There is no winner at this current game...";
        showMainDialog(title, message);
    }
}

