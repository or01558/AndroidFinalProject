package com.finalProject.game.structures;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONException;
import org.json.JSONObject;

public class MakeMoveData {
    PlayerMove move;

    public MakeMoveData(PlayerMove move) {
        this.move = move;
    }

    public PlayerMove getMove() {
        return move;
    }

    public void setMove(PlayerMove move) {
        this.move = move;
    }

    public JSONObject toJson() throws JsonProcessingException, JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("move", new JSONObject(new ObjectMapper().writeValueAsString(move)));

        return jsonObject;
    }

    @Override
    public String toString() {
        return "MakeMoveData{" +
                "move=" + move +
                '}';
    }
}
