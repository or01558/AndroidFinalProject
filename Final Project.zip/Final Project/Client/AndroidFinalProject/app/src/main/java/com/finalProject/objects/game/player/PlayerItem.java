package com.finalProject.objects.game.player;

import com.finalProject.objects.game.Item;

public class PlayerItem {
    private String playerId;
    private int uses;
    private String itemId;
    private Item item;

    public PlayerItem(){
        this.playerId = "";
        this.uses = 0;
        this.itemId = "";
        this.item = null;
    }

    public PlayerItem(String playerId, int uses, String itemId, Item item) {
        this.playerId = playerId;
        this.uses = uses;
        this.itemId = itemId;
        this.item = item;
    }

    public String getPlayerId() {
        return playerId;
    }

    public int getUses() {
        return uses;
    }

    public void setUses(int uses) {
        this.uses = uses;
    }

    public void addUses(int uses) {
        this.uses += uses;
    }

    public void removeUses(int uses) {
        this.uses -= uses;
    }


    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    @Override
    public String toString() {
        return "PlayerItem{" +
                "playerId='" + playerId + '\'' +
                ", uses=" + uses +
                ", itemId='" + itemId + '\'' +
                ", item=" + item +
                '}';
    }
}
