package com.finalProject.events.builtin;

import com.finalProject.structures.Event;
import com.finalProject.objects.User;

public class UserChangeEvent extends Event<UserChangeEvent.UserChangeData, UserChangeEvent> {
    public enum UserConnection {
        CONNECTING(0),
        LOGGING_OUT(1),
        DELETING(-1);

        private final int value;

        UserConnection(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }

        @Override
        public String toString() {
            return "UserConnection{" +
                    "value=" + value +
                    '}';
        }
    }

    public static class UserChangeData {
        private User user;
        private boolean connected;
        private UserConnection connectionState;

        public UserChangeData(User user, boolean connected, UserConnection connectionState) {
            this.user = user;
            this.connected = connected;
            this.connectionState = connectionState;
        }

        public User getUser() {
            return user;
        }

        public boolean isConnected() {
            return connected;
        }

        public UserConnection getConnectionState() {
            return connectionState;
        }
    }

    protected static final String Name = "userChange";
    protected static final String Description = "An user change event.";

    public UserChangeEvent(UserChangeData eventData) {
        super( -1, eventData);
        setState(eventData.connectionState.getValue());
        this.event = this;
        this.eventClass = UserChangeEvent.class;
    }

    public User getUser() {
        return getEventData().getUser();
    }

    public boolean isConnected() {
        return getEventData().isConnected();
    }

    public UserConnection getConnectionState() {
        return getEventData().getConnectionState();
    }

}
