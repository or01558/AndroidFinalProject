package com.finalProject.game.structures;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONException;
import org.json.JSONObject;

public class PlayGameData {
    private Game game;

    public PlayGameData(Game game) {
        this.game = game;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    @Override
    public String toString() {
        return "PlayGameData{" +
                "game=" + game +
                '}';
    }

    public JSONObject toJson() throws JsonProcessingException, JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("game", new JSONObject(new ObjectMapper().writeValueAsString(game)));

        return jsonObject;
    }

}
