package com.finalProject.objects.user;

public class UserProfile {
    private String id;
    private String nickname;
    private String aboutMe;
    private String icon;
    private String image;
    private String banner;

    public UserProfile() {
        this.id = "";
        this.nickname = "";
        this.aboutMe = "";
        this.icon = "";
        this.image = "";
        this.banner = "";
    }

    public UserProfile(String id, String nickname, String aboutMe, String icon, String image, String banner) {
        this.id = id;
        this.nickname = nickname;
        this.aboutMe = aboutMe;
        this.icon = icon;
        this.image = image;
        this.banner = banner;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    @Override
    public String toString() {
        return "UserProfile{" +
                "id='" + id + '\'' +
                ", nickname='" + nickname + '\'' +
                ", aboutMe='" + aboutMe + '\'' +
                ", icon='" + icon + '\'' +
                ", image='" + image + '\'' +
                ", banner='" + banner + '\'' +
                '}';
    }
}
