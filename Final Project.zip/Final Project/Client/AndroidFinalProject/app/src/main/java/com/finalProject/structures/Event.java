package com.finalProject.structures;

import com.finalProject.rest.server.ResponseTypes;

public class Event<EventData, EventClass extends Event<EventData, EventClass>> {
    protected static final String Name = "";
    protected static final String Description = "";
    private int state;
    private boolean success;
    private ResponseTypes responseType;
    private EventData eventData;
    protected EventClass event;
    protected Class<EventClass> eventClass;

    public Event(int state, boolean success, ResponseTypes responseType, EventData eventData, EventClass event, Class<EventClass> eventClass) {
        this.state = state;
        this.success = success;
        this.responseType = responseType;
        this.eventData = eventData;
        this.event  = event;
        this.eventClass = eventClass;
    }

    public Event(int state, EventData eventData){
        this(state, true, ResponseTypes.Success, eventData, null, null);
    }

    public String getName() {
        return Name;
    }

    public String getDescription() {
        return Description;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public ResponseTypes getResponseType() {
        return responseType;
    }

    public void setResponseType(ResponseTypes responseType) {
        this.responseType = responseType;
    }

    public EventData getEventData() {
        return eventData;
    }

    public void setEventData(EventData eventData) {
        this.eventData = eventData;
    }

    public EventClass getEvent() {
        return event;
    }

    public Class<EventClass> getEventClass() {
        return eventClass;
    }
}
