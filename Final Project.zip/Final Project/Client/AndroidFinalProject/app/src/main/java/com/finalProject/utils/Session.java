package com.finalProject.utils;

import com.finalProject.events.EventsManager;
import com.finalProject.events.builtin.UserChangeEvent;
import com.finalProject.events.builtin.UserChangeEvent.*;

import com.finalProject.objects.User;
import com.finalProject.rest.authorization.UserAuthorization;
import com.finalProject.rest.server.ServerResponse;
import com.finalProject.storage.UserManager;

import org.json.JSONObject;


public class Session {
    private static User user = null;
    private static JSONObject matchJson = null;

    public static void setCurrentUser(User user) {
        Session.user = user;
        boolean connected = user != null;
        UserConnection userConnection = user != null ? UserConnection.CONNECTING : UserConnection.LOGGING_OUT;
        UserChangeData userChange = new UserChangeData(user, connected, userConnection);
        EventsManager.fire(new UserChangeEvent(userChange));
    }

    public static void logoutCurrentUser(User user) {
      setCurrentUser(null);
    }

    public static void deleteCurrentUser() {
        Session.user = null;
        UserChangeEvent.UserChangeData userChange = new UserChangeData(null, false, UserConnection.DELETING);
        EventsManager.fire(new UserChangeEvent(userChange));
    }

    public static User getCurrentUser() {
        return user;
    }

    public static void loadUser(UserManager userManager) {
        UserAuthorization userAuth = userManager.getAuthorization();
        if (userAuth != null) {
            new Thread(() -> {
                try {
                    User user = Services.getUserService().getUser(userAuth);
                    setCurrentUser(user);
                } catch (Exception | ServerResponse e) {
                  if(e instanceof ServerResponse)
                      System.out.println(((ServerResponse) e).getReason());
                    e.printStackTrace();
                }
            }).start();
        }
    }

    public static JSONObject getMatchJson() {
        return matchJson;
    }

    public static void setMatchJson(JSONObject matchJson) {
        Session.matchJson = matchJson;
    }
}
