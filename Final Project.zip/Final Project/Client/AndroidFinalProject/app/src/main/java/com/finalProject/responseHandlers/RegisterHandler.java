package com.finalProject.responseHandlers;

import android.graphics.Color;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.finalProject.MainActivity;
import com.finalProject.rest.responses.RegisterResponse;
import com.finalProject.rest.server.ServerResponse;
import com.finalProject.storage.UserManager;
import com.finalProject.structures.ResponseHandler;
import com.finalProject.utils.App;

public class RegisterHandler extends ResponseHandler<RegisterHandler> {

    RegisterResponse registerResponse;
    private TextView textView;

    public static void handle(AppCompatActivity activity, RegisterResponse registerResponse, TextView textView) {
        new RegisterHandler(activity, registerResponse, textView).handle();
    }

    public RegisterHandler(AppCompatActivity activity,  RegisterResponse registerResponse, TextView textView) {
        super(registerResponse.getServerResponse(), activity);
        this.registerResponse = registerResponse;
        this.textView = textView;
    }
    @Override
    public void onFailure(ServerResponse err, AppCompatActivity activity) {
        textView.setTextColor(Color.RED);

        switch (err.getErrorId()) {
            case 401:
                textView.setText("An user with this email already exists! \nMaybe you can try to login into your user...");
                break;

            case 402:
                textView.setText("An user with this username already exists! \nPlease choose another username...");
                break;

            case 403:
                textView.setText("Invalid email address has provided! Please provide a legit email address...");
                break;

            case 404:
                textView.setText("Invalid user address has provided! Your Username length must be bigger then 1...");
                break;

            case 405:
                textView.setText("Invalid password has provided! Your Password length must be 8 or bigger then 8... \nPlease note that your password should also include at least one English letter\n and also at least one number!");
                break;
        }

    }

    @Override
    public void onSuccess(ServerResponse response, AppCompatActivity activity) {
        try {
            textView.setText("You have been successfully created your user! \n Now You can login him via the main screen of the app..");
            App.get().startActivity(MainActivity.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUnhandledResult(AppCompatActivity activity) {
        textView.setTextColor(Color.RED);
        textView.setText("Something went wrong, Please try again later!");
    }


}

