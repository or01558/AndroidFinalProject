package com.finalProject.game.events;

public interface GameServiceEvents {
    void onGameClientConnection();
}
