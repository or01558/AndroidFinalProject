package com.finalProject.structures;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.finalProject.interfaces.AppEvents;
import com.finalProject.R;
import com.finalProject.storage.UserManager;
import com.finalProject.utils.App;
import com.finalProject.utils.Session;

import java.lang.reflect.InvocationTargetException;


public class BaseActivity extends AppCompatActivity implements AppEvents {
    protected boolean loadUser = true;
    protected AppEvents appEvents = this;
    protected boolean useLoadingScreen = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            App app = App.getAndInitialize(this);
            app.setActivity(this);
            if(useLoadingScreen) setContentView(R.layout.activity_main_loading_screen);
            else onUserLoadingFailed();
            if (loadUser) {
                loadUser();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadUser() throws InvocationTargetException, NoSuchMethodException, IllegalAccessException, InstantiationException {
        UserManager userManager = (UserManager) App.get().getManager("user_storage");
        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        Session.loadUser(userManager);
                        if (userManager.getAuthorization() == null)
                            runOnUiThread(appEvents::onUserLoadingFailed);
                    }
                },
                5000
        );
    }

    @Override
    public boolean onUserLoadingFailed() {
        return true;
    }
}
