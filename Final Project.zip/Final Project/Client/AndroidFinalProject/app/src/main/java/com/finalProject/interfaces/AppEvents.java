package com.finalProject.interfaces;

public interface AppEvents {
    boolean onUserLoadingFailed();
}
