package com.finalProject;

import android.os.Bundle;

import com.finalProject.structures.BaseActivity;
import com.finalProject.utils.App;

public class UserDeletionActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_user_deletion);

    }

    public void restoreUser() {

    }

    public void confirm() {
      App.get().startActivity(MainActivity.class);
    }

}
