package com.finalProject.rest.client;

import com.finalProject.rest.server.Server;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class RestClient extends Server.Client {
    OkHttpClient httpClient;
    public boolean passClientsInformation = false;

    public RestClient(String id, String secret) {
        super(id, secret);
        httpClient = new OkHttpClient();
    }

    public JSONObject getRequest(String link, String contentType) throws JSONException, IOException {
        return this.sendRequest(link, null, "GET", contentType);
    }

    public JSONObject getRequest(String link, JSONObject data, String contentType) throws JSONException, IOException {
        return this.sendRequest(link, data, "GET", contentType);
    }

    public JSONObject get(String path, String contentType) throws Exception {
        return this.getRequest(getLinkOf(host, path), contentType);
    }

    public JSONObject get(String path, JSONObject data, String contentType) throws Exception {
        return this.getRequest(getLinkOf(host, path), data, contentType);
    }

    public JSONObject postRequest(String link, JSONObject data, String contentType) throws JSONException, IOException {
        return this.sendRequest(link, data, "POST", contentType);
    }

    public JSONObject post(String path, JSONObject data, String contentType) throws Exception {
        return this.postRequest(getLinkOf(host, path), data, contentType);
    }

    public JSONObject deleteRequest(String link, JSONObject data, String contentType) throws JSONException, IOException {
        return this.sendRequest(link, data, "DELETE", contentType);
    }

    public JSONObject delete(String path, JSONObject data, String contentType) throws Exception {
        return this.deleteRequest(getLinkOf(host, path), data, contentType);
    }

    public JSONObject putRequest(String link, JSONObject data, String contentType) throws JSONException, IOException {
        return this.sendRequest(link, data, "PUT", contentType);
    }

    public JSONObject put(String path, JSONObject data, String contentType) throws Exception {
        return this.putRequest(getLinkOf(host, path), data, contentType);
    }

    @Override
    public JSONObject sendRequest(JSONObject data, String path, String method, String contentType) throws Exception {
        return this.sendRequest(getLinkOf(host, path), data, method, contentType);
    }

    @Override
    public JSONObject sendRequest(String link, JSONObject data, String method, String contentType) throws IOException, JSONException {

        Request.Builder requestBuilder = new Request.Builder();
        requestBuilder.url(new URL(link));

        if (data != null && !(method.equalsIgnoreCase("get")) && !passClientsInformation) {
            data.put("clientId", id);
            data.put("clientSecret", secret);
        }

        String json = data != null ? data.toString() : null;

        requestBuilder.addHeader("Content-Type", contentType);
        requestBuilder.addHeader("Content-Language", "en-US");

        if (method.equalsIgnoreCase("get") && !passClientsInformation) {
            requestBuilder.addHeader("clientId", id);
            requestBuilder.addHeader("clientSecret", secret);
            if (json != null) requestBuilder.addHeader("data", json);
        } else if (json != null) {
            requestBuilder.addHeader("Content-Length", Integer.toString(json.getBytes().length));
            requestBuilder.method(method, RequestBody.create(json.getBytes()));
        }

        Response response = httpClient.newCall(requestBuilder.build()).execute();
        ResponseBody body = response.body();
        String bodyString = body.string();

        return new JSONObject(bodyString);

    }

    private String getLinkOf(String host, String path) throws Exception {
        if (host == null)
            throw new Exception("RestClient Request Error: Cannot send request to this specific host - HOST IS NULL.");
        if (path == null)
            throw new Exception("RestClient Request Error: Cannot send request to this specific host with this specific path - PATH IS NULL.");
        return String.format("%s%s", host, path);
    }
}