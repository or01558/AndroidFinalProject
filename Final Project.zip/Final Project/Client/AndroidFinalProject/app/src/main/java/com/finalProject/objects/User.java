package com.finalProject.objects;

import com.finalProject.annotations.EncryptedVariable;
import com.finalProject.objects.game.Player;
import com.finalProject.objects.user.UserProfile;

public class User {
    private String id;
    @EncryptedVariable
    private String email;
    private String username;
    @EncryptedVariable
    private String password;
    private UserProfile profile;
    private Player player;
    private String userToken;

    public User() {
        this.id = "";
        this.email = "";
        this.username = "";
        this.password = "";
        this.profile = null;
        this.player = null;
        this.userToken = "";
    }

    public User(String id, String email, String username, String password, UserProfile profile, Player player, String userToken) {
        this.id = id;
        this.email = email;
        this.username = username;
        this.password = password;
        this.profile = profile;
        this.player = player;
        this.userToken = userToken;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserProfile getProfile() {
        return profile;
    }

    public void setProfile(UserProfile profile) {
        this.profile = profile;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    public String getUserToken() {
        return userToken;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", email='" + email + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", profile=" + profile +
                ", player=" + player +
                ", userToken=" + userToken +
                '}';
    }
}
