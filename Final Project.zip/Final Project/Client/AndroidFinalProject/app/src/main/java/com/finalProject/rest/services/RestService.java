package com.finalProject.rest.services;

import com.finalProject.rest.RestApi;
import com.finalProject.rest.server.ResponseTypes;
import com.finalProject.rest.server.ServerResponse;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

public class RestService {
    protected RestApi restApi;

    public RestService(RestApi restApi) {
        this.restApi = restApi;
    }

    public void throwErrors(@NotNull JSONObject response) throws JSONException, ServerResponse {
        ServerResponse errorResponse = null;
        if(response.has("error")) {
            System.out.println(response);
            boolean error = response.getBoolean("error");
            if(error) {
                JSONObject errorJSON = new JSONObject(response.getString("errorMessage"));
                errorResponse = ServerResponse.createFromJSON(errorJSON);
            }
        } else {
            String rType = response.getString("type");
            ResponseTypes responseType = ResponseTypes.valueOf(rType);
            if(responseType != ResponseTypes.Success) errorResponse = ServerResponse.createFromJSON(response);
        }
        if(errorResponse != null) throw errorResponse;
    }

    public ServerResponse throwErrorsAndGetResponse(@NotNull JSONObject response) throws JSONException, ServerResponse {
        throwErrors(response);
        return ServerResponse.createFromJSON(response);
    }
}
