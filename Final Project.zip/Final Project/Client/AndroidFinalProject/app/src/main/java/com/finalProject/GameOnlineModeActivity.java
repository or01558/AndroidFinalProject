package com.finalProject;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.finalProject.game.client.GameClient;
import com.finalProject.game.events.MultiplayerModeEvents;
import com.finalProject.structures.BaseActivity;

import org.json.JSONException;


public class GameOnlineModeActivity extends BaseActivity implements MultiplayerModeEvents {
    TextView matchMakingMessage;

    @Override
    protected void onCreate(Bundle savedInstance) {
        try {
            this.loadUser = false;
            super.onCreate(savedInstance);
            setContentView(R.layout.activity_game_online_mode);
            matchMakingMessage = findViewById(R.id.matchMakingMessage);
            GameClient gameClient = GameClient.getCurrentInstance();
            gameClient.getGameService().addMultiplayerModeEventListener(this);
            createMatch(gameClient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createMatch(GameClient gameClient) throws JSONException, JsonProcessingException {
        gameClient.play(gameClient.getPlayGameData());
    }

    @Override
    public void onGameRoomCreated() {
        matchMakingMessage.setText("The game room has been created \n Waiting for players...");
    }

    @Override
    public void onGameRoomJoined() {
        matchMakingMessage.setText("You have been joined to existing game room... \n Waiting for players...");
    }

    @Override
    public void onPlayerJoined() {
        matchMakingMessage.setText("Player has joined waiting for extra players... \n 3 minutes left in order to start the game");

    }

    @Override
    public void onMatchCanceled() {
        matchMakingMessage.setTextColor(Color.RED);
        matchMakingMessage.setText("No Players Are online right now.. \n Please try again later!");

    }

}


