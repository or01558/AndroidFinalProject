package com.finalProject.utils;

import com.finalProject.rest.services.GameService;
import com.finalProject.rest.RestApi;
import com.finalProject.rest.services.UserService;

public class Services {
    private static RestApi restApi = new RestApi();
    private static UserService userService = new UserService(restApi);
    private static GameService gameService = new GameService(restApi);


    public static RestApi getRestApi() {
        return restApi;
    }

    public static UserService getUserService() {
        return userService;
    }

    public static GameService getGameService() {
        return gameService;
    }

}
