package com.finalProject.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Target({ElementType.LOCAL_VARIABLE, ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)

/**
 * **Mark variable as `Encrypted Variable` when needed.**
 * *When Variable is encrypted you cannot access its real value from the front side.*
 * *If you still wants to get its real value and to use it send request to the server to decrypt it.*
 */
public @interface EncryptedVariable {
}
