package com.finalProject.objects.game;

import com.finalProject.objects.game.player.PlayerItem;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Player {
    private String userId;
    private int coins;
    private int diamonds;
    private int level;
    private int xp;
    private List<PlayerItem> items;
    private boolean bot;

    public Player() {
        this.userId = "";
        this.coins = 0;
        this.diamonds = 0;
        this.level = 0;
        this.xp = 0;
        this.items = null;
        this.bot = false;
    }

    public Player(String userId, int coins, int diamonds, int level, int xp, List<PlayerItem> items) {
        this.userId = userId;
        this.coins = coins;
        this.diamonds = diamonds;
        this.level = level;
        this.xp = xp;
        this.items = items;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getCoins() {
        return coins;
    }

    public void setCoins(int coins) {
        this.coins = coins;
    }

    public void addCoins(int coins){
        this.coins += coins;
    }

    public void removeCoins(int coins){
        this.coins -= coins;
    }

    public int getDiamonds() {
        return diamonds;
    }

    public void setDiamonds(int diamonds) {
        this.diamonds = diamonds;
    }

    public void addDiamonds(int diamonds){
        this.diamonds += diamonds;
    }

    public void removeDiamonds(int diamonds){
        this.diamonds -= diamonds;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void addLevels(int levels){
        this.level += levels;
    }

    public void removeLevels(int levels){
        this.level -= levels;
    }

    public int getXp() {
        return xp;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }

    public void addXp(int xp){
        this.xp += xp;
    }

    public void removeXp(int xp){
        this.xp -= xp;
    }

    public List<PlayerItem> getItems() {
        return items;
    }

    public void setItems(List<PlayerItem> items) {
        this.items = items;
    }

    public void setBot(boolean bot) {
        this.bot = bot;
    }

    public boolean isBot() {
        return this.bot;
    }

    @Override
    public String toString() {
        return "Player{" +
                "userId='" + userId + '\'' +
                ", coins=" + coins +
                ", diamonds=" + diamonds +
                ", level=" + level +
                ", xp=" + xp +
                ", items=" + items +
                ", bot=" + bot +
                '}';
    }
}
