package com.finalProject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.finalProject.responseHandlers.LoginHandler;
import com.finalProject.structures.BaseActivity;
import com.finalProject.rest.authorization.UserAuthorization;
import com.finalProject.utils.Services;

public class MainActivity extends BaseActivity {

    private EditText emailField;
    private EditText passwordField;
    private TextView formResultMessage;


    @Override
    protected void onCreate(Bundle savedInstance) {
        useLoadingScreen = false;
        super.onCreate(savedInstance);
        formResultMessage = findViewById(R.id.formResultMessage);
    }

    public void login(View v) {
        String email = emailField.getText().toString();
        String password = passwordField.getText().toString();

        runOnUiThread(new Thread(() -> {
            try {
                UserAuthorization userAuth = Services.getUserService().login(email, password);
                LoginHandler loginHandler = new LoginHandler(this, userAuth, formResultMessage);
                loginHandler.handle();
                if(loginHandler.isSuccess()) {
                    Thread.sleep(5000);
                    setContentView(R.layout.activity_main_loading_screen);
                    loadUser();
                }
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }));

    }


    public void register(View v) {
        String email = emailField.getText().toString();
        String password = passwordField.getText().toString();
        Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
        intent.putExtra("email", email);
        intent.putExtra("password", password);
        startActivity(intent);
    }

    @Override
    public boolean onUserLoadingFailed() {
        super.onUserLoadingFailed();
        setContentView(R.layout.activity_main);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        return true;
    }
}