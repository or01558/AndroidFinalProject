package com.finalProject.rest.services;

import static com.finalProject.utils.Services.getRestApi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finalProject.objects.User;
import com.finalProject.rest.RestApi;
import com.finalProject.rest.authorization.UserAuthorization;
import com.finalProject.rest.client.RestClient;
import com.finalProject.rest.server.ServerResponse;
import org.json.JSONObject;

public class UserService extends RestService {

    public UserService(RestApi restApi) {
        super(restApi);
    }

    public UserAuthorization login(String username, String password) throws Exception {
        try {
            RestClient restClient = restApi.getRestClient();
            JSONObject requestData = new JSONObject();
            requestData.put("username", username);
            requestData.put("password", password);
            JSONObject response = restClient.post("/login", requestData, "application/json");
            throwErrors(response);
            System.out.println(response);
            JSONObject responseValue = new JSONObject(response.getString("value"));
            String accessToken = responseValue.getString("accessToken");
            String refreshToken = responseValue.getString("refreshToken");
            return new UserAuthorization(ServerResponse.createFromJSON(response), accessToken, refreshToken);
        } catch (ServerResponse e) {
            if (e instanceof ServerResponse) return new UserAuthorization(e, null, null);
        }

        return null;
    }

    public ServerResponse register(String email, String username, String password) throws Exception {
        RestApi restApi = getRestApi();
        RestClient restClient = restApi.getRestClient();
        JSONObject registerRequestData = new JSONObject();
        registerRequestData.put("email", email);
        registerRequestData.put("username", username);
        registerRequestData.put("password", password);
        JSONObject response = restClient.post("/register", registerRequestData, "application/json");
        return ServerResponse.createFromJSON(response);
    }

    public User getUser(UserAuthorization userAuth) throws Exception, ServerResponse {
        RestClient restClient = restApi.getRestClient();
        JSONObject requestData = new JSONObject();
        requestData.put("accessToken", userAuth.getAccessToken());
        requestData.put("refreshToken", userAuth.getRefreshToken());
        JSONObject response = restClient.post("/api/users/authorize", requestData, "application/json");
        throwErrors(response);
        JSONObject responseValue = new JSONObject(response.getString("value"));
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(responseValue.getJSONObject("user").toString(), User.class);
    }
}
