package com.finalProject.structures;

import androidx.appcompat.app.AppCompatActivity;
import com.finalProject.rest.server.ServerResponse;


public abstract class ResponseHandler<T> {
    private ServerResponse serverResponse;
    private AppCompatActivity activity;

    public ResponseHandler(ServerResponse serverResponse, AppCompatActivity activity){
        this.serverResponse = serverResponse;
        this.activity = activity;
    }

    public static void handle(ServerResponse response, AppCompatActivity activity) {
    }

    public abstract void onFailure(ServerResponse err, AppCompatActivity activity);
    public abstract void onSuccess(ServerResponse response, AppCompatActivity activity);
    public abstract void onUnhandledResult(AppCompatActivity activity);

    public void handle() {
        switch (serverResponse.getType()) {
            case Error -> {
                onFailure(serverResponse, activity);
                break;
            }

            case Success -> {
                onSuccess(serverResponse, activity);
                break;
            }

            case Unknown -> {
                onUnhandledResult(activity);
                break;
            }
        }
    }

    public ServerResponse getServerResponse() {
        return serverResponse;
    }

    public AppCompatActivity getActivity() {
        return activity;
    }

    public T setServerResponse(ServerResponse serverResponse) {
        this.serverResponse = serverResponse;
        return (T) this;
    }

    public T setActivity(AppCompatActivity activity) {
        this.activity = activity;
        return (T) this;
    }
}
