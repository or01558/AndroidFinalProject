package com.finalProject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.finalProject.responseHandlers.RegisterHandler;
import com.finalProject.rest.responses.RegisterResponse;
import com.finalProject.structures.BaseActivity;
import com.finalProject.rest.server.ServerResponse;
import com.finalProject.utils.Services;

public class RegisterActivity extends BaseActivity {
    private EditText usernameField;
    private String email;
    private String password;
    private TextView formResultMessage;


    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_register);
        Intent intent = getIntent();
        email = intent.getStringExtra("email");
        password = intent.getStringExtra("password");
        usernameField = findViewById(R.id.usernameField);
        formResultMessage = findViewById(R.id.formResultMessage);
    }

    public void createUser(View v) throws Exception {
      String username = usernameField.getText().toString();
      new Thread(() -> {
          try {
              ServerResponse serverResponse = Services.getUserService().register(email, username, password);
              RegisterHandler.handle(this, new RegisterResponse(serverResponse, email, usernameField.getText().toString(), password), formResultMessage);
          } catch (Exception e) {
              e.printStackTrace();
          }
      }).start();
    }
}
