package com.finalProject.rest.services;

import static com.finalProject.utils.Services.getRestApi;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finalProject.objects.User;
import com.finalProject.rest.RestApi;
import com.finalProject.rest.authorization.UserAuthorization;
import com.finalProject.rest.client.RestClient;
import com.finalProject.rest.server.ServerResponse;
import org.json.JSONObject;

public class GameService extends RestService {

    public GameService(RestApi restApi) {
        super(restApi);
    }

    public JSONObject getGameClientJson(UserAuthorization userAuth) throws Exception, ServerResponse {
        RestClient restClient = restApi.getRestClient();
        JSONObject requestData = new JSONObject();
        requestData.put("accessToken", userAuth.getAccessToken());
        requestData.put("refreshToken", userAuth.getRefreshToken());

        JSONObject webClientJson = new JSONObject();
        webClientJson.put("id", restClient.getId());
        webClientJson.put("secret", restClient.getSecret());
        requestData.put("webClient", webClientJson);

        restClient.passClientsInformation = true;
        System.out.println(requestData);
        JSONObject response = restClient.post("/api/game/clients/connect", requestData, "application/json");
        restClient.passClientsInformation = false;

        throwErrors(response);
        JSONObject responseValue = new JSONObject(response.getString("value"));
        return responseValue;
    }
}
