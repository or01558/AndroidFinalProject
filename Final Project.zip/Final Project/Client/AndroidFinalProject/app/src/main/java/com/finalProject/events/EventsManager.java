package com.finalProject.events;

import com.finalProject.events.builtin.UserChangeEvent;
import com.finalProject.structures.EventBus;
import com.finalProject.structures.Listener;
import com.finalProject.structures.Event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EventsManager {

    private static HashMap<Class<? extends Event>, EventBus<? extends Event>> eventBusMap = new HashMap<>();
    private static List<Class<? extends Event>> events = new ArrayList<>();

    public static void registerEvents() {
       registerEvent(UserChangeEvent.class);
    }

    public static <T extends Event> void registerEvent(Class<T> eventClass) {
        events.add(eventClass);
        eventBusMap.put(eventClass, new EventBus<T>());
    }


    public static void registerListener(Listener listener) throws Exception {
       getEventBus(UserChangeEvent.class).addConsumer(listener :: onUserChange);
    }


    public static <T extends Event> EventBus<T> getEventBus(Class<T> eventClass) {
        return (EventBus<T>) eventBusMap.get(eventClass);
    }

    public static <T extends Event> void fire(T event) {
        getEventBus(event.getEventClass()).fireEvent(event);
    }

}
