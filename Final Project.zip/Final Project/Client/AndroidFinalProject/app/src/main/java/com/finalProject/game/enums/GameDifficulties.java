package com.finalProject.game.enums;

public enum GameDifficulties {
    Easy,
    Normal,
    Medium,
    Hard,
    VeryHard,
    Hardcore,
    Impossible,
}
