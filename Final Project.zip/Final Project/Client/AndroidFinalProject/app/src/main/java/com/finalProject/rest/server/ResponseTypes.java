package com.finalProject.rest.server;

public enum ResponseTypes {
    Success(0),
    Error(400),
    Unknown(-1);

    public int value;

    private ResponseTypes(int value) {
        this.value = value;
    }

    public static ResponseTypes getValueOf(int value) {
        if (value == 0) return Success;
        else if (value == 400) return Error;
        else return Unknown;
    }
}

