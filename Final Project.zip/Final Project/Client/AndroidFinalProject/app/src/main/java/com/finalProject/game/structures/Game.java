package com.finalProject.game.structures;

import com.finalProject.game.enums.GameDifficulties;

public class Game {
    private String id;
    private Boolean allowBots;
    private String mode;
    private String difficulty;

    public Game(String id, GameDifficulties difficulty, Boolean isOnlineMode, Boolean allowsBots) {
        this.id = id;
        this.difficulty = difficulty.name();
        this.mode = isOnlineMode ? "multiplayer" : "singleplayer";
        this.allowBots = allowsBots;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getAllowBots() {
        return allowBots;
    }

    public void setAllowBots(Boolean allowBots) {
        this.allowBots = allowBots;
    }

    public String getMode() {
        return mode;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    @Override
    public String toString() {
        return "Game{" +
                "id='" + id + '\'' +
                ", allowBots=" + allowBots +
                ", mode='" + mode + '\'' +
                '}';
    }
}
