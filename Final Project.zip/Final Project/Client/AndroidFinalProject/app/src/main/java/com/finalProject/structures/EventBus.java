package com.finalProject.structures;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class EventBus<T extends Event> {
    private List<Method> methods = new ArrayList<>();
    private List<Consumer<T>> consumers = new ArrayList<>();

    public List<Consumer<T>> getConsumers() {
        return consumers;
    }

    public void setConsumers(List<Consumer<T>> consumers) {
        this.consumers = consumers;
    }

    public void addConsumer(Consumer<T> consumer) {
        consumers.add(consumer);
    }

    public void removeConsumer(Consumer<T> consumer) {
        this.consumers.remove(consumer);
    }

    public void addConsumer(List<Consumer<T>> consumers) {
        consumers.forEach((consumer) -> this.addConsumer(consumer));
    }

    public void removeConsumer(List<Consumer<T>> consumers) {
        consumers.forEach((consumer) -> this.removeConsumer(consumer));
    }

    public List<Method> getMethods() {
        return this.methods;
    }

    public void setMethods(List<Method> methods) {
        this.methods = methods;
    }

    public void addMethod(Method method) {
        this.methods.add(method);
    }

    public void removeMethod(Method method) {
        this.methods.remove(method);
    }

    public void addMethods(List<Method> methods) {
        methods.forEach((method) -> this.addMethod(method));
    }

    public void removeMethods(List<Method> methods) {
        methods.forEach((method) -> this.removeMethod(method));
    }

    public void fireEvent(T event) {

        List<Consumer<T>> consumers = this.consumers;
        List<Method> methods = this.methods;

        if (consumers != null) {
            consumers.forEach(consumer -> {
                consumer.accept(event);
            });
        }


        if (methods != null) {
            methods.forEach(method -> {
                try {
                    method.invoke(null, event);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.getCause().printStackTrace();
                }
            });
        }

    }
}

