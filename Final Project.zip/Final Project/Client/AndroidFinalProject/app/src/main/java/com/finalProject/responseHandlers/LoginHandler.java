package com.finalProject.responseHandlers;

import android.content.Context;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.finalProject.rest.authorization.UserAuthorization;
import com.finalProject.rest.server.ServerResponse;
import com.finalProject.storage.UserManager;
import com.finalProject.structures.ResponseHandler;
import com.finalProject.utils.App;
import com.finalProject.utils.Session;

import java.util.Map;
import java.util.Set;

public class LoginHandler extends ResponseHandler<LoginHandler> {

    private UserAuthorization userAuth;
    private TextView textView;
    private boolean success;


    public static void handle(AppCompatActivity activity, UserAuthorization userAuth, TextView textView) {
        new LoginHandler(activity, userAuth, textView).handle();
    }

    public LoginHandler(AppCompatActivity activity, UserAuthorization userAuth, TextView textView) {
        super(userAuth.getServerResponse(), activity);
        this.userAuth = userAuth;
        this.textView = textView;
    }

    @Override
    public void onFailure(ServerResponse err, AppCompatActivity activity) {
        textView.setTextColor(Color.RED);

        switch (err.getErrorId()) {
            case 301:
                textView.setText("Incorrect username or email!");
                break;

            case 302:
                textView.setText("Invalid Password did you forget it? click here.");
                break;

            case 303, 304:
                textView.setText("Something went wrong, Please try again later!");
                break;
        }

    }

    @Override
    public void onSuccess(ServerResponse response, AppCompatActivity activity) {
        try {
            UserManager userManager = (UserManager) App.get().getManager("user_storage");
            userManager.saveAuthorization(userAuth);
            textView.setText("You have been successfully logged in!");
            success = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUnhandledResult(AppCompatActivity activity) {
        TextView textView = new TextView(activity);
        textView.setTextColor(Color.RED);
        textView.setText("Something went wrong, Please try again later!");
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public UserAuthorization getUserAuth() {
        return userAuth;
    }

    public TextView getTextView() {
        return textView;
    }
}
