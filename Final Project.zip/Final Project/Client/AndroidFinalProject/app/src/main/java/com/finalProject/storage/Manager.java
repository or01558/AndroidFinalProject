package com.finalProject.storage;

import android.content.SharedPreferences;
import org.jetbrains.annotations.Nullable;
import java.util.Map;
import java.util.Set;

public abstract class Manager {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor = null;
    private boolean editingMode;


    public Manager(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
        this.editingMode = false;
    }

    public void edit() {
        if(!editingMode) this.editor = sharedPreferences.edit();
        this.editingMode = true;
    }

    public void save(String name, Object value, boolean applyChanges) {
        this.edit();
        this.put(name, value);
        if (applyChanges) this.applyChanges();
    }

    public void save(String name, Object value) {
        this.save(name, value, false);
    }

    private void put(String name, Object value) {
        if (value instanceof String) this.put(name, (String) value);
        if (value instanceof Integer) this.put(name, (Integer) value);
        if (value instanceof Long) this.put(name, (Long) value);
        if (value instanceof Float) this.put(name, (Float) value);
        if (value instanceof Boolean) this.put(name, (Boolean) value);
        else this.put(name, value.toString());
    }

    public Object get(String name) {
        Map<String, ?> savedData = sharedPreferences.getAll();
        return savedData.containsKey(name) ? savedData.get(name) : null;
    }

    public boolean has(String name) {
        return sharedPreferences.contains(name);
    }

    public boolean has(String[] names) {
        for (String name : names) {
            if (!sharedPreferences.contains(name)) return false;
        }
        return true;
    }

    public void delete(String name, boolean applyChanges) {
        this.edit();
        this.editor.remove(name);
        if (applyChanges) this.applyChanges();
    }

    public void delete(String name) {
        this.delete(name, false);
    }

    public void put(String name, @Nullable String value) {
        this.editor.putString(name, value);
    }

    public void put(String name, @Nullable Set<String> value) {
        this.editor.putStringSet(name, value);

    }

    public void put(String name, Integer value) {
        this.editor.putInt(name, value);
    }

    public void put(String name, Long value) {
        this.editor.putLong(name, value);
    }

    public void put(String name, Float value) {
        this.editor.putFloat(name, value);
    }

    public void put(String name, Boolean value) {
        this.editor.putBoolean(name, value);
    }

    public void applyChanges() {
        this.editor.apply();
    }
}
