package com.finalProject.rest.server;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONException;
import org.json.JSONObject;


public class ServerResponse extends Throwable {
        @NotNull
        private String message = "";

        @NotNull
        private HttpStatus status;

        @NotNull
        private ResponseTypes type;

        @Nullable
        private Integer errorId = null;

        @Nullable
        private String reason = null;

        @Nullable
        private String got = null;

        @Nullable
        private String expected = null;

        @Nullable
        private Object value;

        private int statusCode;

        @NotNull
        public final String getMessage() {
                return this.message;
        }

        @NotNull
        public final HttpStatus getStatus() {
                return this.status;
        }

        @NotNull
        public final ResponseTypes getType() {
                return this.type;
        }

        @Nullable
        public final Integer getErrorId() {
                return this.errorId;
        }

        @Nullable
        public final String getReason() {
                return this.reason;
        }

        @Nullable
        public final String getGot() {
                return this.got;
        }

        @Nullable
        public final String getExpected() {
                return this.expected;
        }

        @Nullable
        public final Object getValue() {
                return this.value;
        }

        public final void setValue(@Nullable Object value) {
                this.value = value;
        }

        public final int getStatusCode() {
                return this.statusCode;
        }

        public final void setStatusCode(int statusCode) {
                this.statusCode = statusCode;
        }

        public ServerResponse(@NotNull String message, @NotNull HttpStatus status, @NotNull ResponseTypes type, @Nullable Integer errorId, @Nullable String reason, @Nullable String got, @Nullable String expected, @Nullable Object value) {
                this.message = message;
                this.status = status;
                this.type = type;
                this.errorId = errorId;
                this.reason = reason;
                this.got = got;
                this.expected = expected;
                this.value = value;
                this.statusCode = status.value();
        }

        public ServerResponse(@NotNull String message, @NotNull HttpStatus status, @NotNull ResponseTypes type, @Nullable Integer errorId, @Nullable String reason, @Nullable String got, @Nullable String expected, @Nullable Object value, int statusCode) {
                this(message, status, type, errorId, reason, got, expected, value);
                this.statusCode = statusCode;
        }

        public static ServerResponse createFromJSON(@NotNull JSONObject json) throws JSONException {
                JSONObject value = null;
                if (!json.isNull("value")) {
                        value = new JSONObject(json.getString("value"));
                }

                Integer errorId = (Integer) null;
                if (!json.isNull("errorId")) {
                        errorId = json.getInt("errorId");
                }

                String reason = (String) null;
                String got = (String) null;
                String expected = (String) null;
                if (!json.isNull("reason")) {
                        reason = json.getString("reason");
                }

                if (!json.isNull("got")) {
                        got = json.getString("got");
                }

                if (!json.isNull("expected")) {
                        expected = json.getString("expected");
                }

                return new ServerResponse(json.getString("message"), HttpStatus.valueOf(json.getString("status")), ResponseTypes.valueOf(json.getString("type")), errorId, reason, got, expected, value, json.getInt("statusCode"));
        }

        public static class ResponseBuilder {
                @NotNull
                private String message;
                @NotNull
                private HttpStatus status;
                @NotNull
                private ResponseTypes type;
                @Nullable
                private Integer errorId;
                @Nullable
                private String reason;
                @Nullable
                private String got;
                @Nullable
                private String expected;

                public ResponseBuilder(@NotNull String message, @NotNull HttpStatus status, @NotNull ResponseTypes type, @Nullable Integer errorId, @Nullable String reason, @Nullable String got, @Nullable String expected) {
                        this.message = message;
                        this.status = status;
                        this.type = type;
                        this.errorId = errorId;
                        this.reason = reason;
                        this.got = got;
                        this.expected = expected;
                }

                @NotNull
                public ResponseBuilder setMessage(@NotNull String message) {
                        this.message = message;
                        return this;
                }

                @NotNull
                public ResponseBuilder message(@NotNull String message) {
                        return this.setMessage(message);
                }

                @NotNull
                public ResponseBuilder setStatus(@NotNull HttpStatus status) {
                        this.status = status;
                        return this;
                }

                @NotNull
                public ResponseBuilder status(@NotNull HttpStatus status) {
                        return this.setStatus(status);
                }

                @NotNull
                public ResponseBuilder setType(@NotNull ResponseTypes type) {
                        this.type = type;
                        return this;
                }

                @NotNull
                public ResponseBuilder type(@NotNull ResponseTypes type) {
                        return this.setType(type);
                }

                @NotNull
                public ResponseBuilder setErrorId(@Nullable Integer errorId) {
                        this.errorId = errorId;
                        return this;
                }

                @NotNull
                public ResponseBuilder errorId(@Nullable Integer errorId) {
                        return this.setErrorId(errorId);
                }

                @NotNull
                public ResponseBuilder setReason(@Nullable String reason) {
                        this.reason = reason;
                        return this;
                }

                @NotNull
                public ResponseBuilder reason(@Nullable String reason) {
                        return this.setReason(reason);
                }

                @NotNull
                public ResponseBuilder setGot(@Nullable String got) {
                        this.got = got;
                        return this;
                }

                @NotNull
                public final ResponseBuilder got(@Nullable String got) {
                        return this.setGot(got);
                }

                @NotNull
                public ResponseBuilder setExpected(@Nullable String expected) {
                        this.expected = expected;
                        return this;
                }

                @NotNull
                public ResponseBuilder expected(@Nullable String expected) {
                        return this.setExpected(expected);
                }

                @NotNull
                public ResponseBuilder gotWhileExpected(@Nullable String got, @Nullable String expected) {
                        this.setGot(got);
                        return this.setExpected(expected);
                }

                @NotNull
                public ServerResponse error(@Nullable String reason, @Nullable String got, @Nullable String expected) {
                        this.setReason(reason);
                        return this.gotWhileExpected(got, expected).build();
                }

                @NotNull
                public final ServerResponse build() {
                        return new ServerResponse(this.message, this.status, this.type, this.errorId, this.reason, this.got, this.expected, null, 0);
                }

                @NotNull
                public String getMessage() {
                        return this.message;
                }

                @NotNull
                public HttpStatus getStatus() {
                        return this.status;
                }

                @NotNull
                public ResponseTypes getType() {
                        return this.type;
                }

                @Nullable
                public Integer getErrorId() {
                        return this.errorId;
                }


                @Nullable
                public String getReason() {
                        return this.reason;
                }


                @Nullable
                public String getGot() {
                        return this.got;
                }


                @Nullable
                public String getExpected() {
                        return this.expected;
                }

        }
}
