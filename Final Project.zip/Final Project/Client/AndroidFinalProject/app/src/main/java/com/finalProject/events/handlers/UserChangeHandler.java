package com.finalProject.events.handlers;

import com.finalProject.MainActivity;
import com.finalProject.UserActivity;
import com.finalProject.UserDeletionActivity;
import com.finalProject.annotations.EventHandler;
import com.finalProject.events.builtin.UserChangeEvent;
import com.finalProject.storage.UserManager;
import com.finalProject.utils.App;

public class UserChangeHandler {

    @EventHandler
    public static boolean onChange(UserChangeEvent event) {
        App app = App.get();
        System.out.print("hey user!");
        UserChangeEvent.UserConnection connectionState = event.getConnectionState();
        if (connectionState == UserChangeEvent.UserConnection.CONNECTING && event.getUser() != null && event.isConnected()) {
            app.startActivity(UserActivity.class);
        } else if (connectionState == UserChangeEvent.UserConnection.LOGGING_OUT && event.getUser() == null && !event.isConnected()) {
            app.startActivity(MainActivity.class);
        } else if (connectionState == UserChangeEvent.UserConnection.DELETING) {
            app.startActivity(UserDeletionActivity.class);
        }

        return true;
    }
}
