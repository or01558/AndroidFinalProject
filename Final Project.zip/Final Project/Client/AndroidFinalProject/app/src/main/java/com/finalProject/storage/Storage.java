package com.finalProject.storage;

import android.content.SharedPreferences;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

public class Storage {
    private static HashMap<String, Class<? extends Manager>> managers = new HashMap<>();

    public static void registerManager(String name, Class<? extends Manager> managerClass) {
        managers.put(name, managerClass);
    }

    public static void registerManagers() {
        registerManager("user_storage", UserManager.class);
    }

    public static Manager getManager(String name, SharedPreferences sharedPreferences) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {
        if(!managers.containsKey(name)) return null;
        return managers.get(name).getConstructor(SharedPreferences.class).newInstance(sharedPreferences);
    }
}
