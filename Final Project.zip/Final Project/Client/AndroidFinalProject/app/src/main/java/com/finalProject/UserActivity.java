package com.finalProject;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.finalProject.game.client.GameClient;
import com.finalProject.game.enums.GameDifficulties;
import com.finalProject.game.events.GameServiceEvents;
import com.finalProject.game.structures.Game;
import com.finalProject.game.structures.PlayGameData;
import com.finalProject.structures.BaseActivity;
import com.finalProject.objects.User;
import com.finalProject.storage.UserManager;
import com.finalProject.utils.App;
import com.finalProject.utils.Session;

import org.json.JSONException;

import java.lang.reflect.InvocationTargetException;

public class UserActivity extends BaseActivity implements GameServiceEvents, AdapterView.OnItemSelectedListener {
    TextView welcomeMessage;
    private boolean allowBots = true;
    private GameDifficulties difficulty = GameDifficulties.Normal;
    private boolean onlineMode = false;
    private Spinner gameDifSelector;

    @Override
    protected void onCreate(Bundle savedInstance) {
        this.loadUser = false;
        super.onCreate(savedInstance);
        setContentView(R.layout.activity_user);
        welcomeMessage = findViewById(R.id.formResultMessage);
        gameDifSelector = findViewById(R.id.gameDifSelector);

        gameDifSelector.setAdapter(ArrayAdapter.createFromResource(this, R.array.game_difficulties_array, R.layout.activity_user));
        User user = Session.getCurrentUser();
        System.out.println(user);
        welcomeMessage.setText(welcomeMessage.getText().toString().replace("{user.username}", user.getUsername()));

    }

    public void logout(View v) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException, InstantiationException {
        UserManager userManager = (UserManager) App.get().getManager("user_storage");
        userManager.deleteAuthorization();
        Session.setCurrentUser(null);
    }

    public void createGameClientAndPlay(boolean onlineMode) throws JSONException, JsonProcessingException {
        GameClient gameClient = GameClient.getCurrentInstance();

        this.onlineMode = onlineMode;

        if(GameClient.getCurrentInstance() == null) {
            gameClient = new GameClient(Session.getCurrentUser(), this);
        }

        play(gameClient);
    }

    public void play(GameClient gameClient) throws JSONException, JsonProcessingException {
        gameClient.setPlayGameData(new PlayGameData(new Game("6308242213402244", difficulty, onlineMode, allowBots)));
        if(!onlineMode && gameClient.isConnected()) gameClient.play(gameClient.getPlayGameData());
        else if(gameClient.isConnected()) playOnlineMode();
    }

    public void playSinglePlayer(View v) throws JSONException, JsonProcessingException {
        createGameClientAndPlay(false);
    }

    public void playMultiPlayer(View v) throws JSONException, JsonProcessingException {
      showAllowBotsScreen();
    }

    public void showAllowBotsScreen() {
        new AlertDialog.Builder(this)
                .setTitle("Multiplayer Mode Chosen")
                .setMessage("Do you want to allow game bots in your game in order to fill an empty place when needed?")

                .setPositiveButton("yes", (dialog, which) -> {
                    allowBots = true;
                    try {
                        createGameClientAndPlay(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                })

                .setNegativeButton("no", (dialog, which) -> {
                    allowBots = false;
                    try {
                        createGameClientAndPlay(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    public void playOnlineMode() {
       App.get().startActivity(GameOnlineModeActivity.class);
    }

    @Override
    public void onGameClientConnection() {
        GameClient gameClient = GameClient.getCurrentInstance();
        try {
            gameClient.setConnected(true);
            if(!this.onlineMode) gameClient.play(gameClient.getPlayGameData());
            else playOnlineMode();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
      String difficulty = (String) parent.getItemAtPosition(pos);
      this.difficulty = GameDifficulties.valueOf(difficulty);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
