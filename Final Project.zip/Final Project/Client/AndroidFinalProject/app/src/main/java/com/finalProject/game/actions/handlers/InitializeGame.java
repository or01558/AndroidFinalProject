package com.finalProject.game.actions.handlers;

import com.finalProject.GameActivity;
import com.finalProject.utils.App;
import com.finalProject.utils.Session;

import org.json.JSONObject;

public class InitializeGame {

    public static void handle(JSONObject matchJson) {
      Session.setMatchJson(matchJson);
      App.get().startActivity(GameActivity.class);
    }
}
