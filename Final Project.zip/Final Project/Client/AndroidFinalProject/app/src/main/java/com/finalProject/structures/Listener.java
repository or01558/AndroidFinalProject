package com.finalProject.structures;
import com.finalProject.events.builtin.UserChangeEvent;

public interface Listener {
    boolean onUserChange(UserChangeEvent event);
}
