package com.finalProject.game.structures;

public class PlayerMove {
    private int value;

    public PlayerMove(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "PlayerMove{" +
                "value=" + value +
                '}';
    }
}
