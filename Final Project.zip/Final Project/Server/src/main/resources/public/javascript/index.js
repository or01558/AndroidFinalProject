import Resources from "./src/utils/Resources.js";

const { userJson } = globalThis;
let user = null;

console.log("User Json is", userJson);

/*if (userJson) user = Resources.loadUser(userJson);
window.user = user;

if (user != null && user instanceof User) {
    Console.log(`User is ${user}`);

    const userId = user.getId();
    const username = user.getUsername();

} else {

};*/