export default class Resources {
  

}