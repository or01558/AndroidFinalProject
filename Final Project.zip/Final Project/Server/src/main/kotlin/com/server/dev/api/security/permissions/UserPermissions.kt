package com.server.dev.api.security.permissions

import org.springframework.stereotype.Component

@Component
object UserPermissions {
    val Username : Permission = Permission(1, "Username Access", "User's Username Permission", "Allows access to the username name of this specific user", "access.user.username")
    val Profile: Permission = Permission(2, "Profile Access", "User's Profile Permission", "Allows access to the profile name of this specific user", "access.user.profile")
    val Manage_Player: Permission = Permission(3, "Manage Player Access", "User's Player Permission", "Allows access to the player info and management of this specific user", "access.user.manage_player")
}