package com.server.dev.games

import com.server.dev.api.game.*
import com.server.dev.games.annotations.GameId
import com.server.dev.games.bots.GuessTheNumberBot
import kotlin.random.Random

class GuessTheNumberState : GameState<GuessTheNumberState?>{
    val guessNumber : Int
    val guesses : MutableList<Int>

  constructor(guessNumber : Int, guesses : MutableList<Int>) : super(null) {
      this.guessNumber = guessNumber
      this.guesses = guesses
      setState(this)
  }
}

@GameId("6308242213402244")
class GuessTheNumber(difficulty : GameDifficulties, match : Match<GuessTheNumberState?, GuessTheNumberState, GuessTheNumber, Int>? = null, private var maxNumber : Int = 0) : Game<GuessTheNumberState?, GuessTheNumberState, GuessTheNumber, Int>(difficulty, null, match) {
    companion object {
        const val minPlayers: Int = 2
        const val maxPlayers: Int = 4
        var maxRounds = 20
    }

    override fun setMatch(match: Match<GuessTheNumberState?, GuessTheNumberState, GuessTheNumber, Int>?) {
        super.setMatch(match)
        getMatch()?.players?.forEach { user ->
            if (user.player?.bot == true) {
                bots.add(GuessTheNumberBot(user, maxNumber = maxNumber))
            }
        }
    }

    override fun start() {
        setState(GuessTheNumberState(generateGuessNumber(), mutableListOf()))
    }

    override fun isWin(): Boolean {
        val match = getMatch() ?: return false
        val state = getState() ?: return false
        if (match.currentMove == state.guessNumber) {
            match.winner = match.currentPlayerTurn
            getMatch()?.game!!.gameEnded = true
            return true
        }

        return false
    }

    override fun makeMove(move: Int) {
        val match = getMatch() ?: return
        val state = getState() ?: return

        if (match.currentRound < maxRounds) {
            state.guesses.add(move)
            match.currentMove = move
            if (!isWin()) {
                if (match.currentPlayerTurnIndex + 1 == match.playersCount) {
                    match.currentRound++
                    match.currentPlayerTurnIndex = 0
                    match.currentPlayerTurn = match.players[0]
                } else {
                    match.currentPlayerTurnIndex++
                    match.currentPlayerTurn = match.players[match.currentPlayerTurnIndex]
                    makeBotTurns()
                }
            }
        } else {
            stop()
        }
    }

    override fun makeBotTurns() {
        val match = getMatch() ?: return
        val user = match.currentPlayerTurn
        if (user.player?.bot == true) {
            val bot = findBot(user) ?: return
            val move = bot.generateMove()
            makeMove(move)
        }
    }

    private fun generateGuessNumber(): Int {
        val max: Int
        when (difficulty) {
            GameDifficulties.Easy -> {
                max = 6
                maxRounds = 3
            }

            GameDifficulties.Normal -> {
                max = 10
                maxRounds = 5
            }

            GameDifficulties.Medium -> {
                max = 20
                maxRounds = 10
            }

            GameDifficulties.Hard -> {
                max = 50
                maxRounds = 25
            }

            GameDifficulties.VeryHard -> {
                max = 100
                maxRounds = 50
            }

            GameDifficulties.Hardcore -> {
                max = 120
                maxRounds = 60
            }

            GameDifficulties.Impossible -> {
                max = 180
                maxRounds = 90
            }
        }
        maxNumber = max
        return Random.nextInt(max) + 1
    }
}