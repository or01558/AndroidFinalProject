package com.server.dev.api.database.repositories

import com.server.dev.api.database.entities.UserEntity
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface UsersRepository : CrudRepository<UserEntity, String> {
   fun findByUsername(username : String) :  List<UserEntity>
   fun findByEmail(email : String) :  List<UserEntity>
   fun findByUsernameOrEmail(username : String, email : String) : List<UserEntity>

}