package com.server.dev.api.services.game

import org.springframework.stereotype.Service

@Service
class GameService(val clientsService: ClientsService) {
}