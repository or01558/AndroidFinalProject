package com.server.dev.api.services.users.auth

import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.responses.errors.ApiErrors
import com.server.dev.api.responses.errors.UserAuthorizationErrors
import com.server.dev.api.security.AuthorizationManager
import com.server.dev.api.security.authorization.AuthResponse
import com.server.dev.api.security.authorization.Authorization
import com.server.dev.api.security.authorization.ResponseTypes
import com.server.dev.api.security.authorization.clients.Clients
import com.server.dev.api.security.users.auth.UserAuthorization
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.utils.RequestBody
import com.server.dev.api.utils.ServerResources
import org.json.JSONObject
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service

@Service
class UserAuthorizationService(val usersRepository: UsersRepository) {

    fun createAuthorization(authResponse: AuthResponse?): ResponseEntity<*> {
        if(authResponse == null) return UserAuthorizationErrors.InvalidCodeAuthorization.entity()

        val code = authResponse.code
        val error = authResponse.error
        val errorMessage = authResponse.errorMessage
        val clientId = authResponse.clientId
        val clientSecret = authResponse.clientSecret


        if (code != null && !error) {
            val clientResult = RequestBody.getClient(clientId, clientSecret);
            if(clientResult as? ServerResponse != null) return clientResult.entity()

            val client = clientResult as Clients
            val authResult = AuthorizationManager.getAuthorizationInfo(code, client) ?: ApiErrors.UnknownError.entity()
            val authorization = authResult as Authorization

            authorization.responseType = ResponseTypes.AccessToken
            val accessToken = AuthorizationManager.generateToken(authorization, client)

            authorization.responseType = ResponseTypes.RefreshToken
            val refreshToken = AuthorizationManager.generateToken(authorization, client)
            val responseBody = JSONObject()
            responseBody.put("accessToken", accessToken)
            responseBody.put("refreshToken", refreshToken)

            return ServerResponse("Authorization created", HttpStatus.OK, com.server.dev.api.structures.ServerResponseTypes.Success, null, "", "", "", responseBody).entity()

        } else if (error) {

            if (errorMessage == null)
               return ApiErrors.UnknownError.entity()

            return errorMessage.entity()

        } else
            return UserAuthorizationErrors.MissingAuthCode.entity()
    }

    fun authorizeUser(userAuthorization: UserAuthorization?): ResponseEntity<*> {
        if(userAuthorization == null) return UserAuthorizationErrors.InvalidAuthorization.entity()

        val accessToken = userAuthorization.accessToken ?: return UserAuthorizationErrors.MissingAccessToken.entity()
        val refreshToken = userAuthorization.refreshToken ?: return UserAuthorizationErrors.MissingRefreshToken.entity()
        val clientId = userAuthorization.clientId
        val clientSecret = userAuthorization.clientSecret


            val clientResult = RequestBody.getClient(clientId, clientSecret);
            if(clientResult as? ServerResponse != null) return clientResult.entity()

            val client = clientResult as Clients
            val authResult = ServerResources.authorizeUser(usersRepository, accessToken, refreshToken, client) ?: return ApiErrors.UnknownError.entity()
            val responseBody = JSONObject()

            responseBody.put("user", authResult.userJson)

            return ServerResponse("Authorization created", HttpStatus.OK, com.server.dev.api.structures.ServerResponseTypes.Success, null, "", "valid user authorization", "valid user authorization", responseBody).entity()
    }
}