package com.server.dev.api.database.entities


import javax.persistence.*

@Entity
@Table(name = "games")
data class GameEntity(
    @Id
    val id : String,
    val title : String,
    val name : String,
    val description : String,
){
    constructor() : this("", "", "", "")
}