package com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors

import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.structures.ServerResponseTypes
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class GameDataErrors {
    companion object {
        val SomethingWentWrong = ServerResponse(
            "Something went wrong!",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Unknown,
            4000,
            "Invalid Game Data Has Provided",
            "unknown",
            "valid game data"
        )
    }
}