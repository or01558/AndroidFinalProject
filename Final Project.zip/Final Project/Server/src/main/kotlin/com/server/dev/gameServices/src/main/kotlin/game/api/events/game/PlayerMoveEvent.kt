package com.server.dev.gameServices.src.main.kotlin.game.api.events.game

import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketEvent
import org.json.JSONObject

final class PlayerMoveEvent: WebSocketEvent<PlayerMoveEvent>{
    private val move : String

    constructor(move : String) : super("playerMove", 187171, null)  {
        this.move = move
        setEvent(this)
    }

    override fun getEventJson(): JSONObject {
        val json =  JSONObject()
        json.put("move", move)
        return json
    }
}