package com.server.dev.gameServices.src.main.kotlin.structures

import com.server.dev.api.structures.Json
import org.json.JSONObject

class Event(val title : String, val name : String, private val description: String, val data : Json) {
    fun toJson(): JSONObject {
        val eventJSON = JSONObject()
        eventJSON.put("title", title)
        eventJSON.put("name", name)
        eventJSON.put("description", description)
        eventJSON.put("data", data.toJson())

        return eventJSON
    }
}