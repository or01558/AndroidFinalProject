package com.server.dev.api.constants

val userNames = listOf<String>(
"Mr.Weasel2",
"Lyra149",
"Michael263",
"Thor2765",
"Sophie2182",
"Maya121",
"WinterGuard135",
"Sasha The Unbeatable Warrior",
"ApexGG",
"Marion34",
"BetaTron2",
"OliverTheKing",
"GhostBuster",
"\$WizardOf4The#Devoure_OFSouls",
"_The_Devourer_of_The_Souls",
"TheWanderer2",
"RileyDamon2u2y",
"SilverTron543",
"TheBabyGuard2982",
"Onyx121",
"GenesisBot2u3",
"FrankieBot28181",
"KatsumiGuard2821",
"ThePrimeBot542",
"Ultron124__5",
"AndyRoid2517",
"CybelQ473",
"Ezegoidtar11t762",
"TinkerThe_lordOf_ThWinners15168",
"Lennony176161",
"<>Jordan<<Bot1u17>>",
"Sakura",
"Lee1\$571",
"Omega1311",
"TheIvoryBot331",
"HitomiBot121",
"JuniorBot123",
"Darian15689",
"YaraTheQueenBot131",
"BronzeyTheKingBot131261",
"EbonyBoty14532",
"Boty14568971",
"Botyna71651",
"Botrino17816761",
"Otterinyah1ty1f$",
"Otterino1514#1",
 "TheFox15789",
"AkiTheUnbeatableBot",
"AkinaTheUnbeatableGirl",
"AmariTron125703040",
"ElliottDenver58126"
)

fun main(args : Array<String>){
    println(userNames.size)
}

val imageColors = listOf(
    "light_gray",
    "gray",
    "dark_gray",

    "light_blue",
    "blue",
    "dark_blue",

    "light_yellow",
    "yellow",
    "dark_yellow",

    "light_red",
    "red",
    "dark_red",

    "light_purple",
    "purple",
    "dark_purple",

    "light_orange",
    "orange",
    "dark_orange",

    "light_brown",
    "brown",
    "dark_brown",

    "light_green",
    "green",
    "dark_green",


    "light_green",
    "green",
    "dark_green",


    "gold_fusion",
    "sonic_silver",
    "alloy_orange",

    "b'dazzled_blue",
    "big_dip_o'_ruby",
    "steel_blue",

    "bittersweet_shimmer",
    "blast_off_bronze",
    "cyber_grape",

    "deep_space_sparkle",
    "illuminating_emerald",
    "metallic_seaweed",

    "metallic_sunburst",
    "razzmic_berry",
    "sheen_green",

    "shimmering_blush",
    "baseball_mitt_(Burnt Sienna)",
    "earthworm_(Brick Red)",

    "pine_tree_(Pine Green)",
    "saw_dust_(Peach)",
    "sharpening_pencils_(Goldenrod)",

    "smell_the_roses_(Red)",
    "sunny_day_(Yellow)",
    "wash_the_dog_(Dandelion)"
)
