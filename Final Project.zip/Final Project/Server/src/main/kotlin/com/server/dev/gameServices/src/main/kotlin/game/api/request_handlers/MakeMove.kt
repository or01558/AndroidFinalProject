package com.server.dev.gameServices.src.main.kotlin.game.api.request_handlers

import com.server.dev.api.extensions.sha256
import com.server.dev.api.game.GameClient
import com.server.dev.api.game.Match
import com.server.dev.api.structures.Json
import com.server.dev.gameServices.src.main.kotlin.game.api.events.game.GameEndEvent
import com.server.dev.gameServices.src.main.kotlin.game.api.events.game.PlayerMoveEvent
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketActions
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketResponse
import com.server.dev.gameServices.src.main.kotlin.structures.GameRoom
import com.server.dev.gameServices.src.main.kotlin.structures.Service
import com.server.dev.games.GuessTheNumber
import org.json.JSONObject
import org.springframework.web.socket.TextMessage

data class PlayerMove(val value : Int) : Json() {
    override fun declareJSON() {
        super.declareJSON()
        val moveDataJSON = JSONObject()
        moveDataJSON.put("value", value)
        this["move"] = moveDataJSON
    }
}

fun endGame(service : Service, gameRoom: GameRoom, match : Match<*, *, *, *>) {
    val webSocketResponse = WebSocketResponse(GameEndEvent(match), match, WebSocketActions("endGame", 11771, mutableListOf()))

    gameRoom.gameClients.forEach { gameClient ->
            gameClient.webSocketSession!!.sendMessage(TextMessage(webSocketResponse.toJson().toString()))
    }

    service.gameRooms.remove(gameRoom)

}

fun makeMove(service: Service, gameClient: GameClient, data: JSONObject) : Boolean? {
   try {
       if (!data.has("move")) return false

       val move = data.getJSONObject("move")
       if(!move.has("value")) return false
       val value = move.getInt("value")
       val gameRoom = service.findGameRoom(gameClient) ?: return null
       val match =  gameRoom.match ?: return false
       val game = match.game as GuessTheNumber
       game.makeMove(value)
       if(game.gameEnded) endGame(service, gameRoom, match)
       val webSocketResponse = WebSocketResponse(PlayerMoveEvent(value.toString().sha256()), match, WebSocketActions("makeMove", 191771, mutableListOf()))

       gameRoom.gameClients.forEach {
           it.webSocketSession!!.sendMessage(TextMessage(webSocketResponse.toJson().toString()))
       }

       return true
   } catch(exp : Exception) {
       exp.printStackTrace()
       return false
   }


}