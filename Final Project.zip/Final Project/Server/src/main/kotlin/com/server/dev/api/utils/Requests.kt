package com.server.dev.api.utils

import org.springframework.http.*
import org.springframework.stereotype.Component
import org.springframework.web.client.RestTemplate
import java.net.URL

@Component
class Requests {
    companion object {
        fun send(url : URL, json: String, method: HttpMethod = HttpMethod.POST, contentType: MediaType? = null): ResponseEntity<*> {
            val restTemplate = RestTemplate()
            val headers = HttpHeaders()
            if(contentType != null) headers.contentType = contentType
            else {
                headers.contentType = MediaType.APPLICATION_JSON
            }
            val request = HttpEntity<String>(json, headers)
            return restTemplate.exchange(url.toURI(), method, request, String::class.java)
        }
    }
}