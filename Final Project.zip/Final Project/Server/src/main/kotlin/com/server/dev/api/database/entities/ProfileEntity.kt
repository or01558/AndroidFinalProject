package com.server.dev.api.database.entities

import javax.persistence.*

@Entity
@Table(name="profiles")
data class ProfileEntity(
    @Id
    val id: String,
    val nickname: String = "default",
    val aboutMe: String = "",
    val icon: String = "default",
    val image: String = "default",
    val banner: String = "default",
){
    constructor() : this("")
}