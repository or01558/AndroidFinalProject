package com.server.dev.gameServices.src.main.kotlin.structures

import com.server.dev.api.game.GameClient
import com.server.dev.gameServices.src.main.kotlin.enums.ServiceTypes

abstract class Service(private val name : String, private val description: String, private val permission: List<String>, private val clientPermissions: List<String>, val type : ServiceTypes, private val port: Int) :
 WebSocketService(type) {
 val gameRooms: MutableList<GameRoom> = mutableListOf()

 fun findGameRoom(gameClient : GameClient) : GameRoom? {
  var gameRoom : GameRoom? = null
  gameRooms.forEach {
   if(it.gameClients.contains(gameClient)) gameRoom = it
  }

  return gameRoom
 }
}