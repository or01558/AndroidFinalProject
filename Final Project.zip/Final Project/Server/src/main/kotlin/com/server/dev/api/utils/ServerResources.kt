package com.server.dev.api.utils

import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.extensions.removeCookie
import com.server.dev.api.extensions.user
import com.server.dev.api.security.AuthorizationManager
import com.server.dev.api.security.authorization.AuthorizedUser
import com.server.dev.api.security.authorization.RefreshTokenAuthorization
import com.server.dev.api.security.authorization.Scopes
import com.server.dev.api.security.authorization.clients.Clients
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.json.JSONObject
import org.springframework.stereotype.Component
import org.springframework.web.servlet.view.RedirectView
import java.net.URL
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@Component
class ServerResources {
    companion object {

        fun authorizeUser(usersRepository : UsersRepository, accessToken: String, refreshToken: String, client : Clients = Clients.WEBSITE_CLIENT) : AuthorizedUser? {
            var userToken: String = accessToken
            var tokenData = AuthorizationManager.getTokenData(userToken, client)

            if (tokenData == null) {
                val newToken = createNewToken(refreshToken, client) ?: return null
                userToken = newToken
                tokenData = AuthorizationManager.getTokenData(userToken, client)

            }

            if (tokenData == null) return null
            val (userId) = tokenData

            if(!usersRepository.existsById(userId)) return null


            val userEntity = usersRepository.findById(tokenData.userId)

            return AuthorizedUser(userEntity.get(), tokenData.scopes, userToken)
        }


        fun logoutUser(request: HttpServletRequest, response: HttpServletResponse): RedirectView {
            if (request.user.isEmpty()) return RedirectView("/")
            response.removeCookie("u_a_t")
            response.removeCookie("u_r_t")
            request.user = ""
            return RedirectView("/")
        }

        private fun createNewToken(refreshToken: String, client : Clients): String? {
            val authorization =
                RefreshTokenAuthorization(client.id, client.secret, null, refreshToken)
            authorization.scopes = listOf(Scopes.Identity, Scopes.ManagePlayer)
            val response =
                Requests.send(URL("http://localhost/api/oauth2/token"), authorization.toJson().toString())
            val auth = JSONObject(response.body.toString())
            val error = auth.get("error") as? Boolean ?: true
            val token = auth.get("token") as? String
            return if (error) null
            else token
        }

        fun createJwtFrom(json : JSONObject): String? {
            println("jsonjwt is $json")
            val claims : HashMap<String, Any?> = HashMap()
            claims["data"] = json.toString()
            return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS256, Server.Secret).compact()
        }

        fun getJsonFrom(token: String): JSONObject {
            var data = Jwts.parser().setSigningKey(Server.Secret).parse(token)
            val jsonString = data.body.toString().replace("=", ":")
            return JSONObject(jsonString).getJSONObject("data")
        }
    }
}
