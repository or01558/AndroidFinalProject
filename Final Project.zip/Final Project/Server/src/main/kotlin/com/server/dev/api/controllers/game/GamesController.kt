package com.server.dev.api.controllers.game

import com.server.dev.api.services.game.GamesService
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.*

@Controller()
@RequestMapping("/api/games")
class GamesController(val gamesService : GamesService) {
    @GetMapping(value = ["/get/{gameId}"])
    fun getGame(@PathVariable(value="gameId", required = false) gameId : String?): ResponseEntity<*> {



        return if(gameId == null) gamesService.getGames().entity()
        else gamesService.getGame(gameId).entity()
    }
}