package com.server.dev.api.extensions

import javax.servlet.http.Cookie
import javax.servlet.http.HttpServletResponse

fun HttpServletResponse.createCookie(name: String, value: String, path : String = "/") {
    val cookie = Cookie(name, value)
    cookie.secure = true
    cookie.isHttpOnly = true
    cookie.path = path
    addCookie(cookie)
}

fun HttpServletResponse.removeCookie(name: String) {
    val cookie = Cookie(name, null)
    cookie.maxAge = 0
    addCookie(cookie)
}