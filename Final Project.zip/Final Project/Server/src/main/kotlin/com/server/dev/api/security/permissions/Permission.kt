package com.server.dev.api.security.permissions

import com.server.dev.api.structures.Json
import org.springframework.stereotype.Component

@Component
data class Permission(val id  : Int, val name : String, val title : String, val description : String, val key : String) :
    Json() {

        init {
            declareJSON()
        }

    override fun declareJSON(){
        this["id"] = id
        this["name"] = name
        this["title"] = title
        this["description"] = description
        this["key"] = key
    }

}