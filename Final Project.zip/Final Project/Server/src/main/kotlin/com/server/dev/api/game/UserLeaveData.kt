package com.server.dev.api.game

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.structures.Json
import org.json.JSONObject

class UserLeaveData : Json {
    private val user : UserEntity
    private val isGameEnded : Boolean

    constructor(user : UserEntity, isGameEnded : Boolean) : super() {
        this.user = user
        this.isGameEnded = isGameEnded
    }

    override fun toJson(): JSONObject {
        return JSONObject(jacksonObjectMapper().writeValueAsString(this))
    }
}