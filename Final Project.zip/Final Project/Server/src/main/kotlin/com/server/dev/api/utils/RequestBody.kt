package com.server.dev.api.utils

import com.server.dev.api.security.authorization.clients.Clients
import com.server.dev.api.structures.ServerResponse.Companion.ResponseBuilder
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class RequestBody {

    companion object {
        fun isValidClient(clientId: String?): Boolean {
            val client = clientId?.let { Clients.get(it) }
            return client != null
        }

        fun getClient(clientId: String?, clientSecret: String?): Any {
            val defaultErrorResponse = ResponseBuilder()
                .message("Invalid Client")
                .status(HttpStatus.UNPROCESSABLE_ENTITY)

            if (clientId == null)
                return defaultErrorResponse.errorId(500).error("Missing Client's Id", null, "String")

            if(clientSecret == null)
                return defaultErrorResponse.errorId(501).error("Missing Client's Secret", null, "String")

            val exists = isValidClient(clientId)
            if (!exists)
                return defaultErrorResponse.errorId(502).error("Invalid Client Id", "invalid client id", "valid client id")

            val client = Clients.get(clientId)
                ?: return defaultErrorResponse.errorId(503).message("Cannot process the request").error("Invalid Client", "invalid client", "valid client")
            if(client.secret != clientSecret) return defaultErrorResponse.message("Cannot process the request").error("Invalid Client's Secret", "invalid client's secret", "valid client's secret")
            return client
        }
    }

}