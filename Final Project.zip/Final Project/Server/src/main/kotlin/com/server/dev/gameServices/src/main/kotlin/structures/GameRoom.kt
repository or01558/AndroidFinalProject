package com.server.dev.gameServices.src.main.kotlin.structures

import com.server.dev.api.database.entities.GameEntity
import com.server.dev.api.game.*

data class GameRoom(val gameEntity : GameEntity, val gameClients: MutableList<GameClient>, var match: Match<*, *, *, *>? = null, var allowBots : Boolean = true, var difficulty: GameDifficulties = GameDifficulties.Normal, var closed : Boolean = false) {

}