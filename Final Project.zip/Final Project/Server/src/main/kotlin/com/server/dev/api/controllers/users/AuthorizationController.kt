package com.server.dev.api.controllers.users

import com.server.dev.api.security.authorization.Authorization
import com.server.dev.api.security.authorization.ClientAuthorization
import com.server.dev.api.security.authorization.ResponseTypes
import com.server.dev.api.services.authorization.AuthorizationService
import org.springframework.http.MediaType
import org.springframework.web.bind.annotation.*
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse


@RestController()
@RequestMapping("/api/oauth2", method= [RequestMethod.POST])
class AuthorizationController(val authService : AuthorizationService) {

    @PostMapping(value= ["/token"], consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun grantToken(@RequestParam(required=false, name="responseType") responseType : ResponseTypes?, @RequestBody(required = false) authorization: Authorization?, request: HttpServletRequest, response: HttpServletResponse): Any {
        return authService.authorize(authorization, responseType)
    }

    @PostMapping(value= ["/redirect"], consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun redirect(@RequestParam(required=false, name="clientId") clientId : String?, @RequestParam(required=false, name="responseType") responseType : ResponseTypes?, @RequestBody(required = false) clientAuthorization: ClientAuthorization?, request: HttpServletRequest): Any {
        return authService.authorize(clientAuthorization, responseType, clientId)
    }

}