package com.server.dev.api.services.authorization

import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.responses.errors.AuthorizationErrors
import com.server.dev.api.security.AuthorizationManager
import com.server.dev.api.security.authorization.*
import com.server.dev.api.security.authorization.ResponseTypes.*
import com.server.dev.api.security.authorization.clients.Clients
import com.server.dev.api.structures.RequestURL
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.utils.RequestBody
import com.server.dev.api.utils.Requests
import org.springframework.http.*
import org.springframework.stereotype.Service
import org.springframework.web.servlet.view.RedirectView
import java.net.URL


@Service
class AuthorizationService(val usersRepository: UsersRepository) {

    fun authorize(authorization: Authorization?, responseType: ResponseTypes? = null, clientId: String? = null): Any {
        if (authorization == null) return AuthorizationErrors.EmptyBody.entity()

        if (responseType != null) authorization.responseType = responseType
        if (authorization.userId?.let { usersRepository.existsById(it) } == false) return AuthorizationErrors.invalidUserId(
            authorization.userId
        ).entity()

        if (clientId != null) authorization.clientId = clientId

        val clientResult = RequestBody.getClient(authorization.clientId, authorization.clientSecret);
        if (clientResult as? ServerResponse != null) return clientResult.entity()

        var client: Clients = clientResult as Clients

        val grantType = authorization.grant_type
            ?: return AuthorizationErrors.MissingGrantType

        val redirectMethod = authorization.redirectMethod
        return when (grantType) {
            GrantTypes.ClientAuthorization -> redirect(
                this.authorize(ClientAuthorization(authorization), client),
                redirectMethod
            )

            GrantTypes.AuthorizationCode -> redirect(
                this.authorize(CodeAuthorization(authorization), client),
                redirectMethod
            )

            GrantTypes.RefreshToken -> redirect(
                this.authorize(RefreshTokenAuthorization(authorization), client),
                redirectMethod
            )
        }
    }

    private fun redirect(authResponse: AuthResponse, method: HttpMethod? = null): Any {
        val redirectURL = authResponse.redirectUrl
        if (redirectURL != null) {
            if (method == HttpMethod.GET) {
              authResponse.redirectUrl = redirectURL
              val urlString = authResponse.getAsURL()
              if(urlString != null) return RedirectView(urlString)
              return ResponseEntity.status(HttpStatus.OK).body(authResponse.getBody())
            }


            return Requests.send(URL(redirectURL.toString()), authResponse.getBody())
        }

        return ResponseEntity.status(HttpStatus.OK).body(authResponse.getBody())
    }

    private fun authorize(authorization: ClientAuthorization, client: Clients): AuthResponse {
        var responseType = authorization.responseType
        val redirectURL = getRedirectUrl(authorization)
        val authResponse = AuthResponse(redirectURL)
        authResponse.clientId = client.id
        authResponse.clientSecret = client.secret

        if (responseType == null) return authResponse.setErrorMessage(
            AuthorizationErrors.invalidResponseType(type = "Code")
        )

        val code = AuthorizationManager.generateAuthorizationCode(authorization, client)

        when (responseType) {
            Code -> authResponse.setCode(code)
            else -> {
                authorization.code = code
                val codeAuthorization = CodeAuthorization.createFrom(
                    authorization,
                    client,
                    GrantTypes.AuthorizationCode,
                    responseType,
                    null
                )
                val responseEntity =
                    Requests.send(URL("http://localhost:8080/api/oauth2/token"), codeAuthorization.toJson().toString())
                authResponse.setResponseEntity(responseEntity)
            }
        }

        return authResponse.setResponseType(authorization.responseType)
    }

    private fun authorize(authorization: CodeAuthorization, client: Clients): AuthResponse {
        val redirectURL = getRedirectUrl(authorization)
        val authResponse = AuthResponse(redirectURL)
        authResponse.clientId = client.id
        authResponse.clientSecret = client.secret

        val responseType = authorization.responseType
        if (responseType == null || responseType == Code) return authResponse.setErrorMessage(
            AuthorizationErrors.invalidResponseType(responseType.toString(), "Access token or Refresh token")
        )

        authorization.code?.let { AuthorizationManager.getAuthorizationInfo(it, client) }
            ?: return authResponse.setErrorMessage(
                AuthorizationErrors.InvalidAuthCode
            )
        val token = AuthorizationManager.generateToken(authorization, client) ?: return authResponse.setErrorMessage(
            AuthorizationErrors.TokenISNULL
        )

        return authResponse.setToken(token).setResponseType(authorization.responseType)
    }


    private fun authorize(authorization: RefreshTokenAuthorization, client: Clients): AuthResponse {
        val redirectURL = getRedirectUrl(authorization)
        val authResponse = AuthResponse(redirectURL)
        authResponse.clientId = client.id
        authResponse.clientSecret = client.secret

        val responseType = authorization.responseType
        if (responseType == null || responseType !== AccessToken) return authResponse.setErrorMessage(
            AuthorizationErrors.invalidResponseType(responseType.toString(), "Access Token")
        )

        return authResponse.setToken(AuthorizationManager.createAccessTokenFrom(authorization, client))
            .setResponseType(authorization.responseType)
    }

    private fun getRedirectUrl(authorization: Authorization): RequestURL? {
        return if (authorization.redirect != null) {
            RequestURL(authorization.redirect.toString())
        } else null
    }
}