package com.server.dev.gameServices.src.main.kotlin.game.api.responses

import com.fasterxml.jackson.annotation.JsonIdentityInfo
import com.fasterxml.jackson.annotation.ObjectIdGenerators
import com.server.dev.api.structures.Json
import com.server.dev.api.structures.ServerResponse
import org.json.JSONObject


class WebSocketActions<Argument : Json?>(private var name : String, private var id : Int, private var args : MutableList<Argument>) : Json() {
    fun getName(): String {
        return this.name
    }

    fun setName(name: String) {
        this.name = name
    }

    fun getId(): Int {
        return this.id
    }

    fun getArguments(): MutableList<Argument> {
        return this.args
    }

    fun addArgument(arg: Argument) {
        this.args.add(arg)
    }

    fun removeArgument(arg: Argument) {
        this.args.remove(arg)
    }

    fun removeAllArguments() {
        this.args.clear()
    }

    override fun toJson() : JSONObject {
        this["name"] = name
        this["id"] = id
        val args = mutableListOf<JSONObject>()
        for(arg : Argument in this.args) {
            arg?.toJson()?.let { args.add(it) }
        }
        this["args"] = args
        return this
    }
}

@JsonIdentityInfo(
    generator = ObjectIdGenerators.PropertyGenerator::class,
            property = "id")
abstract class WebSocketEvent<Event : WebSocketEvent<Event>>(private var name: String, private var id: Int,
                                                    private var event: Event?) : Json() {
    fun getName(): String {
        return this.name
    }

    fun setName(name: String) {
        this.name = name
    }

    fun getId(): Int {
        return this.id
    }

    fun getEvent(): Event? {
        return this.event
    }

    fun setEvent(event: Event?) {
        this.event = event
    }

    abstract fun getEventJson() : JSONObject

    override fun toJson() : JSONObject {
        this["name"] = name
        this["id"] = id
        val eventJson = event?.getEventJson()
        if (eventJson != null)
            for (key in eventJson.keys()) {
               if(key is String) this[key] = eventJson.get(key)
            }
        return this
    }
}

class WebSocketResponse<Data : Json?, Event : WebSocketEvent<Event> ,ActionArguments: Json?>(private var webSocketEvent : WebSocketEvent<Event>?, private var data : Data?, private var action: WebSocketActions<ActionArguments>?) : ServerResponse.Companion.ResponseBuilder() {
    fun getEvent(): Event? {
        return this.webSocketEvent?.getEvent()
    }

    fun setEvent(event: Event) {
        this.webSocketEvent = event
    }

    fun getData(): Data? {
        return this.data
    }

    fun setData(data: Data?) {
        this.data = data
    }

    fun getAction(): WebSocketActions<ActionArguments>? {
        return this.action
    }

    fun setAction(action: WebSocketActions<ActionArguments>?) {
        this.action = action
    }

    override fun toJson() : JSONObject {
        this["event"] = webSocketEvent?.toJson()
        this["data"] = data?.toJson()
        this["action"] = action?.toJson()
        return this
    }
}