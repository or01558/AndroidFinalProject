package com.server.dev.api.responses.errors

import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class LoginErrors {
    companion object {
        val EmptyForm = ServerResponse(
            "Login Data can't be null",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            300,
            "Missing Current User Details",
            "null",
            "{username : String, password : String}"
        )

        val InvalidUser = ServerResponse(
            "Invalid Login Data",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            301,
            "Incorrect username or email",
            "invalid username or email",
            "valid username or email"
        )

        val InvalidPassword = ServerResponse(
            "Invalid Login Data",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            302,
            "Incorrect Password",
            "invalid password",
            "valid password"
        )

        val ProcessingFailed = ServerResponse(
            "Cannot process the request",
            HttpStatus.UNAUTHORIZED,
            ServerResponseTypes.Error,
            303,
            "Invalid Authorization Code",
            "null",
            "valid authorization data"
        )

        val UnknownError =  ServerResponse(
            "Something went wrong.",
            HttpStatus.INTERNAL_SERVER_ERROR,
            ServerResponseTypes.Error,
            304,
            "Unknown",
            "none",
            "none"
        )

        fun MissingUsername(username: String?): ServerResponse {
            return ServerResponse(
                "Invalid Login Data",
                HttpStatus.UNPROCESSABLE_ENTITY,
                ServerResponseTypes.Error,
                305,
                "Missing User's Username",
                username + "",
                "{required: true}"
            )
        }

        fun MissingPassword(password: String?): ServerResponse {
            return ServerResponse(
                "Invalid Login Data",
                HttpStatus.UNPROCESSABLE_ENTITY,
                ServerResponseTypes.Error,
                306,
                "Missing User's Password",
                password + "",
                "{required: true}"
            )
        }
    }
}