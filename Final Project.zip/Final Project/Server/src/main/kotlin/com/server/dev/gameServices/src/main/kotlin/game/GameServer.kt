package com.server.dev.gameServices.src.main.kotlin.game

import com.server.dev.gameServices.src.main.kotlin.structures.WebSocketServer
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.context.annotation.Configuration
import org.springframework.web.socket.config.annotation.EnableWebSocket

@Configuration
@EnableWebSocket
class GameServerConfiguration : WebSocketServer(GameServices.MyFirstGameService, 3000) {}

@SpringBootApplication
class GameServer


fun main(args: Array<String>) {
   try {
      SpringApplication.run(GameServer::class.java, "--server.port = 3000")
   } catch(exception : Exception) {
      exception.printStackTrace()
   }
}