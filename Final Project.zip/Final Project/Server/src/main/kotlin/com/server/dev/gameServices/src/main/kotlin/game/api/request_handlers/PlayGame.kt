package com.server.dev.gameServices.src.main.kotlin.game.api.request_handlers

import com.benasher44.uuid.uuid4
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.server.dev.api.constants.imageColors
import com.server.dev.api.constants.userNames
import com.server.dev.api.database.entities.GameEntity
import com.server.dev.api.database.entities.PlayerEntity
import com.server.dev.api.database.entities.ProfileEntity
import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.game.GameClient
import com.server.dev.api.game.GameDifficulties
import com.server.dev.api.game.Match
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.utils.Ids
import com.server.dev.api.utils.Requests
import com.server.dev.gameServices.src.main.kotlin.enums.ServiceTypes
import com.server.dev.gameServices.src.main.kotlin.game.api.events.game.GameStartEvent
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.Responses
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketActions
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketResponse
import com.server.dev.gameServices.src.main.kotlin.structures.GameRoom
import com.server.dev.gameServices.src.main.kotlin.structures.Service
import com.server.dev.gameServices.src.main.kotlin.structures.WebSocketService
import com.server.dev.games.GuessTheNumber
import org.json.JSONObject
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.web.socket.TextMessage
import java.net.URL
import kotlin.concurrent.thread

private fun getGameEntity(gameId : String) : GameEntity? {
    val responseJSON =
        JSONObject(Requests.send(URL("http://localhost/api/games/get/$gameId"), "", HttpMethod.GET).body as String)
    val response = ServerResponse.createFromJSON(responseJSON)
    var gameEntity: GameEntity? = null
    if (response.status == HttpStatus.OK && response.errorId == null && response.type == ServerResponseTypes.Success) {
        val value = JSONObject(response.value.toString())
        gameEntity = ObjectMapper().readValue(
            value.get("game").toString(),
            GameEntity::class.java
        )
    }
    return gameEntity
}

fun playGame(service: Service, gameClient: GameClient, data: JSONObject) : GameRoom? {
   try {
       if (!data.has("game")) return null

       val gameData: JSONObject = data.getJSONObject("game");

       val gameEntity = getGameEntity(gameData.getString("id")) ?: return null

       if (gameEntity.id != "6308242213402244") return null


       var room: GameRoom? = null
       println("dif ${gameData.getJSONObject("difficulty")}")
       var difficulty = GameDifficulties.valueOf(gameData.getJSONObject("difficulty").getString("name"))

       var allowBots = gameData.getBoolean("allowBots")

       service.gameRooms.forEach { gameRoom ->
           if (gameRoom.gameEntity.id == gameEntity.id) {
               if (gameRoom.match == null && gameRoom.gameClients.size < GuessTheNumber.maxPlayers && gameRoom.allowBots == allowBots && gameRoom.difficulty == difficulty) {
                   println("${gameRoom.allowBots} == $allowBots?")
                   gameRoom.gameClients.add(gameClient)
                   room = gameRoom
               }
           }
       }

       if (room == null) {
           room = GameRoom(gameEntity, mutableListOf(gameClient), allowBots = allowBots, difficulty = difficulty)
           service.gameRooms.add(room!!)
           if (gameData.getString("mode").lowercase() == "multiplayer") {

               val waitingForPlayersThread = Thread {
                   if(room!!.match != null) Thread.currentThread().interrupt()
                   waitForPlayers(gameData, room!!)
               }

               waitingForPlayersThread.start()

               val noPlayersThread =  Thread {
                   if(room!!.match != null) Thread.currentThread().interrupt()
                   Thread.sleep(300000)
                   if (allowBots) {
                         createMatchButFillRoom(gameData, room!!)
                   } else {
                       room?.closed = true
                       service.gameRooms.remove(room)
                       gameClient.webSocketSession?.let { WebSocketService.sendServerResponse(it, Responses.NoPlayersAtAll, ServiceTypes.IndividualDataManager) }
                   }
               }

               noPlayersThread.start()
           } else if (gameData.getString("mode").lowercase() == "singleplayer") createMatchButFillRoom(gameData, room!!)
           else return null
       }

       return room
   } catch (exp : Exception) {
       return null
   }
}

private fun waitForPlayers(gameData : JSONObject, gameRoom: GameRoom) {
    while (!gameRoom.closed && gameRoom.match == null) {
            Thread.sleep(1000)
            if (gameRoom.gameClients.size > 1) {
                gameRoom.gameClients.forEach { gameClient ->
                    if(gameRoom.gameClients.indexOf(gameClient) != (gameRoom.gameClients.size - 1))
                        gameClient.webSocketSession?.let { WebSocketService.sendServerResponse(it, Responses.PlayerJoinedToGameRoom, ServiceTypes.IndividualDataManager) }
                }
                Thread.sleep(10000)
               createMatchButFillRoom(gameData, gameRoom)
            }
        }
    Thread.currentThread().interrupt()
}

fun createMatchButFillRoom(gameData: JSONObject, gameRoom: GameRoom) {
    val game = GuessTheNumber(GameDifficulties.valueOf(gameData.getString("difficulty")))
    val players = mutableListOf<UserEntity>()
    var minimumPlayers = GuessTheNumber.maxPlayers - gameRoom.gameClients.size

    if(!gameData.getBoolean("allowBots") && gameData.getString("mode").lowercase() != "singleplayer") {
      minimumPlayers = 0
    }

    gameRoom.gameClients.forEach { gameClient ->
        players.add(gameClient.userEntity)
    }

    for(i in 1..minimumPlayers) {
         players.add(createFakePlayer())
    }

    val match = Match(game, gameRoom.gameEntity, players, currentMove = -1)
    gameRoom.match = match
    val webSocketResponse = WebSocketResponse(GameStartEvent(game), match, WebSocketActions("initializeGame", 18722, mutableListOf(match)))


    gameRoom.gameClients.forEach {
        it.webSocketSession!!.sendMessage(TextMessage(webSocketResponse.toJson().toString()))
    }
}



var currentBotIndex = 0
val BOT_IDS = mutableListOf<String>(
)

fun createFakePlayer() : UserEntity {

 val botId = generateBotId()
 val botUsername = userNames[currentBotIndex]
 val botImage = "default-${imageColors[currentBotIndex]}"
 val profileEntity = ProfileEntity(botId, botUsername, botImage, botImage, botImage)
 val playerEntity = PlayerEntity(botId, bot = true)

 currentBotIndex++

 return UserEntity(botId, "", botUsername, uuid4().toString(), profileEntity, playerEntity)
}

fun generateBotId() : String {
  var botId = Ids.generateUserId()

  while(BOT_IDS.contains(botId)) {
      botId = Ids.generateUserId()
  }

  BOT_IDS.add(botId)

  return botId
}

