package com.server.dev.api.controllers.users

import com.server.dev.api.extensions.sendResponse
import com.server.dev.api.forms.RegisterForm
import com.server.dev.api.responses.errors.ApiErrors
import com.server.dev.api.responses.errors.RegisterErrors
import com.server.dev.api.services.users.UsersService
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.servlet.ModelAndView


@Controller()
@RequestMapping("/register")
class RegisterController(val usersService: UsersService){

    @GetMapping
    fun render(): ModelAndView {
        return usersService.registerService.render()
    }


    @PostMapping(consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun registerFromExternalSource(@RequestBody registerForm : RegisterForm?): ResponseEntity<*> {
        var form :  RegisterForm = registerForm ?: return ApiErrors.Register.EmptyForm.entity()

        var clientResult = form.getClient()

        if(clientResult as? ServerResponse != null) return clientResult.entity()


        return usersService.registerService.register(form).entity()
    }

    @PostMapping(consumes = [MediaType.APPLICATION_FORM_URLENCODED_VALUE])
    fun register(registerForm : RegisterForm?): ModelAndView {
        val modelAndView = render()
        val model = modelAndView.model
        model["username"] = registerForm?.username
        model["email"] = registerForm?.email
        model["password"] = registerForm?.password

        var form :  RegisterForm = registerForm ?: return modelAndView.sendResponse(RegisterErrors.EmptyForm)
        var response = usersService.registerService.register(form)


        model["response"] = response.toJson().toString()

        return modelAndView
    }



}