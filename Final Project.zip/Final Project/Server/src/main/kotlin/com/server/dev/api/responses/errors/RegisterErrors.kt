package com.server.dev.api.responses.errors

import com.server.dev.api.extensions.isMissingMessage
import com.server.dev.api.extensions.meetRequirementsMessage
import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class RegisterErrors {

    companion object {
        val EmptyForm = ServerResponse("Register Data can't be null",  HttpStatus.BAD_REQUEST, ServerResponseTypes.Error, 400,"Missing New User details","null", "{email : String, username : String, password : String}")
        val UserUsernameExists =  ServerResponse("Can't create new user",  HttpStatus.BAD_REQUEST, ServerResponseTypes.Error, 401,"User with this email already exists", "taken email", "untaken email")
        val UserEmailExists =  ServerResponse("Can't create new user",  HttpStatus.BAD_REQUEST, ServerResponseTypes.Error, 402,"User with this username already exists", "taken username", "untaken username")

        fun InvalidEmail(email : String?): ServerResponse {
            return ServerResponse("Invalid Register Data", HttpStatus.UNPROCESSABLE_ENTITY, ServerResponseTypes.Error, 403,"${email.isMissingMessage()} New User's Email ${email.meetRequirementsMessage()}", email + "", "{required: true, length: StringLength.biggerThan(2)}")
        }

        fun InvalidUsername(username : String?): ServerResponse {
            return ServerResponse("Invalid Register Data", HttpStatus.UNPROCESSABLE_ENTITY, ServerResponseTypes.Error, 404,"${username.isMissingMessage()} New User's Username ${username.meetRequirementsMessage()}", username + "", "{required: true, length: StringLength.biggerThan(2)}")
        }

        fun InvalidPassword(password : String?): ServerResponse {
            return ServerResponse("Invalid Register Data", HttpStatus.UNPROCESSABLE_ENTITY, ServerResponseTypes.Error, 405,"${password.isMissingMessage()} New User's Password ${password.meetRequirementsMessage()}", password + "", "{required: true, length: StringLength.biggerAndEqualThen(8), regexes:[Strings.atLeastOneCharacter(), Strings.atLeastOneNumber()]")
        }
    }

}