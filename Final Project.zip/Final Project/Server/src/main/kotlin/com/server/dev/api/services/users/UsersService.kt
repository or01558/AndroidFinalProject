package com.server.dev.api.services.users

import com.server.dev.api.services.users.auth.UserAuthorizationService
import org.springframework.stereotype.Service


@Service
class UsersService(val registerService: RegisterService, val loginService: LoginService, val logoutService: LogoutService, val authorizationService: UserAuthorizationService) {

}