package com.server.dev.gameServices.src.main.kotlin.game.api.data_structures

import com.server.dev.api.structures.Json

class TextMessage(private var message : String) : Json() {
    fun getMessage(): String {
        return this.message
    }

    fun setMessage(message : String) {
        this.message = message
    }

    override fun declareJSON() {
        this["message"] = message
    }
}