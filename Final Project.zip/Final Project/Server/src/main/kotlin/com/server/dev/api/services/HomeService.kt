package com.server.dev.api.services


import com.server.dev.api.database.repositories.GamesRepository
import com.server.dev.api.extensions.user
import com.server.dev.api.games.GamesLoader
import com.server.dev.api.utils.ServerResources
import org.springframework.stereotype.Service
import org.springframework.web.servlet.ModelAndView
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@Service
class HomeService() {

    fun render(request: HttpServletRequest, response: HttpServletResponse): ModelAndView {
        val mav = ModelAndView()
        mav.viewName = "home"

        mav.model["user"] = request.user

        return mav
    }
}
