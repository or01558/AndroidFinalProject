package com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors

import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class GameClientsErrors {
    companion object {
        val EmptyGameClientData = ServerResponse(
            "Game Client Data can't be null",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            1000,
            "Missing Current Game Client Details",
            "null",
            "{gameClient: { id : String, client : String, playerId: String, webClient: { id: String, secret: String} }}"
        )

        val InvalidGameClient =  ServerResponse(
            "Invalid Game Client's Data",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            1004,
            "Invalid Game's Client",
            "invalid game client's data",
            "valid game client's data",
        )

        val ClientNotConnected =  ServerResponse(
            "Client is not connected!",
            HttpStatus.UNAUTHORIZED,
            ServerResponseTypes.Error,
            1005,
            "The client isn't connected to the game services",
            "unconnected game's client",
            "connected game's client",
        )

        val ClientIsAlreadyConnected =  ServerResponse(
            "Client is already connected to the server!",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            1007,
            "The client is already connected to the game services, You are probably an hacker and wants to connect an existing client to the server.",
            "connected game's client",
            "unconnected game's client",
        )

        val MissingWebClientData = ServerResponse(
            "Invalid Game's Client Data",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            10006,
            "Missing Game Client's Web Client's Data",
            "null",
            "{gameClient: { id : String, client : String, playerId: String, webClient: { id: String, secret: String} }}"
        )

        fun MissingClientId(clientId: String?): ServerResponse {
            return ServerResponse(
                "Invalid Game's Client Data",
                HttpStatus.UNPROCESSABLE_ENTITY,
                ServerResponseTypes.Error,
                1001,
                "Missing Game Client's Id",
                clientId + "",
                "{required: true}"
            )
        }

        fun MissingClientSecret(clientSecret: String?): ServerResponse {
            return ServerResponse(
                "Invalid Game's Client Data",
                HttpStatus.UNPROCESSABLE_ENTITY,
                ServerResponseTypes.Error,
                1002,
                "Missing Game Client's Id",
                clientSecret + "",
                "{required: true}"
            )
        }

        fun MissingPlayerId(playerId: String?): ServerResponse {
            return ServerResponse(
                "Invalid Game's Client Data",
                HttpStatus.UNPROCESSABLE_ENTITY,
                ServerResponseTypes.Error,
                1003,
                "Missing Game Client's Id",
                playerId + "",
                "{required: true}"
            )
        }
    }
}