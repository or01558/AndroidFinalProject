package com.server.dev.api.classes

import com.server.dev.api.utils.RequestBody
import org.springframework.stereotype.Component

@Component
abstract class Form<CrudRepository>(val clientId : String? = null, val clientSecret : String? = null) {

    abstract fun validate(repository: CrudRepository, vararg args: Any): Any

    private fun isValidClient(): Boolean {
        return RequestBody.isValidClient(clientId)
    }

    fun getClient(): Any {
       return RequestBody.getClient(clientId, clientSecret)
    }
}
