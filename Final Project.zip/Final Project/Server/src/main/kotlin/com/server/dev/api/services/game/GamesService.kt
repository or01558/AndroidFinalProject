package com.server.dev.api.services.game

import com.fasterxml.jackson.databind.ObjectMapper
import com.server.dev.api.database.repositories.GamesRepository
import com.server.dev.api.responses.errors.ApiErrors
import com.server.dev.api.security.authorization.clients.Clients
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.structures.ServerResponseTypes
import org.json.JSONArray
import org.json.JSONObject
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service

@Service
class GamesService(val gamesRepository: GamesRepository) {
    fun getGame(gameId: String) : ServerResponse {
        var gameOptional = gamesRepository.findById(gameId)
        if(gameOptional.isEmpty) return ApiErrors.Game.GameNotFound

        val responseBody = JSONObject()
        val objectMapper = ObjectMapper()
        responseBody.put("game", objectMapper.writeValueAsString(gameOptional.get()))

        return ServerResponse("The Game has been Successfuly returned from the server", HttpStatus.OK, ServerResponseTypes.Success, null, "", "{gameId: String, clientId: String, clientSecret: String}", "{gameId: String, clientId: String, clientSecret: String}", responseBody)
    }

    fun getGames() : ServerResponse {
        val games = JSONArray()
        var gamesIterable = gamesRepository.findAll()
        val objectMapper = ObjectMapper()

        gamesIterable.forEach { game ->
            objectMapper.writeValueAsString(game)
        }

        val responseBody = JSONObject()
        responseBody.put("games", games)

        return ServerResponse("The Games have Successfuly returned from the server", HttpStatus.OK, ServerResponseTypes.Success, null, "", "{clientId: String, clientSecret: String}", "{clientId: String, clientSecret: String}", responseBody)
    }
}