package com.server.dev.api.structures

import org.json.JSONObject
import org.springframework.stereotype.Component

@Component
abstract class Json() : JSONObject() {

    override operator fun get(name: String): Any? {
        return super.get(name)
    }

    operator fun set(name: String, value: Any?): Any? {
        this.put(name, value)
        return value
    }

    operator fun set(name : String, value : Empty): Any? {
        this.delete(name)
        return value
    }

    fun delete(name : String) {
        this.remove(name)
    }

    open fun declareJSON() {

    }

   open fun toJson() : JSONObject {
        declareJSON()
        return this
    }

}