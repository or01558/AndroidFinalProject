package com.server.dev.gameServices.src.main.kotlin.game.api.events.game

import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketEvent
import org.json.JSONObject

final class PlayerLeaveEvent : WebSocketEvent<PlayerLeaveEvent>{

    constructor() : super("playerLeave", 187862, null)  {
        setEvent(this)
    }

    override fun getEventJson(): JSONObject {
        return JSONObject()
    }
}