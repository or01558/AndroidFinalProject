package com.server.dev.api.extensions

import com.server.dev.api.structures.ServerResponse
import org.springframework.web.servlet.ModelAndView

fun ModelAndView.sendResponse(response: ServerResponse): ModelAndView {
    model["response"] = response.toJson().toString()
    return this
}