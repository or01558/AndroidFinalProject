package com.server.dev.gameServices.src.main.kotlin.game.api.functions

import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.server.dev.api.game.GameClient
import com.server.dev.api.utils.Requests
import java.net.URL

fun getGameClients(): MutableList<GameClient> {
    val responseEntity = Requests.send(URL("http://localhost/api/game/clients/get"), "")
    val mapper = jacksonObjectMapper()
    return mapper.readValue(responseEntity.body.toString(), mapper.typeFactory.constructCollectionType(
        MutableList::class.java,
        GameClient::class.java
    )) as MutableList<GameClient>
}