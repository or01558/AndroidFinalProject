package com.server.dev.api.forms

import com.server.dev.api.classes.Form
import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.responses.errors.ApiErrors
import com.server.dev.api.responses.errors.ApiErrors.Companion.Register
import com.server.dev.api.structures.ServerResponse
import org.springframework.stereotype.Component

@Component
data class RegisterForm(val email : String? = "", val username : String?= "", val password : String? = ""): Form<UsersRepository>() {

    override fun validate(repository: UsersRepository, vararg args: Any): ServerResponse {
        val letter = Regex("[a-z]", RegexOption.IGNORE_CASE)
        val number = Regex("[0-9]")
        val email  = email
        val username = username
        val password = password

        if(email == null || email.length < 2) return Register.InvalidEmail(email)
        if(repository.findByEmail(email).isNotEmpty()) return Register.UserEmailExists

        if(username == null || username.length < 2) return Register.InvalidUsername(username)
        if(repository.findByUsername(username).isNotEmpty()) return Register.UserUsernameExists

        if(password == null || password.length < 8 || !password.contains(number) || !password.contains(letter)) return Register.InvalidPassword(password)

        return ApiErrors.validationSuccess("Register")
    }

}