package com.server.dev.api.database.repositories

import com.server.dev.api.database.entities.ProfileEntity
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface ProfilesRepository : CrudRepository<ProfileEntity, String> {
}