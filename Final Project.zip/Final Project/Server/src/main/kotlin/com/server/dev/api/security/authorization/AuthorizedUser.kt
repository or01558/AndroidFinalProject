package com.server.dev.api.security.authorization

import com.fasterxml.jackson.databind.ObjectMapper
import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.security.permissions.UserPermissions
import org.json.JSONObject
import org.springframework.stereotype.Component

@Component
data class AuthorizedUser(val user : UserEntity, var scopes : List<Scopes>?, val userToken : String){
    var userJson : JSONObject = JSONObject()

    init {
        loadUserScopes(user)
        val jsonString = toJsonString()

        if(jsonString != null) userJson = JSONObject(jsonString)
        userJson.put("userToken", userToken)
    }

    private fun loadUserScopes(user: UserEntity) {
        var hasUsernameAccess = false
        var hasProfileAccess = false
        var hasPlayerPermission = false
        scopes?.forEach { it ->
            it.permissions.map {
            if(it == UserPermissions.Username) hasUsernameAccess = true
            if(it == UserPermissions.Profile) hasProfileAccess = true
            if(it == UserPermissions.Manage_Player) hasPlayerPermission = true
          }
        }

        user.email = "#encrypted";
        user.password = "#value$${user.password.length}:encrypted";

        if(!hasUsernameAccess) user.username = null
        if(!hasProfileAccess)  user.profile = null
        if(!hasPlayerPermission) user.player = null
    }

    private fun toJsonString(): String? {
        val objectMapper = ObjectMapper()
        return objectMapper.writeValueAsString(user)
    }
}
