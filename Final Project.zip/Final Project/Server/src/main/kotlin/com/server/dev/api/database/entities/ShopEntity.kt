package com.server.dev.api.database.entities

import javax.persistence.*

@Entity
@Table(name = "shops")
data class ShopEntity(@Id val id : String,
                      @ManyToMany(fetch = FetchType.EAGER)
                      @JoinColumn(name="shopId", nullable = false, insertable = false, updatable = false)
                      val items : MutableList<ItemEntity>) {
    constructor() : this("", mutableListOf())
}