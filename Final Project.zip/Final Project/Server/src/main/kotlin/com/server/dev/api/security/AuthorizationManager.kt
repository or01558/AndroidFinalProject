package com.server.dev.api.security

import com.server.dev.api.extensions.contains
import com.server.dev.api.extensions.sha256
import com.server.dev.api.security.authorization.Authorization
import com.server.dev.api.security.authorization.AuthorizationCode
import com.server.dev.api.security.authorization.RefreshTokenAuthorization
import com.server.dev.api.security.authorization.ResponseTypes.AccessToken
import com.server.dev.api.security.authorization.ResponseTypes.RefreshToken
import com.server.dev.api.security.authorization.Scopes
import com.server.dev.api.security.authorization.clients.Clients
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.json.JSONObject
import org.springframework.stereotype.Component
import java.util.*
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import kotlin.random.Random.Default.nextInt

@Component
data class TokenData(val userId : String, val scopes : List<Scopes>){
}

@Component
class AuthorizationManager {

    companion object {

        private val Symbols: List<String> = listOf("!", "@", "#", "$", "%", "^", "&", "*", "|", "<", ">", "?")

        private val authorizationCodes = HashMap<String, MutableList<AuthorizationCode>>()

        fun generateAuthorizationCode(authorization: Authorization, client: Clients): String {
            val hash = "${client.id}:${client.secret}".sha256()
            val userId = authorization.userId ?: ""

            val scopes = authorization.scopes
            var code = generateAuthorizationCode()
            val authorizationCode = AuthorizationCode(userId, scopes, code)
            val codes = authorizationCodes[hash] ?: mutableListOf()

            val authCodeExpiredThread = Thread {
                Thread.sleep(300000)
                codes.remove(authorizationCode)
                Thread.currentThread().interrupt()
            }

            authCodeExpiredThread.start()
            codes.add(authorizationCode)
            authorizationCodes[hash] = codes

            return code
        }

        private fun generateRandomChar(containsLetter : Boolean, containsNumber : Boolean, containsSymbol : Boolean)  : Any {
            var identifier = 0

            if(!containsNumber && !containsLetter && !containsSymbol || containsNumber && containsLetter && containsSymbol) identifier = nextInt(1, 3)

            else if (containsNumber) {
                identifier = if(!containsLetter && !containsSymbol) nextInt(2, 3)
                else if(!containsLetter) 2
                else 3
            } else if (containsLetter) {
                identifier = if(!containsSymbol && !containsNumber) {
                    val r = Math.random().roundToInt()
                    if(r == 0) 1
                    else 3
                }
                else if(!containsSymbol) 3
                else 1
            } else if (containsSymbol) {
                identifier = if(!containsLetter && !containsNumber) nextInt(1, 2)
                else if(!containsLetter) 2
                else 1
            }


           return when (identifier) {
               1 -> generateRandomNumber()
               2 -> generateRandomLetter()
               else -> generateRandomSymbol()
           }

        }

        private fun generateAuthorizationCode() : String {
            var code = ""

            for(i in 0 until 16) {
                var containsLetter = code.contains(Regex("[a-z]"))
                var containsNumber = code.contains(Regex("[0-9]"))
                var containsSymbol = code.contains(Symbols)
                var char = generateRandomChar(containsLetter, containsNumber, containsSymbol)

                code += char
            }

            return code
        }

        private fun generateRandomSymbol(): Any {
            val randomIndex = nextInt(0, Symbols.size)
            return Symbols.get(randomIndex)
        }

        private fun generateRandomLetter(): Char {
           return nextInt(97, 122).toChar()
        }

        private fun generateRandomNumber(): Int {
           return nextInt(1, 9)
        }

        fun getAuthorizationInfo(code : String, client : Clients) : Authorization? {
            val hash = "${client.id}:${client.secret}".sha256()
            val authorizationCodes = authorizationCodes[hash] ?: return null
            val authorizationCode = authorizationCodes.find {
                it.code == code
            } ?: return null

            return Authorization.fromAuthorizationCode(authorizationCode, client)
        }

        fun generateToken(authorization : Authorization, client : Clients) : String? {
           return when(authorization.responseType){
             AccessToken -> generateAccessToken(authorization, client)
             RefreshToken -> generateRefreshToken(authorization, client)
             else -> null
           }
        }

        private fun generateAccessToken(authorization : Authorization, client : Clients): String? {
            val userId = authorization.userId ?: return null
            val claims : HashMap<String, Any> = HashMap();
            claims["userId"] = "\"$userId\""
            claims["scopes"] = authorization.scopes.map {
                it.name
            }
            val exp = Date()
            exp.time = exp.time + 300000

            return Jwts.builder().setClaims(claims as Map<String, Any>?).signWith(SignatureAlgorithm.HS256, client.secret)
                .setExpiration(exp).compact()
        }

        private fun generateRefreshToken(authorization : Authorization, client : Clients): String? {
            val userId = authorization.userId ?: return null
            val claims : HashMap<String, Any> = HashMap();
            claims["userId"] = "\"$userId\""
            claims["scopes"] = authorization.scopes.map {
                it.name
            }
            val exp = Date()
            exp.time = exp.time + 300000
            return Jwts.builder().setClaims(claims as Map<String, Any>?).signWith(SignatureAlgorithm.HS256, client.secret)
             .compact()
        }

        fun createAccessTokenFrom(authorization: RefreshTokenAuthorization, client: Clients): String? {

            val tokenData = authorization.refresh_token?.let { getTokenData(it, client) } ?: return null

            authorization.userId = tokenData.userId
            authorization.scopes = tokenData.scopes

            return generateAccessToken(authorization, client)

        }

        fun getTokenData(token : String, client: Clients): TokenData? {
          try {
              var data = Jwts.parser().setSigningKey(client.secret).parse(token)
              val json = JSONObject(data.body.toString())
              val userId = json.getString("userId")
              val scopesArray = json.getJSONArray("scopes")
              val scopes = mutableListOf<Scopes>()

              for (i in 0 until scopesArray.length()) {
                  val name = scopesArray.getString(i)
                  val scope = Scopes.get(name)
                  if(scope != null) scopes.add(scope)
              }

              return TokenData(userId, scopes.toList())
          } catch(e: Exception) {
              return null
          }

        }

        fun getAuthorizationCode(token: String, client: Clients): String? {
            val hash = "${client.id}:${client.secret}".sha256()
            val tokenData = getTokenData(token, client)
            val codes = authorizationCodes[hash]
            var code : String? = null
            codes?.forEach {
                if(it.userId == tokenData?.userId) code = it.code
            }

           return code
        }
    }

}

