@file:JvmName("Empty")

package com.server.dev.api.structures

import org.springframework.stereotype.Component

@Component
class Empty(){
}