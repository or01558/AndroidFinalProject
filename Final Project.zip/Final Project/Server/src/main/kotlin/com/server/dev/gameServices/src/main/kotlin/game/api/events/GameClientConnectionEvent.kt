package com.server.dev.gameServices.src.main.kotlin.game.api.events

import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketEvent
import org.json.JSONObject
import org.springframework.web.socket.WebSocketSession


final class GameClientConnectionEvent: WebSocketEvent<GameClientConnectionEvent>{
    private val test : String = "test"
    private val webSocketSession: WebSocketSession

    constructor(webSocketSession: WebSocketSession) : super("webSocketConnection", 191837413, null) {
        this.webSocketSession = webSocketSession
        setEvent(this)
    }

    override fun getEventJson(): JSONObject {
        val json = JSONObject()
        json.put("test", test)
        return json
    }
}