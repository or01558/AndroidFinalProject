package com.server.dev.api.game

import com.server.dev.api.security.authorization.clients.Clients
import org.springframework.stereotype.Component

@Component
class GameClientData(private val accessToken: String?, private val refreshToken: String?, private val webClient : Clients?) {

    fun getAccessToken() : String? {
        return accessToken
    }

    fun getRefreshToken() : String? {
        return refreshToken
    }

    fun getWebClient() : Clients? {
        return webClient
    }
}