package com.server.dev.api.security.users.auth

import org.springframework.stereotype.Component

@Component
data class UserAuthorization(val accessToken : String?, val refreshToken : String?, val clientId: String?, val clientSecret: String?)
