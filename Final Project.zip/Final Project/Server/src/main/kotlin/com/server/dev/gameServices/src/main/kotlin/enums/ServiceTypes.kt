package com.server.dev.gameServices.src.main.kotlin.enums

import org.springframework.stereotype.Component

@Component
enum class ServiceTypes {
    DataReceiver, // used for receiving data to updating it on the server side. (common way to update an internal storage from external source)
    DataSender, //used for send data to the client side when needed like being able to update things on the client side when they get updated on the server side. (common way to update the client side information, so It will match to the same information the being stored on the server side)
    DataAnalyser, //A layer above DataReceiver type, used for validating the data being sent and for doing certain actions on the server based on the data object. (common way for managing the services via external source)
    DataEmitter,//A layer above DataSender type, used for sending events to the client side in a way that if some even occurred on the server He will happen on the client too, this is a common way to make real time chat based application.
    IndividualDataManager, //can contain all types of service at once without having any issues with service types that being conflicted with others. (common way to make a real game with security, admin management, developer management and a multiplayer mode)
}