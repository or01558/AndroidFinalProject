package com.server.dev.gameServices.src.main.kotlin.game.api.events.client

import com.fasterxml.jackson.databind.ObjectMapper
import com.server.dev.api.game.GameClient
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketEvent
import org.json.JSONObject

final class GameClientConnectionEvent: WebSocketEvent<GameClientConnectionEvent>{
    private val gameClient : GameClient


    constructor(gameClient : GameClient) : super("gameClientConnection", 1727201, null) {
        this.gameClient = gameClient
        setEvent(this)
    }

    override fun getEventJson(): JSONObject {
        val json = JSONObject()
        json.put("id", gameClient.id)
        json.put("secret", gameClient.secret)
        json.put("user", convertUserEntityToUserJson())
        json.put("isConnectedToGameServices", gameClient.isConnectedToGameServices)
        return json
    }


    private fun convertUserEntityToUserJson() : JSONObject {
        val objectMapper = ObjectMapper()
        return JSONObject(objectMapper.writeValueAsString(gameClient.userEntity))
    }
}
