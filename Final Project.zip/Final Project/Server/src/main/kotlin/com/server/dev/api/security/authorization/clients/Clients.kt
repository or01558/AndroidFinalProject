package com.server.dev.api.security.authorization.clients

import com.fasterxml.jackson.annotation.JsonCreator
import com.fasterxml.jackson.annotation.JsonFormat
import com.fasterxml.jackson.annotation.JsonProperty
import org.springframework.stereotype.Component

@Component
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
enum class Clients(val id : String, val secret : String) {
     WEBSITE_CLIENT("3b99f2b3-f531-45ef-a955-80d08a6c01ce", "41f3fc62-fd2b-4da8-a1cb-3ff7fa5a7a84"),
     PC_CLIENT("e5aacfd9-9366-46bc-ae5f-ac8425c24f0f", "bce67f39-116b-4602-a20d-ab1791b8851e"),
     APP_CLIENT("f88da1cc-6b3c-405e-99a4-fefb01553b7f", "e906a5f7-c30a-403e-a02b-7d772daadf60");
    companion object {
         @JvmStatic
         @JsonCreator
         fun forValues(
              @JsonProperty("id") id: String,
              @JsonProperty("secret") secret: String
         ): Clients? {
              for (client in Clients.values()) {
                   if (client.id == id && client.secret == secret) {
                        return client
                   }
              }
              return null
         }

         fun has(clientId: String): Boolean {
              for (client in values()) {
                   if (client.id == clientId) return true
              }
              return false
         }

         fun get(clientId: String): Clients? {
              for(client : Clients in values()) {
                if(client.id == clientId) return client
              }
              return null
         }
}
}
