package com.server.dev.api.middlewares

import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.extensions.user
import com.server.dev.api.utils.ServerResources
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.annotation.Order
import org.springframework.stereotype.Component
import org.springframework.web.util.WebUtils
import java.io.IOException
import javax.servlet.*
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse


class UserLoader(@Autowired val usersRepository: UsersRepository? = null) : Filter {

    @Throws(IOException::class, ServletException::class)
    override fun doFilter(
        request: ServletRequest,
        response: ServletResponse?,
        chain: FilterChain
    ) {
        println("test")
        val req = request as HttpServletRequest
        val res = response as HttpServletResponse

        if (req.requestURL.contains("/api") || req.requestURL.contains("/logout") || req.requestURL.contains("/login/process")) return chain.doFilter(req, res)

        var accessTokenCookie = WebUtils.getCookie(req, "u_a_t")
        val refreshTokenCookie = WebUtils.getCookie(req, "u_r_t")
        if (accessTokenCookie == null || refreshTokenCookie == null || accessTokenCookie.value == null || refreshTokenCookie.value == null) return chain.doFilter(
            req,
            res
        )

        val refreshToken = refreshTokenCookie.value
        var accessToken = accessTokenCookie.value

        if(usersRepository == null) return chain.doFilter(request, response)

        val authorizedUser = ServerResources.authorizeUser(usersRepository!!, accessToken, refreshToken)
            ?: return chain.doFilter(request, response)
        val userToken = authorizedUser.userToken

        if (!(accessToken.equals(userToken))) {
            accessTokenCookie.value = userToken
            accessTokenCookie.path = "/"
            res.addCookie(accessTokenCookie)
        }

        request.user = authorizedUser.userJson.toString()


        chain.doFilter(request, response)
    }



}
