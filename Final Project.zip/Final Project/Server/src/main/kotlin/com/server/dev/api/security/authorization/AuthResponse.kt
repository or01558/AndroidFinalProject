package com.server.dev.api.security.authorization

import com.server.dev.api.structures.Json
import com.server.dev.api.structures.RequestURL
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.utils.ServerResources
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Component

@Component
class AuthResponse(
    var redirectUrl: RequestURL? = null,
    var error: Boolean = false,
    var errorMessage: ServerResponse? = null,
    var code: String? = null,
    var responseEntity: ResponseEntity<*>? = null,
    var token: String? = null,
    var responseType: ResponseTypes? = null,
    var clientId: String? = null,
    var clientSecret: String? = null
) : Json() {

    fun setErrorMessage(errorMessage: ServerResponse?): AuthResponse {
        this.errorMessage = errorMessage
        this.error = true
        return this
    }

    fun getBody(): String {
        return responseEntity?.body?.toString() ?: this.toJson().toString()
    }

    fun setCode(code: String): AuthResponse {
        this.code = code
        return this
    }

    fun setResponseEntity(responseEntity: ResponseEntity<*>): AuthResponse {
        this.responseEntity = responseEntity
        return this
    }

    fun setToken(token: String?): AuthResponse {
        this.token = token
        return this
    }

    fun setResponseType(responseType: ResponseTypes?): AuthResponse {
        this.responseType = responseType
        return this
    }

    fun getAsURL(): String? {
      return if(redirectUrl != null){
          val url = redirectUrl as RequestURL
          val json = this.toJson()
          val auth = ServerResources.createJwtFrom(json)

          url.addQueryParameter("auth", auth)

          return url.toString()
       }else null
    }

     override fun declareJSON(){
        this["redirectUrl"] =  redirectUrl?.toJson()
        this["error"] = error
        this["errorMessage"] = errorMessage?.toJson()
        this["code"] = code
        this["token"] = token
        this["responseType"] = responseType?.toString()
        this["clientId"] = clientId
        this["clientSecret"] = clientSecret
     }
}


