package com.server.dev.api.controllers.users

import com.server.dev.api.extensions.sendResponse
import com.server.dev.api.extensions.user
import com.server.dev.api.forms.LoginForm
import com.server.dev.api.responses.errors.ApiErrors
import com.server.dev.api.responses.errors.LoginErrors
import com.server.dev.api.security.authorization.clients.Clients
import com.server.dev.api.services.HomeService
import com.server.dev.api.services.users.UsersService
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.utils.ServerResources
import org.springframework.http.*
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.*
import org.springframework.web.servlet.ModelAndView
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse


@Controller()
@RequestMapping("/login")
class LoginController(val homeService: HomeService, val usersService: UsersService) {

    @GetMapping
    fun render(request: HttpServletRequest, response: HttpServletResponse): ModelAndView {
        if (request.user.isNotEmpty()) return homeService.render(request, response)
        return usersService.loginService.render()
    }


    @PostMapping(consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun loginFromExternalSource(@RequestBody loginForm: LoginForm?): ResponseEntity<*> {
        var form : LoginForm = loginForm ?: return ApiErrors.Login.EmptyForm.entity()

        var clientResult = form.getClient()

        if(clientResult as? ServerResponse != null) return clientResult.entity()

        var client : Clients = clientResult as Clients


        val result = usersService.loginService.login(form, client, fromWebsite = false)
        if(result as? ServerResponse != null) return result.entity()
        return result as ResponseEntity<*>
    }


    @PostMapping(consumes = [MediaType.APPLICATION_FORM_URLENCODED_VALUE])
    fun loginFromWebsite(loginForm: LoginForm?, request: HttpServletRequest, response : HttpServletResponse): Any {
        val modelAndView =  usersService.loginService.render()
        val model = modelAndView.model
        model["username"] = loginForm?.username
        model["password"] = loginForm?.password

        var form : LoginForm = loginForm ?: return modelAndView.sendResponse(LoginErrors.EmptyForm)

        val result =  usersService.loginService.login (
            form,
            Clients.WEBSITE_CLIENT,
            fromWebsite = true
        )

        if(result as? ServerResponse != null)
            return modelAndView.sendResponse(result)

        return result as ResponseEntity<*>
    }

    @GetMapping(value = ["/process"])
    fun process(@RequestParam(required=false, name="auth") auth : String, request : HttpServletRequest, response : HttpServletResponse): Any {
      val jsonObject = ServerResources.getJsonFrom(auth)
      return usersService.loginService.process(jsonObject, request, response)
    }




}