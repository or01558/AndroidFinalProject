package com.server.dev.api.controllers.users

import com.server.dev.api.security.authorization.AuthResponse
import com.server.dev.api.security.users.auth.UserAuthorization
import com.server.dev.api.services.users.UsersService
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@RestController()
@RequestMapping("/api/users")

class UserAuthorizationController(val usersService: UsersService) {

    @PostMapping("/authorize")
    fun authorize(
        @RequestBody userAuth: UserAuthorization?,
        request: HttpServletRequest,
        response: HttpServletResponse
    ): ResponseEntity<*> {
        return usersService.authorizationService.authorizeUser(userAuth)
    }

    @PostMapping("/create-authorization", consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun createAuthorization(
        @RequestBody authResponse: AuthResponse?,
        request: HttpServletRequest,
        response: HttpServletResponse
    ): ResponseEntity<*> {
        return usersService.authorizationService.createAuthorization(authResponse)
    }
}