package com.server.dev.api.services.users

import com.server.dev.api.database.entities.PlayerEntity
import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.database.entities.ProfileEntity
import com.server.dev.api.database.repositories.PlayersRepository
import com.server.dev.api.database.repositories.ProfilesRepository
import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.extensions.sha256
import com.server.dev.api.forms.RegisterForm
import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.utils.Ids
import com.server.dev.api.structures.ServerResponse
import org.springframework.stereotype.Service
import org.springframework.web.servlet.ModelAndView



@Service
class RegisterService(val usersRepository: UsersRepository, val profilesRepository: ProfilesRepository, val playersRepository: PlayersRepository) {

    fun render(): ModelAndView {
        val mav = ModelAndView()
        mav.viewName = "register"
        return mav
    }

    fun register(registerForm : RegisterForm): ServerResponse {
        val message = registerForm.validate(usersRepository)
        if(message.type == ServerResponseTypes.Error) return message

        var id = Ids.generateUserId()

        while(usersRepository.existsById(id)) {
            id = Ids.generateUserId()
        }

        val defaultPlayer = PlayerEntity(id)
        val defaultProfile = ProfileEntity(id)

        profilesRepository.save(defaultProfile)
        playersRepository.save(defaultPlayer)
        val userEntity = UserEntity(id, registerForm.email as String, registerForm.username as String, (registerForm.password as String).sha256(), defaultProfile, defaultPlayer)
        usersRepository.save(userEntity)
        return ServerResponse("User successfully created")
    }


}