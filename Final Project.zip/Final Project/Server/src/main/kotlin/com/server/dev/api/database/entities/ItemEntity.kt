package com.server.dev.api.database.entities

import javax.persistence.Entity
import javax.persistence.Id
import javax.persistence.Table


@Entity
@Table(name = "items")
data class ItemEntity(var name : String, @Id var id: String, var title : String, var description: String, var price : Int, var shopId : String, var amount: Int = 1, var usesPerOne: Int = 1) {
    constructor() : this("", "", "", "", 0, "")
}