package com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors

import com.server.dev.api.structures.ServerResponse
import org.springframework.stereotype.Component

@Component
class Errors {
    companion object
    {
        val GameClients = GameClientsErrors
        val RequestData = RequestDataErrors
        val GameErrors = GameDataErrors

        fun validationSuccess(name : String): ServerResponse {
            return ServerResponse("$name Validation Succeed")
        }
    }
}