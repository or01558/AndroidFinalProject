package com.server.dev.api.services.game

import com.server.dev.api.constants.gameClients
import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.game.GameClient
import com.server.dev.api.game.GameClientData
import com.server.dev.api.game.GameClientInformation
import com.server.dev.api.responses.errors.ApiErrors
import com.server.dev.api.security.authorization.AuthorizedUser
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.utils.ServerResources
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import com.server.dev.api.structures.ServerResponseTypes.Success
import org.json.JSONObject

@Service
class ClientsService(val usersRepository: UsersRepository) {

    fun connect(gameClientData: GameClientData): Any {
        val webClient = gameClientData.getWebClient()
            ?: return com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors.Errors.GameClients.MissingWebClientData
        val accessToken = gameClientData.getAccessToken() ?: return ApiErrors.UserAuth.MissingAccessToken
        val refreshToken = gameClientData.getRefreshToken() ?: return ApiErrors.UserAuth.MissingRefreshToken
        val authorizedUser: AuthorizedUser =
            ServerResources.authorizeUser(usersRepository, accessToken, refreshToken, webClient)
                ?: return ApiErrors.UserAuth.InvalidUser

        val id: String = GameClient.generateClientId()
        val secret: String = GameClient.generateClientSecret()
        val userEntity: UserEntity = authorizedUser.user
        val gameClient = GameClient(id, secret, userEntity)

        gameClients.add(gameClient)
        val responseBody = JSONObject()
        responseBody.put("gameClient", gameClient.toJson())

        return ServerResponse(
            "Game client created",
            HttpStatus.OK,
            Success,
            null,
            "",
            "valid game client data",
            "valid game client data",
            responseBody
        ).entity()
    }

    fun disconnect(gameClientInformation: GameClientInformation): Any {
        val id = gameClientInformation.getId() ?: return com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors.Errors.GameClients.MissingClientId(gameClientInformation.getId())
        val secret = gameClientInformation.getSecret() ?: return com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors.Errors.GameClients.MissingClientSecret(gameClientInformation.getSecret())
        val playerId = gameClientInformation.getPlayerId() ?: return com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors.Errors.GameClients.MissingPlayerId(gameClientInformation.getPlayerId())

        gameClients.removeIf {
            it.id == id && it.secret == secret && (it.userEntity.player?.userId == playerId)
        }

        val responseBody = JSONObject()

        return ServerResponse(
            "Game client removed",
            HttpStatus.OK,
            Success,
            null,
            "",
            "valid game client information",
            "valid game client information",
            responseBody
        ).entity()
    }
}