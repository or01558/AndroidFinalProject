package com.server.dev.api.responses.errors

import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class AuthorizationErrors {
    companion object {

        val EmptyBody = ServerResponse(
            "Authorization Data can't be null",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            500,
            "Missing authorization details",
            "null",
            "Authorization::instance"
        )

        val MissingGrantType = ServerResponse(
            "Cannot process the authorization",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            501,
            "Invalid Grant Type",
            "null",
            "client auth, code auth or refresh token auth",
        )

        val InvalidAuthCode =  ServerResponse(
            "Invalid Authorization Data",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            502,
            "Invalid Authorization Code",
            "null",
            "Valid authorization code",
        )

        val TokenISNULL =  ServerResponse(
            "Something went wrong",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            503,
            "Token is null",
            "null",
            "token"
        )

        fun invalidResponseType(got : String = "null", type: String): ServerResponse {
            return ServerResponse(
                "Invalid Authorization Data",
                HttpStatus.UNPROCESSABLE_ENTITY,
                ServerResponseTypes.Error,
                504,
                "Invalid Response Type",
                got,
                type,
            )
        }

        fun invalidUserId(userId: String?): ServerResponse {
            return ServerResponse(
                "Invalid Authorization Data",
                HttpStatus.UNPROCESSABLE_ENTITY,
                ServerResponseTypes.Error,
                505,
                "Invalid user id",
                userId + "",
                "valid user id"
            )
        }

    }
}