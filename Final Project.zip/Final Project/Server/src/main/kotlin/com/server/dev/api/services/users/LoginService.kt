package com.server.dev.api.services.users

import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.extensions.createCookie
import com.server.dev.api.forms.LoginForm
import com.server.dev.api.responses.errors.LoginErrors
import com.server.dev.api.security.authorization.clients.Clients
import com.server.dev.api.services.HomeService
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.security.authorization.*
import com.server.dev.api.utils.Requests
import org.json.JSONObject
import org.springframework.http.*
import org.springframework.stereotype.Service
import org.springframework.web.servlet.ModelAndView
import com.server.dev.api.structures.RequestURL
import org.springframework.web.servlet.view.RedirectView
import java.net.URL
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse


@Service
class LoginService(val homeService: HomeService, val usersRepository: UsersRepository) {

    fun render(): ModelAndView {
        val mav = ModelAndView()
        mav.viewName = "login"
        return mav
    }


    fun login(loginForm: LoginForm, client: Clients, redirectURL: String? = null, fromWebsite: Boolean): Any {

        val validationResult = loginForm.validate(usersRepository)
        if (validationResult is ServerResponse) return validationResult
        return login(validationResult as UserEntity, client, redirectURL, fromWebsite)
    }

    fun login(user: UserEntity, client: Clients, redirectURL: String? = null, fromWebsite: Boolean): ResponseEntity<*> {
       val auth =  createClientAuthorization(user, client, redirectURL, fromWebsite)
        return Requests.send(
            URL("http://localhost/api/oauth2/redirect"),
           auth.toJson().toString()
        )
    }

    fun process(auth: JSONObject, request: HttpServletRequest, response: HttpServletResponse): Any {
        val responseType = ResponseTypes.getByName(auth.get("responseType") as String?)
        if (auth.get("error") == true) return LoginErrors.UnknownError.entity()
        if (!auth.isNull("code") && responseType == ResponseTypes.Code) {
            val responseEntity = Requests.send(
                URL("http://localhost/api/users/create-authorization"),
                auth.toString()
            )

            val responseJSON = JSONObject(responseEntity.body.toString())
            val serverResponse = ServerResponse.createFromJSON(responseJSON)

            if(serverResponse.status == HttpStatus.OK && serverResponse.statusCode == 200 && serverResponse.type == com.server.dev.api.structures.ServerResponseTypes.Success){
               performLoginSuccess(response, serverResponse)
               return RedirectView("/");
            }

            return serverResponse

        } else return LoginErrors.ProcessingFailed.entity()

        //return ServerResponse("Processing User Login Action...", HttpStatus.PROCESSING).entity()
    }

    private fun createClientAuthorization(
        user: UserEntity,
        client: Clients,
        redirectURL: String? = null,
        fromWebsite: Boolean
    ): ClientAuthorization {
        var redirect = redirectURL?.let { RequestURL(redirectURL) }
        if (redirect == null && fromWebsite) redirect = RequestURL("http://localhost/login/process")
        else if(redirect == null) redirect = RequestURL("http://localhost/api/users/create-authorization")
        val authorization = ClientAuthorization(redirect)
        authorization.clientId = client.id
        authorization.clientSecret = client.secret
        authorization.responseType = ResponseTypes.Code
        authorization.userId = user.id
        authorization.scopes = listOf(Scopes.Identity, Scopes.ManagePlayer)
        if (fromWebsite) authorization.redirectMethod = HttpMethod.GET
        return authorization
    }

    private fun performLoginSuccess(clientResponse: HttpServletResponse, serverResponse: ServerResponse) {
        val responseValue : JSONObject = serverResponse.value as JSONObject
        val accessToken : String = responseValue.getString("accessToken")
        val refreshToken : String = responseValue.getString("refreshToken")
        clientResponse.createCookie("u_a_t", accessToken)
        clientResponse.createCookie("u_r_t", refreshToken)
    }

}


