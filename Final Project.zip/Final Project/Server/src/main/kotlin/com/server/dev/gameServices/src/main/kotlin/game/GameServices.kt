package com.server.dev.gameServices.src.main.kotlin.game

import org.springframework.stereotype.Component

@Component
class GameServices {
  companion object {
      val MyFirstGameService : MyFirstGameService = MyFirstGameService()

  }
}