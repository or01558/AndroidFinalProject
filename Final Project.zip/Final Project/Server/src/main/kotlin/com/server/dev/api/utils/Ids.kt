package com.server.dev.api.utils

import org.springframework.stereotype.Component
import kotlin.random.Random

@Component
class Ids {

    companion object {
        private const val USER_ID_LENGTH = 16

        fun generateUserId() : String {
            var id = ""

            for(i in 0 until USER_ID_LENGTH) {
                id += Random.nextInt(0, 9)
            }

            return id
        }
    }
}