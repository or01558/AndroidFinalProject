package com.server.dev.api.structures

import org.json.JSONObject
import org.springframework.stereotype.Component
import java.net.URL

@Component
class QueryParams(var queryString: String) : Json() {

    init {
        val queryParams =  queryString.split("&")
        for(param in queryParams) {
            val keyValueParts = param.replace("?", "").split("=")
            if(keyValueParts.size == 2){
                val key = keyValueParts[0]
                val value = keyValueParts[1]
                this.add(key, value)
            }
        }
    }

    fun add(name: String, value: Any?) : QueryParams {
        if(value == null || (value is String && value.isEmpty())) return this
        this[name] = value.toString()
        val char = if(queryString.isNotEmpty()) "&" else "?"
        queryString = "$char$name=$value"
        return this
    }

    override fun remove(name: String) : QueryParams {
        var lastIndex = 0
        val lastLength = name.length + 2
        val i = queryString.indexOf("$name=")
        val beforeIndex = i -1
        val char = if(beforeIndex == 0 ) "?" else "&"
        var value = ""

        for(j in 1 until lastLength) {
            lastIndex++
        }

        loop@ for(j in (lastIndex + 1) until queryString.length){
            if(queryString[j] == '&') break@loop
            value += queryString[j]
        }

        queryString = queryString.replace("$char$name?=$value", "")
        this.delete(name)
        return this
    }

    override fun declareJSON() {
        this["queryString"] = queryString
    }

    override fun toString(): String {
        return queryString
    }
}

@Component
class RequestURL(var url : String?) : Json() {
    private var protocol: String = ""
    private var host: String = ""
    private var port: Int = 80
    private var path: String = "/"
    private var query: QueryParams = QueryParams("")

    init {
        parse()
    }

    fun addQueryParameter(name: String, value: Any?): RequestURL {
        this.query.add(name, value)
        return this
    }

    fun removeQueryParameter(name: String): RequestURL {
        this.query.remove(name)
        return this
    }

    override fun toString(): String {
        return "$protocol://${host}${if (port == 80) "" else ":$port"}${path}${query}"
    }

    private fun parse() {
        if (url is String) {
            val urlObject = URL(url)
            protocol = urlObject.protocol
            host = urlObject.host
            if (urlObject.port != -1) port = urlObject.port
            path = urlObject.path
            query = QueryParams(urlObject.query ?: "")
        }

    }

    override fun declareJSON() {
        this["url"] = url
        this["protocol"] = protocol
        this["host"] = host
        this["port"] = port
        this["path"] = path
        val queryJSON: JSONObject? = query?.toJson()
        this["query"] = queryJSON
    }
}