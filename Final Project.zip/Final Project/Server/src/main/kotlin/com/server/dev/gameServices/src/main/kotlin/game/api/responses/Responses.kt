package com.server.dev.gameServices.src.main.kotlin.game.api.responses

import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.structures.ServerResponseTypes
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class Responses {
    companion object {
        val GameRoomCreated = ServerResponse(
            "Game Room has successfully created! Now You just need to wait for other players to join!",
            HttpStatus.OK,
            ServerResponseTypes.Success,
        )

        val YouJoinedToGameRoom = ServerResponse(
            "You have been successfully joined to an existing game room! Now You just need to wait for three minutes for extra players to join!",
            HttpStatus.OK,
            ServerResponseTypes.Success,
        )

        val PlayerJoinedToGameRoom = ServerResponse(
            "A player has joined your game room! The game will start in three minutes! \n Waiting for extra players to join the game...",
            HttpStatus.OK,
            ServerResponseTypes.Success,
        )


        val NoPlayersAtAll = ServerResponse(
            "No Players are online right now and You have decided to disable the game bots at all! \nPlease try again later...",
            HttpStatus.CONFLICT,
            ServerResponseTypes.Unknown,
        )
    }
}