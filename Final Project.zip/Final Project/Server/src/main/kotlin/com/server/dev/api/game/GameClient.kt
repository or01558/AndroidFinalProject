package com.server.dev.api.game

import com.benasher44.uuid.uuid4
import com.fasterxml.jackson.databind.ObjectMapper
import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.structures.Json
import com.server.dev.gameServices.src.main.kotlin.game.GameServices
import org.json.JSONObject
import org.springframework.stereotype.Component
import org.springframework.web.socket.WebSocketSession
import kotlin.random.Random

@Component
data class GameClient(val id : String, val secret: String, val userEntity: UserEntity, var isConnectedToGameServices: Boolean = false, var webSocketSession: WebSocketSession? = null) :
    Json() {
    companion object {
        private const val ID_LENGTH = 16

        fun generateClientId(): String {
            var id = ""

            do {
                for (i in 0 until ID_LENGTH) {
                    id += Random.nextInt(0, 9)
                }

            } while (GameServices.MyFirstGameService.isGameClientExistsById(id))

            return id
        }

        fun generateClientSecret(): String {
            var secret = ""

            do {
            } while (GameServices.MyFirstGameService.isGameClientExistsBySecret(secret))

                    secret = uuid4().toString()

            return secret
        }

    }

    override fun toJson() : JSONObject {
        val objectMapper = ObjectMapper()
        return JSONObject(objectMapper.writeValueAsString(this))
    }
}