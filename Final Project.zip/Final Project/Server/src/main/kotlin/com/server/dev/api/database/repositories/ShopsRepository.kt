package com.server.dev.api.database.repositories

import com.server.dev.api.database.entities.ShopEntity
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface ShopsRepository : CrudRepository<ShopEntity, String> {
}