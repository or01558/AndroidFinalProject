package com.server.dev.api.extensions

import com.server.dev.api.structures.FieldProperty
import javax.servlet.http.HttpServletRequest


var HttpServletRequest.user: String by FieldProperty { "" }
