package com.server.dev.gameServices.src.main.kotlin.game.api.events.game

import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketEvent
import com.server.dev.games.GuessTheNumber
import org.json.JSONObject

final class GameStartEvent : WebSocketEvent<GameStartEvent> {
    private var game : GuessTheNumber

    constructor(game : GuessTheNumber) : super("gameStart", 18101, null) {
        this.game = game
        setEvent(this)
    }

    override fun getEventJson(): JSONObject {
        val json = JSONObject()
        json.put("game", game.toJson())
        return json
    }
}
