package com.server.dev.api.games

import com.server.dev.api.database.entities.GameEntity
import com.server.dev.api.database.repositories.GamesRepository
import kotlin.random.Random

class GamesLoader(private val gamesRepository: GamesRepository) {
    companion object {
        private const val GAME_ID_LENGTH = 16
    }

    fun addGames() {
         val guessTheNumber : GameEntity = GameEntity(generateGameId(),
         "Guess The Number Game",
          "GuessTheNumber",
         "A game when you need to guess the right number!")
          println("GuessTheNumber game id is " + guessTheNumber.id)

          val ticTacToe : GameEntity = GameEntity(generateGameId(),
                  "Tic Tac Toe Game",
                  "TicTacToe",
                  "A game when you need to make three/x/o in a row/column/diagonal in order to win it."
          )
          println("TicTacToe game id is " + ticTacToe.id)


        addGame(guessTheNumber)
         addGame(ticTacToe)
      }

     private fun generateGameId() : String {

         var id = ""

         while (id.isEmpty() || gamesRepository.existsById(id)) {
             for (i in 0 until Companion.GAME_ID_LENGTH) {
                 id += Random.nextInt(0, 9)
             }
         }

         return id
     }

      private fun addGame(gameEntity: GameEntity) {
          gamesRepository.save(gameEntity)
    }
}