package com.server.dev.api.structures

import org.springframework.stereotype.Component

@Component
enum class ServerResponseTypes(val value : Int) {
    Success(0),
    Error(400),
    Unknown(-1);

    companion object {
        fun getValueOf(value: Int): ServerResponseTypes {
            return when (value) {
                0 -> Success
                400 -> Error
                else -> Unknown
            }
        }
    }
}