package com.server.dev.gameServices.src.main.kotlin.game

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.server.dev.api.database.entities.GameEntity
import com.server.dev.api.game.Game
import com.server.dev.api.game.GameClient
import com.server.dev.api.game.GameClientInformation
import com.server.dev.api.game.UserLeaveData
import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.utils.Requests
import com.server.dev.gameServices.src.main.kotlin.enums.ServiceTypes
import com.server.dev.gameServices.src.main.kotlin.game.api.data_structures.TextMessage
import com.server.dev.gameServices.src.main.kotlin.game.api.events.GameClientConnectionEvent
import com.server.dev.gameServices.src.main.kotlin.game.api.events.game.PlayerLeaveEvent
import com.server.dev.gameServices.src.main.kotlin.game.api.functions.getGameClients
import com.server.dev.gameServices.src.main.kotlin.game.api.request_handlers.endGame
import com.server.dev.gameServices.src.main.kotlin.game.api.request_handlers.makeMove
import com.server.dev.gameServices.src.main.kotlin.game.api.request_handlers.playGame
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.Responses
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketActions
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketResponse
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors.Errors
import com.server.dev.gameServices.src.main.kotlin.structures.Service
import org.json.JSONException
import org.json.JSONObject
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component
import org.springframework.web.socket.CloseStatus
import org.springframework.web.socket.TextMessage as WebSocketMessage
import org.springframework.web.socket.WebSocketSession
import java.net.URL
import java.util.concurrent.atomic.AtomicReference

@Component
class MyFirstGameService : Service("myGameService", "This service allows game client to connect to the game and to actually play it. Also allows game clients to modify the saved game state and to send data/events/actions to this service for being able to make all the game mechanics working.", mutableListOf("user.game.play", "user.game.play.player."), mutableListOf("game.service.connect", "game.service.individual.data.manager"), ServiceTypes.IndividualDataManager, 3000) {

    companion object {
        val waitingSessions: MutableList<WebSocketSession> = mutableListOf()
    }

    fun isGameClientExistsById(id: String): Boolean {
        val gameClientExists: AtomicReference<Boolean> = AtomicReference()
        gameClientExists.set(false)

        getGameClients().forEach { gc ->
            if (gc.id == id) gameClientExists.set(true)
        }

        return gameClientExists.get()
    }


    fun isGameClientExistsBySecret(secret: String): Boolean {
        val gameClientExists: AtomicReference<Boolean> = AtomicReference()
        gameClientExists.set(false)

        getGameClients().forEach { gc ->
            if (gc.secret == secret) gameClientExists.set(true)
        }

        return gameClientExists.get()
    }


    override fun onMessage(client: WebSocketSession, message: WebSocketMessage): Boolean {
        try {
            val data = JSONObject(message.payload)
            if (client.attributes.isEmpty()) {
                if (!data.has("gameClient"))
                    return sendServerResponse(client, Errors.GameClients.EmptyGameClientData)

                val gameClientJSON = data.getJSONObject("gameClient")

                if (!gameClientJSON.has("id")) return sendServerResponse(
                    client,
                    Errors.GameClients.MissingClientId(null)
                )
                if (!gameClientJSON.has("secret")) return sendServerResponse(
                    client,
                    Errors.GameClients.MissingClientSecret(null)
                )
                if (!gameClientJSON.has("playerId")) return sendServerResponse(
                    client,
                    Errors.GameClients.MissingPlayerId(null)
                )

                val id = gameClientJSON.getString("id")
                val secret = gameClientJSON.getString("secret")
                val playerId = gameClientJSON.getString("playerId")
                val gameClient = getGameClient(id, secret, playerId)
                    ?: return sendServerResponse(client, Errors.GameClients.InvalidGameClient)

                if (gameClient.isConnectedToGameServices) return sendServerResponse(
                    client,
                    Errors.GameClients.ClientIsAlreadyConnected
                )

                client.attributes["gameClient"] = gameClient
                gameClient.webSocketSession = client
                gameClient.isConnectedToGameServices = true
                val response: WebSocketResponse<TextMessage, GameClientConnectionEvent, Nothing> = WebSocketResponse(
                    GameClientConnectionEvent(client),
                    TextMessage("Websocket Client and the game client has been successfuly connected! \n You can now successfully play game through the service 'MyFirstGameService'."),
                    null
                )
                send(client, response)
                return true
            }

            val attributes = client.attributes
            val gameClient =
                getGameClient(attributes) ?: return sendServerResponse(client, Errors.GameClients.InvalidGameClient)
            return handlePlayerRequest(client, gameClient, data)
        } catch (exp: JSONException) {
            exp.printStackTrace()
            return sendServerResponse(client, Errors.RequestData.InvalidDataFormat)
        }

    }

    private fun handlePlayerRequest(
        client: WebSocketSession,
        gameClient: GameClient,
        requestData: JSONObject
    ): Boolean {
        if (!gameClient.isConnectedToGameServices) return sendServerResponse(
            client,
            Errors.GameClients.ClientNotConnected
        )

        if (!requestData.has("path")) return sendServerResponse(
            client,
            Errors.RequestData.MissingGameAction
        )

        val path = requestData.getString("path")

        if (path == "/play") {
            val gameRoom = playGame(this, gameClient, requestData.getJSONObject("data"))
                ?: return sendServerResponse(client, Errors.GameErrors.SomethingWentWrong)
            if(requestData.getJSONObject("data").getJSONObject("game").getString("mode").lowercase() == "multiplayer") {
                if(gameRoom.gameClients.indexOf(gameClient) > 0 ) return sendServerResponse(client, Responses.YouJoinedToGameRoom)
                return sendServerResponse(client, Responses.GameRoomCreated)
            }

        } else if (path == "/make-move") {
            val success = makeMove(this, gameClient, requestData.getJSONObject("data")) ?: return sendServerResponse(
                client,
                Errors.RequestData.InvalidDataFormat
            )
            if (!success) return sendServerResponse(client, Errors.GameErrors.SomethingWentWrong)
            return true
        }

        return sendServerResponse(client, Errors.RequestData.InvalidPath)
    }

    private fun getGameClient(id: String?, secret: String?, playerId: String?): GameClient? {
        val gameClient: AtomicReference<GameClient?> = AtomicReference()
        gameClient.set(null)

        getGameClients().forEach { gc ->
            if (gc.id == id && gc.secret == secret && gc.userEntity.id == playerId) {
                gameClient.set(gc)
            }
        }

        return gameClient.get()
    }


    private fun getGameClient(attributes: Map<String, Any>): GameClient? {
        if (attributes.isEmpty()) return null
        return if (attributes.containsKey("gameClient")) attributes["gameClient"] as GameClient else null
    }

    override fun onError(client: WebSocketSession, error: Throwable): Boolean {
        return false
    }

    override fun onClientConnection(client: WebSocketSession) {
        super.onClientConnection(client)
        waitingSessions.add(client)
        val response: WebSocketResponse<TextMessage, GameClientConnectionEvent, Nothing> = WebSocketResponse(
            GameClientConnectionEvent(client),
            TextMessage("Websocket Client has been added to the waiting sessions list! \n If You want create a game client and bind it within two minutes You will get kicked out from the game service 'MyFirstGameService'."),
            null
        )
        send(client, response)
    }

    override fun onClientDisconnection(client: WebSocketSession, status: CloseStatus) {
        val gameClient = getGameClient(client.attributes) ?: return
        val gameRoom = findGameRoom(gameClient)
        if (gameRoom != null) {
            val userData = UserLeaveData(gameClient.userEntity, false)
            val webSocketResponse = WebSocketResponse(
                PlayerLeaveEvent(), userData, WebSocketActions("playerLeave", 1829837, mutableListOf(userData))
            )

            gameRoom.gameClients.remove(gameClient)
            removeGameClientFromServer(GameClientInformation(gameClient.id, gameClient.secret, gameClient.userEntity.player!!.userId))

            gameRoom.gameClients.forEach {
                if (it.userEntity.id != gameClient.userEntity.id) {
                    send(it.webSocketSession!!, webSocketResponse)
                }
            }

            if(gameRoom.gameClients.size < 2) endGame(this, gameRoom, gameRoom.match!!)

        }
    }

    private fun removeGameClientFromServer(gameClientInformation : GameClientInformation) : Boolean {
        val responseJSON =
            JSONObject(Requests.send(URL("http://localhost/api/game/clients/disconnect"), jacksonObjectMapper().writeValueAsString(gameClientInformation), HttpMethod.POST).body as String)
        val response = ServerResponse.createFromJSON(responseJSON)

        if (response.status == HttpStatus.OK && response.errorId == null && response.type == ServerResponseTypes.Success) {
            return true
        }

        return false
    }
}