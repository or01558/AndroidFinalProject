package com.server.dev.games.annotations

annotation class GameId(val id : String)
