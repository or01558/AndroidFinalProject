package com.server.dev.api.utils

import org.springframework.stereotype.Component

@Component
class Server {

    companion object {
        val Secret = "aljaljal;$$%2333"
    }
}