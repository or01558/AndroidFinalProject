package com.server.dev.api.game

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.server.dev.api.database.entities.GameEntity
import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.structures.Json
import com.server.dev.gameServices.src.main.kotlin.game.api.request_handlers.PlayerMove
import org.json.JSONArray
import org.json.JSONObject
import org.springframework.stereotype.Component
import java.util.concurrent.atomic.AtomicReference

@Component
class GameState<T>(private var state : T) {
 fun getState() : T {
     return this.state
 }

 fun setState(state: T) {
     this.state = state
 }
}

enum class GameDifficulties(val value : Int) {
    Easy(0),
    Normal(1),
    Medium(2),
    Hard(3),
    VeryHard(4),
    Hardcore(5),
    Impossible(6),
}

abstract class GameBot<C : Any>(val user: UserEntity) {
    abstract fun generateMove() : C
}

@Component
abstract class Game<T, K : GameState<T>, V : Game<T, K, V, C>, C : Any>(val difficulty: GameDifficulties, state : T, private var match : Match<T, K, V, C>?, var gameEnded: Boolean = false, var bots : MutableList<GameBot<C>> = mutableListOf()): GameState<T>(state) {
    companion object {
        const val minPlayers : Int = 1
        const val maxPlayers = 10
        const val maxRounds = -1
        const val maxTurnsPerPlayer = -1
    }

    abstract fun start()
    abstract fun isWin() : Boolean
    abstract fun makeMove(move : C)
    abstract fun makeBotTurns()

    fun stop() {
        gameEnded = true
    }

    fun isDraw() : Boolean {
        return getMatch()?.winner == null
    }

    fun getMatch(): Match<T, K, V, C>? {
        return this.match
    }

    fun setMatch(match: Match<T, K, V, C>?) {
        this.match = match
    }

    fun findBot(user: UserEntity) : GameBot<C>? {
        val gameBotReference : AtomicReference<GameBot<C>?> = AtomicReference()
        gameBotReference.set(null)

        if(user.player?.bot == true) {
            bots.forEach {
                if(it.user.id == user.id) gameBotReference.set(it)
            }
        }

        return gameBotReference.get()
    }

    fun toJson() : JSONObject {
        val json = JSONObject()
        val difficultyJson = JSONObject()
        difficultyJson.put("name", difficulty.name)
        difficultyJson.put("value", difficulty.value)

        json.put("difficulty", difficultyJson)
        json.put("gameEnded", gameEnded)

        var botsUsers : MutableList<JSONObject> = mutableListOf()

        bots.forEach {
            botsUsers.add(JSONObject(jacksonObjectMapper().writeValueAsString(it.user)))
        }

        return json
    }
}


class Match<T ,  K : GameState<T>, V : Game<T, K, V, C>, C : Any>: Json {
    final var game : V
    final var gameEntity: GameEntity
    final var players: List<UserEntity>
    var winner: UserEntity? = null
    final var playersCount : Int = 0
    var currentPlayerTurnIndex : Int = 0
    var currentPlayerTurn : UserEntity
    var currentMove : C
    var currentRound : Int = 0
    var turnsPerPlayerList : MutableMap<String, Int> = mutableMapOf()

    constructor(game : V, gameEntity: GameEntity, players: List<UserEntity>,  currentMove : C, ) : super() {
        this.game = game
        this.gameEntity = gameEntity
        this.players = players
        this.currentMove = currentMove
        currentPlayerTurn = players[currentPlayerTurnIndex]

        this.playersCount = players.size
        this.game.setMatch(this)
        this.game.start()
        this.players.forEach {
            this.turnsPerPlayerList[it.id] = 0
        }
    }

    override fun toJson(): JSONObject {
        val objectMapper = ObjectMapper()
        this["game"] = this.game.toJson()
        this["gameData"] = JSONObject(objectMapper.writeValueAsString(this.gameEntity))
        this["players"] = JSONArray(objectMapper.writeValueAsString(this.players))
        if(this.winner != null) this["winner"] = JSONObject(objectMapper.writeValueAsString(this.winner))
        this["playersCount"] = this.playersCount
        this["currentPlayerTurn"] = JSONObject(objectMapper.writeValueAsString(this.currentPlayerTurn))
        this["currentMove"] = this.currentMove
        this["currentRound"] = this.currentRound
        this["turnsPerPlayerList"] = JSONObject(objectMapper.writeValueAsString(this.turnsPerPlayerList))
        return this
    }
}