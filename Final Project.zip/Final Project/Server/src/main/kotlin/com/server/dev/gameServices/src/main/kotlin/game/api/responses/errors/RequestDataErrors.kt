package com.server.dev.gameServices.src.main.kotlin.game.api.responses.errors

import com.server.dev.api.structures.ServerResponse
import com.server.dev.api.structures.ServerResponseTypes
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class RequestDataErrors {
    companion object {
        val InvalidDataFormat = ServerResponse(
            "Cannot parse the requested data format",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            2000,
            "Invalid Data Format Has Provided",
            "unknown",
            "JSONObject"
        )

        val InvalidPath = ServerResponse(
            "Cannot parse the requested data format",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            2002,
            "Invalid Path Has Provided",
            "unknown",
            "/play or /make-move"
        )

        val MissingGameAction = ServerResponse(
            "Cannot parse the request data",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            2001,
            "Missing specific game action",
            "null",
            "valid game object"
        )
    }
}