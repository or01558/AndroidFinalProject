package com.server.dev.api.security.authorization

import org.springframework.stereotype.Component

@Component
data class AuthorizationCode(val userId : String, val scopes : List<Scopes>, val code : String) {

}
