package com.server.dev.api.responses.errors

import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class ApiErrors {
    companion object
    {
        val Login = LoginErrors
        val Register = RegisterErrors
        val Authorization = AuthorizationErrors
        val UserAuth = UserAuthorizationErrors
        val UnknownError = ServerResponse("Something went wrong",  HttpStatus.BAD_REQUEST, ServerResponseTypes.Error, 400,"Unknown.","valid auth response??", "valid auth response")
        val Game = GameErrors

        fun validationSuccess(name : String): ServerResponse {
            return ServerResponse("$name Validation Succeed")
        }
    }
}