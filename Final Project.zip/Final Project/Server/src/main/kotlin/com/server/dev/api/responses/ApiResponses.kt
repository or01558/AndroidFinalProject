package com.server.dev.api.responses

import org.springframework.stereotype.Component

@Component
class ApiResponses {

}