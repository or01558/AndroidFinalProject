package com.server.dev.api.game

import com.server.dev.api.security.authorization.clients.Clients
import org.springframework.stereotype.Component

@Component
class GameClientInformation(private val id: String?, private val secret: String?, private val playerId : String) {

    fun getId(): String? {
        return this.id
    }

    fun getSecret(): String? {
        return this.secret
    }

    fun getPlayerId(): String? {
        return this.playerId
    }
}