package com.server.dev.api.database.entities

import javax.persistence.*

@Entity
@Table(name = "users")
data class UserEntity(
    @Id
    val id : String,
    var email : String,
    var username : String?,
    var password : String,
    @ManyToOne()
    @JoinColumn(name="id", nullable = false, insertable = false, updatable = false)
    var profile: ProfileEntity? = null,
    @ManyToOne()
    @JoinColumn(name="id", nullable = false, insertable = false, updatable = false, referencedColumnName = "userId")
    var player: PlayerEntity? = null){
    constructor() : this("", "", "", "")
}