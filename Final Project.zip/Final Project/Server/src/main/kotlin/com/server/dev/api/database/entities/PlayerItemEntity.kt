package com.server.dev.api.database.entities

import javax.persistence.*


@Entity
@Table(name = "player_items")
data class PlayerItemEntity(@Id val playerId : String, val uses: Int = 0, val itemId : String,
                            @ManyToOne()
                            @JoinColumn(name="itemId", referencedColumnName="id", nullable = false, insertable = false, updatable = false)
                            val item : ItemEntity?) {
    constructor() : this("", 0, "", null) {
    }
}