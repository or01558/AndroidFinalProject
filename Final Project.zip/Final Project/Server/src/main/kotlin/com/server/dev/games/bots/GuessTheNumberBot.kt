package com.server.dev.games.bots

import com.server.dev.api.database.entities.UserEntity
import com.server.dev.api.game.GameBot

class GuessTheNumberBot(user : UserEntity, private val guesses : MutableList<Int> = mutableListOf(), private val maxNumber : Int, private var times : Int = 0) : GameBot<Int>(user) {

    private fun generateMove(minValue : Int, maxValue : Int) : Int {
        if(!guesses.contains(minValue)) {
            guesses.add(minValue)
            return minValue
        }

        else if(!guesses.contains(maxValue)) {
            guesses.add(maxValue)
            times++
            return maxValue
        }

        return maxValue
    }


    override fun generateMove(): Int {
       return generateMove(1 + times, maxNumber - times)
    }
}