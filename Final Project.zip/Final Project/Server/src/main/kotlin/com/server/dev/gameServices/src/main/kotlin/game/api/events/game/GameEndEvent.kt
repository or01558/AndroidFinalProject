package com.server.dev.gameServices.src.main.kotlin.game.api.events.game

import com.server.dev.api.game.Match
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketEvent
import com.server.dev.games.GuessTheNumber
import org.json.JSONObject

final class GameEndEvent : WebSocketEvent<GameEndEvent> {
    private val match : Match<*, *, *, *>

    constructor(match : Match<*, *, *, *>) : super("gameEnd", 161761, null)  {
        this.match = match
        setEvent(this)
    }

    override fun getEventJson(): JSONObject {
        val json = JSONObject()
        json.put("match", match.toJson())
        return json
    }
}
