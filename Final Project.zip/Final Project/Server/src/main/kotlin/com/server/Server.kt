package com.server

import com.server.dev.api.middlewares.UserLoader
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.domain.EntityScan
import org.springframework.boot.runApplication
import org.springframework.boot.web.servlet.FilterRegistrationBean
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import org.thymeleaf.templatemode.TemplateMode
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver


@Configuration
 class WebMvcConfig() : WebMvcConfigurer {

	@Bean
	 fun yourTemplateResolver(): ClassLoaderTemplateResolver {
		val configurator = ClassLoaderTemplateResolver();
		configurator.prefix = "templates/";
		configurator.suffix = ".html";
		configurator.templateMode = TemplateMode.HTML;
		configurator.characterEncoding = "UTF-8";
		configurator.order = 0;  // this is important. This way spring //boot will listen to both places 0 and 1
		configurator.checkExistence = true
		return configurator;
	}

	@Bean
	fun userLoaderFilter(): FilterRegistrationBean<UserLoader>? {
		val registrationBean: FilterRegistrationBean<UserLoader> =
			FilterRegistrationBean<UserLoader>()
		registrationBean.filter = UserLoader()
		registrationBean.order = 1
		registrationBean.addUrlPatterns("/", "/*");
		return registrationBean
	}

}


@EntityScan(basePackages = ["com.server.dev.api.database.entities"])
@ComponentScan(basePackages = ["java.lang.*", "com.server.dev.api.controllers", "com.server.dev.api.services"])
@SpringBootApplication
class BackendApplication


fun main(args: Array<String>) {
	try {
		runApplication<BackendApplication>(*args)
	} catch(exception : Exception) {
		exception.printStackTrace()
	}
}
