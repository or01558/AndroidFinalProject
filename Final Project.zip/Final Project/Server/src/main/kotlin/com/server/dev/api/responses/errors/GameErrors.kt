package com.server.dev.api.responses.errors

import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class GameErrors {
    companion object {
        val EmptyGameClientData = ServerResponse(
            "Game Client Data can't be null",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            300,
            "Missing Current New Game Client Details.",
            "null",
            "{accessToken : String, refreshToken : String, webClient : { id : String, secret : String }}"
        )

        val EmptyGameClientInformation = ServerResponse(
            "Game Client Information can't be null",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            300,
            "Missing Game Client Details.",
            "null",
            "{id : String, secret : String, playerId : String, webClient : { id : String, secret : String }}"
        )

        val GameNotFound = ServerResponse(
            "The server was trying to fetch an unknown game!",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            301,
            "Invalid Game Id has been provided.",
            "invalid game id",
            "valid game id"
        )
    }
}