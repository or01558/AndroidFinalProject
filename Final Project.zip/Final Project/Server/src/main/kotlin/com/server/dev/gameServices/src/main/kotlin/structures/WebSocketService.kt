package com.server.dev.gameServices.src.main.kotlin.structures

import com.server.dev.api.structures.Json
import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import com.server.dev.gameServices.src.main.kotlin.enums.ServiceTypes
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketEvent
import com.server.dev.gameServices.src.main.kotlin.game.api.responses.WebSocketResponse
import org.json.JSONObject
import org.springframework.context.annotation.Configuration
import org.springframework.web.socket.*
import org.springframework.web.socket.config.annotation.EnableWebSocket
import org.springframework.web.socket.config.annotation.WebSocketConfigurer
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry
import org.springframework.web.socket.handler.AbstractWebSocketHandler

open class WebSocketServer(val Service : Service, val port : Int) : WebSocketConfigurer {

    override fun registerWebSocketHandlers(registry: WebSocketHandlerRegistry) {
        registry.addHandler(this.Service, "/*")
    }

}

abstract class WebSocketService(var serviceType: ServiceTypes) : AbstractWebSocketHandler() {

    companion object {
        fun sendServerResponse(client: WebSocketSession, serverResponse: ServerResponse,  serviceType : ServiceTypes): Boolean {
            sendJsonMessage(client, serverResponse.toJson(), serviceType)
            return serverResponse.type == ServerResponseTypes.Success
        }

        fun sendMessage(client: WebSocketSession, textMessage: TextMessage, serviceType : ServiceTypes) {
            if(serviceType != ServiceTypes.DataSender && serviceType != ServiceTypes.IndividualDataManager) throw Exception("This Websocket service doesn't support message sending. \n You can still do it on the old fashion way with modifying the code or configuring it by yourself but If You want options to manipulate and control messages You should use the built in DataSender type or the IndividualDataManager for some more customization")
            client.sendMessage(textMessage)
        }

        fun sendJsonMessage(client: WebSocketSession, json: JSONObject,  serviceType : ServiceTypes) {
            if(serviceType != ServiceTypes.DataSender && serviceType != ServiceTypes.IndividualDataManager) throw Exception("This Websocket service doesn't support message sending. \n You can still do it on the old fashion way with modifying the code or configuring it by yourself but If You want options to manipulate and control messages You should use the built in DataSender type or the IndividualDataManager for some more customization")
            client.sendMessage(TextMessage(json.toString()))
        }

    }

    private val clients: MutableList<WebSocketSession> = mutableListOf()

     fun <Data : Json?, Event : WebSocketEvent<Event>,ActionArguments: Json?> send(client : WebSocketSession, response: WebSocketResponse<Data, Event, ActionArguments>) {
         client.sendMessage(TextMessage(response.toJson().toString()))
     }

    open fun onClientConnection(client : WebSocketSession) {

    }

    open fun onUpdateRequest(client: WebSocketSession, updatedData: JSONObject) : Boolean {
        return true
    }

    open fun onServiceAction(session: WebSocketSession, serviceAction: JSONObject) {

    }

    open fun onMessage(client: WebSocketSession, message: TextMessage) : Boolean {
        return true
    }

    open fun onError(client: WebSocketSession, error: Throwable) : Boolean {
        return true
    }

    open fun onClientDisconnection(client: WebSocketSession, status: CloseStatus) {

    }

    @Throws(Exception::class)
    override fun afterConnectionEstablished(session: WebSocketSession) {
        this.clients.add(session)
        this.onClientConnection(session)
    }

    @Throws(Exception::class)
    override fun handleTextMessage(session: WebSocketSession, message: TextMessage) {
        when (serviceType) {
            ServiceTypes.DataReceiver -> this.onUpdateRequest(session, JSONObject(message.toString()))
            ServiceTypes.DataAnalyser -> this.onServiceAction(session, JSONObject(message.toString()))
            ServiceTypes.IndividualDataManager -> this.onMessage(session, message)
            else -> {}
        }
    }


    @Throws(Exception::class)
    override fun handleTransportError(session: WebSocketSession, exception: Throwable) {
        onError(session, exception)
    }

    @Throws(Exception::class)
    override fun afterConnectionClosed(session: WebSocketSession, closeStatus: CloseStatus) {
        this.clients.removeIf { client ->
            client.id == session.id
        }
        onClientDisconnection(session, closeStatus)
    }

    private fun sendMessage(client: WebSocketSession, textMessage: TextMessage) {
       sendMessage(client, textMessage, serviceType)
    }

    private fun sendJsonMessage(client: WebSocketSession, json: JSONObject) {
      sendJsonMessage(client, json, serviceType)
    }

    fun sendServerResponse(client: WebSocketSession, serverResponse: ServerResponse): Boolean {
       return sendServerResponse(client, serverResponse, serviceType)
    }


    fun emit(client : WebSocketSession, event : Event) {
        if(this.serviceType != ServiceTypes.DataEmitter && this.serviceType != ServiceTypes.IndividualDataManager) throw Exception("This Websocket service doesn't support events sending. \n You can still do it on the old fashion way with modifying the code or configuring it by yourself but If You want options to manipulate and control events You should use the built in DataEmitter type or the IndividualDataManager for some more customization")
        client.sendMessage(TextMessage(event.toJson().toString()))
    }

    fun brodcast(event : Event) {
        this.clients.forEach { client -> emit(client, event)}
    }

    fun brodcast(textMessage : TextMessage) {
        this.clients.forEach { client -> sendMessage(client, textMessage)}
    }

    fun brodcast(json : Json) {
        this.clients.forEach { client -> sendJsonMessage(client, json.toJson())}
    }

    override fun supportsPartialMessages(): Boolean {
        return false
    }
}