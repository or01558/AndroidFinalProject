package com.server.dev.api.structures

import org.json.JSONObject
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Component

@Component
class ServerResponse(var message : String = "", var status: HttpStatus = HttpStatus.OK, var type : ServerResponseTypes = ServerResponseTypes.Success, var errorId: Int? = null, var reason : String? = null, var got: String? = null, var expected: String? = null, var value : Any? = null, var statusCode: Int = status.value()) : Json() {

    companion object {
        fun createFromJSON(json: JSONObject): ServerResponse {
            var value : JSONObject? = null
           if(!json.isNull("value")) value = JSONObject(json.getString("value"))
            var errorId: Int? = null
            if(!json.isNull("errorId")) errorId = json.getInt("errorId")
            var reason: String? = null
            var got: String?  = null
            var expected: String?  = null
            if(!json.isNull("reason")) reason = json.getString("reason")
            if(!json.isNull("got")) got = json.getString("got")
            if(!json.isNull("expected")) expected = json.getString("expected")

            return ServerResponse(json.getString("message"), HttpStatus.valueOf(json.getString("status")), ServerResponseTypes.valueOf(json.getString("type")), errorId, reason, got, expected, value, json.getInt("statusCode")
          )
        }

        class ResponseBuilder()  : ServerResponse() {

            fun setMessage(message: String): ResponseBuilder {
                this.message = message
                return this
            }

            fun message(message: String): ResponseBuilder {
                return this.setMessage(message)
            }

            fun setStatus(status: HttpStatus): ResponseBuilder {
                this.status = status
                return this
            }

            fun status(status: HttpStatus): ResponseBuilder {
                return this.setStatus(status)
            }

            fun setType(type: ServerResponseTypes): ResponseBuilder {
                this.type = type
                return this
            }

            fun type(type: ServerResponseTypes): ResponseBuilder {
                return this.setType(type)
            }

            fun setErrorId(errorId: Int?): ResponseBuilder {
                this.errorId = errorId
                return this
            }

            fun errorId(errorId: Int?): ResponseBuilder {
                return this.setErrorId(errorId)
            }

            fun setReason(reason: String?): ResponseBuilder {
                this.reason = reason
                return this
            }

            fun reason(reason: String?): ResponseBuilder {
                return this.setReason(reason)
            }

            fun setGot(got: String?): ResponseBuilder {
                this.got = got
                return this
            }

            fun got(got: String?): ResponseBuilder {
                return this.setGot(got)
            }

            fun setExpected(expected: String?): ResponseBuilder {
                this.expected = expected
                return this
            }

            fun expected(expected: String?): ResponseBuilder {
                return this.setExpected(expected)
            }

            fun gotWhileExpected(got: String?, expected: String?): ResponseBuilder {
                this.setGot(got)
                return this.setExpected(expected)
            }

            fun error(reason : String?, got: String?, expected: String?): ServerResponse {
                this.setReason(reason)
                return this.gotWhileExpected(got, expected).build()
            }

            fun setValue(value : Any?) : ResponseBuilder {
                this.value = value
                return this
            }

            fun value(value : Any?) : ResponseBuilder {
              return this.setValue(value)
            }

            fun setStatusCode(statusCode : Int) : ResponseBuilder {
                this.statusCode = statusCode;
                return this
            }

            fun statusCode(statusCode : Int) : ResponseBuilder {
                return this.setStatusCode(statusCode)
            }

            fun build(): ServerResponse {
                return this
            }
        }

    }

    override fun declareJSON() {
        this["message"] = message
        this["status"] = status?.value()
        this["statusCode"] = statusCode
        this["type"] = type?.value
        this["errorId"] = errorId
        this["reason"] = reason
        this["got"] = got
        this["expected"] = expected
        this["value"] = null
        if(value != null) this["value"] = value as JSONObject
    }

    fun entity(): ResponseEntity<ServerResponse> {
        if(value != null) value = value.toString()
        return ResponseEntity.status(status).contentType(MediaType.APPLICATION_JSON).body(this)
    }
}