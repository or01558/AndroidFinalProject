package com.server.dev.api.extensions

import java.security.MessageDigest

fun String.sha256(): String {
    return hashString(this, "SHA-256")
}

fun String.contains(list: List<String>): Boolean {

    list.forEach {
        if(this.contains(it)) return true
    }

    return false
}

private fun hashString(input: String, algorithm: String): String {
    return MessageDigest
        .getInstance(algorithm)
        .digest(input.toByteArray())
        .fold("") { str, it -> str + "%02x".format(it) }
}

fun String?.isMissingMessage() = if(isNullOrEmpty()) "Missing" else ""
fun String?.meetRequirementsMessage() : String = isMissingMessage().ifEmpty { "doesn't meet the requirements" }