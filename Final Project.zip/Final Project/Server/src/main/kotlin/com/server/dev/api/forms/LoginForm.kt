package com.server.dev.api.forms

import com.server.dev.api.database.repositories.UsersRepository
import com.server.dev.api.extensions.sha256
import com.server.dev.api.classes.Form
import com.server.dev.api.responses.errors.LoginErrors
import org.springframework.stereotype.Component

@Component
data class LoginForm(val username : String? = "", val password : String? = "") : Form<UsersRepository>() {

    override fun validate(repository: UsersRepository, vararg args: Any): Any {
        if(username.isNullOrEmpty()) return LoginErrors.MissingUsername(username)
        if(password.isNullOrEmpty())  return LoginErrors.MissingPassword(password)

        val users = repository.findByUsernameOrEmail(username!!, password!!)
        if(users.isEmpty()) return LoginErrors.InvalidUser

        val userEntity = users[0]
        if(userEntity.password != password!!.sha256())  return LoginErrors.InvalidPassword
        userEntity.password = "password:#encrypted"
        userEntity.email = "email:#is__secret"

        return userEntity
    }

    override fun toString(): String {
        return """
            LoginForm(clientId=$clientId, clientSecret=$clientSecret, username=$username, password=$password)
        """.trimIndent()
    }

}