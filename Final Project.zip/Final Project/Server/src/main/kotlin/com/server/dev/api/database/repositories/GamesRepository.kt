package com.server.dev.api.database.repositories

import com.server.dev.api.database.entities.GameEntity
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface GamesRepository : CrudRepository<GameEntity, String> {
}