package com.server.dev.api.database.entities

import javax.persistence.*

@Entity
@Table(name = "players")
data class PlayerEntity(
    @Id
    val userId : String,
    val coins : Int = 0,
    val diamonds : Int = 0,
    val level : Int = 0,
    val xp: Int = 0,
    val bot : Boolean = false,
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinColumn(name="userId", referencedColumnName="playerId", nullable = false, insertable = false, updatable = false)
    val items : MutableList<PlayerItemEntity> = mutableListOf()
    ){
    constructor() : this("")
}