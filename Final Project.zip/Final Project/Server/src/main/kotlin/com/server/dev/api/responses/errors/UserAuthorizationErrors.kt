package com.server.dev.api.responses.errors

import com.server.dev.api.structures.ServerResponseTypes
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component

@Component
class UserAuthorizationErrors {
    companion object {
        val InvalidAuthorization = ServerResponse(
            "User's Auth Data can't be null",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            600,
            "Missing User auth details", "null", "{accessToken: String, refreshToken: String, clientId: String, clientSecret: String}"
        )

        val MissingAccessToken = ServerResponse(
            "Invalid User Auth",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            601,
            "Missing User's access's token", "null", "String"
        )

        val MissingRefreshToken = ServerResponse(
            "Invalid User Auth",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            602,
             "Missing User's refresh's token", "null", "String"
        )

        val InvalidUser = ServerResponse(
            "Invalid User Auth",
            HttpStatus.UNAUTHORIZED,
            ServerResponseTypes.Error,
            603,
            "Cannot find this specific user!",
            "invalid user data",
            "valid user data"
        )

        val InvalidCodeAuthorization =  ServerResponse(
            "User's Code's Auth Data can't be null",
            HttpStatus.BAD_REQUEST,
            ServerResponseTypes.Error,
            604,
            "Missing User's code auth details", "null", "{clientId: String, clientSecret: String, code: String}"
        )

        val MissingAuthCode =  ServerResponse(
            "Invalid User's Code Auth",
            HttpStatus.UNPROCESSABLE_ENTITY,
            ServerResponseTypes.Error,
            605,
            "Missing User's auth's code", "null", "String"
        )

    }
}