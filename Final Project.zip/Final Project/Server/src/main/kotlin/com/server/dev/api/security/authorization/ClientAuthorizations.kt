package com.server.dev.api.security.authorization

import com.server.dev.api.security.authorization.clients.Clients
import com.server.dev.api.security.permissions.Permission
import com.server.dev.api.security.permissions.UserPermissions
import com.server.dev.api.structures.RequestURL
import org.json.JSONArray
import org.json.JSONObject
import org.springframework.http.HttpMethod
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Component
import java.net.URL

@Component
enum class ResponseTypes(var value : String) {
    AccessToken("access-token"),
    RefreshToken("refresh-token"),
    Code("code");
    companion object {
        fun get(value: String?): ResponseTypes? {
            for(responseType in values()) {
                if(value != null && responseType.value == value) return responseType
            }
            return null
        }

       fun getByName(name : String?): ResponseTypes? {
           for(responseType in values()) {
               if(name != null && responseType.name == name) return responseType
           }
           return null
       }
    }
}


enum class GrantTypes(var value : String) {
    AuthorizationCode("authorization-code"),
    RefreshToken("refresh-token"),
    ClientAuthorization("client-authorization");
    companion object {
        fun get(value: String?): GrantTypes? {
            for(grantType in values()) {

                if(value != null && grantType.value == value) return grantType
            }
            return null
        }
    }
}

enum class Scopes(var id : String, var scopeName : String, var permissions : List<Permission>, var title : String, var description: String, val isUserScope : Boolean) {
    Identity(
        "pT3Pt",
        "identity",
        listOf(UserPermissions.Username, UserPermissions.Profile),
        "Identity User",
        "Allows you to identity specific user with his username and password and to access some values from the user object. \nFor more details about the user object response look on the api's documentation.",
        true,
    ),

    ManagePlayer(
        "1r71ka",
        "player management",
        listOf(UserPermissions.Manage_Player),
        "Manage Player Data",
        "Allows you to get specific user's player's data and to manage all the data within the player object. \nFor more details about the player object object look on the api's documentation.",
        true);


    fun toJson(): JSONObject {
        val jsonObject = JSONObject()
        jsonObject.put("id", id)
        jsonObject.put("scopeName", scopeName)
        jsonObject.put("permissions", JSONArray(permissions.map { it.toJson()}))
        jsonObject.put("title", title)
        jsonObject.put("description", description)
        jsonObject.put("isUserScope", isUserScope)
        return jsonObject
    }

    companion object {

       fun get(name: String) : Scopes? {
            for(scope in values()) {

                if(scope.name == name) return scope
            }
            return null
        }

       fun getById(scopeId: String) : Scopes? {
           for(scope in values()) {

               if(scope.id == scopeId) return scope
           }
           return null
       }

   }
}

open class Authorization(var clientId : String? = null, var clientSecret: String? = null, var redirect : RequestURL? = null, var grant_type: GrantTypes? = null, var code: String? = null, var refresh_token: String? = null, var access_token: String? = null, var responseType: ResponseTypes? = null, var userId : String? = null, var scopes: List<Scopes> = listOf(), var redirectMethod : HttpMethod? = null) {

    private var client : Clients? = null

    companion object {
        private fun fromJson(json : JSONObject): Authorization {
            val authorization =  Authorization()
            authorization.clientId = json.getString("clientId")
            authorization.clientSecret = json.getString("clientSecret")
            authorization.redirect = RequestURL(json.getString("redirect"))
            authorization.clientSecret = json.getString("clientSecret")
            authorization.grant_type = GrantTypes.get(json.getString("grant_type"))
            authorization.code = json.getString("code")
            authorization.refresh_token = json.getString("refresh_token")
            authorization.access_token = json.getString("access_token")
            authorization.responseType = ResponseTypes.get(json.getString("responseType"))
            authorization.userId = json.getString("userId")
            return authorization
        }

        fun fromEntity(entity: ResponseEntity<*>): Authorization {
            val body = JSONObject(entity.body.toString())
            return fromJson(body.getJSONObject("authorization"))
        }

        fun fromAuthorizationCode(authorizationCode: AuthorizationCode, client : Clients): Authorization {
          return  Authorization(responseType = ResponseTypes.Code, code = authorizationCode.code, userId = authorizationCode.userId, scopes = authorizationCode.scopes).setClient(client)
        }

    }

    fun setClient(client : Clients?): Authorization {
        this.client = client
        this.clientId = client?.id
        this.clientSecret = client?.secret
        return this
    }

    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("clientId", clientId)
        json.put("clientSecret", clientSecret)
        if(redirect != null) json.put("redirect", redirect!!.toJson())
        json.put("grant_type", grant_type)
        json.put("code", code)
        json.put("refresh_token", refresh_token)
        json.put("access_token", access_token)
        json.put("responseType", responseType)
        json.put("userId", userId)
        val jsonScopes = scopes.map {
            it.name
        }
        json.put("scopes", JSONArray(jsonScopes))
        json.put("redirectMethod", redirectMethod)
        return json
    }
}

class CodeAuthorization(
    clientId: String? = null,
    redirect: RequestURL? = null,
    code: String? = null,
    responseType: ResponseTypes? = ResponseTypes.AccessToken,
    clientSecret: String? = null,
    grantType: GrantTypes? = GrantTypes.AuthorizationCode,
    userId: String? = null,
    scopes: List<Scopes> = listOf()
) : Authorization(clientId = clientId, redirect = redirect, code = code, grant_type = grantType, responseType = responseType, clientSecret = clientSecret, userId = userId, scopes = scopes){

    companion object {
        fun createFrom(
            authorization: Authorization,
            client: Clients,
            grantType: GrantTypes,
            responseType: ResponseTypes,
            redirect: RequestURL? = null
        ) : CodeAuthorization {

            return CodeAuthorization(code = authorization.code, clientId = client.id, clientSecret = client.secret, grantType = grantType, responseType = responseType, redirect = redirect, scopes = authorization.scopes, userId = authorization.userId)
        }

    }

    constructor(authorization : Authorization, responseType : ResponseTypes? = null) : this(
        authorization.clientId,
        authorization.redirect,
        authorization.code,
        responseType ?: authorization.responseType,
        authorization.clientSecret,
        authorization.grant_type,
        authorization.userId,
        authorization.scopes
    ) {
        this.clientSecret = authorization.clientSecret
        this.grant_type = authorization.grant_type
        this.refresh_token = authorization.refresh_token
        this.access_token = authorization.access_token
        this.userId = authorization.userId
        this.scopes = authorization.scopes
    }

    init {
        if(this.responseType == null) this.responseType = ResponseTypes.AccessToken
    }
}

class RefreshTokenAuthorization(clientId: String? = null, clientSecret: String? = null, redirect: RequestURL? = null, refresh_token: String?) : Authorization(clientId = clientId, clientSecret = clientSecret, redirect = redirect, refresh_token = refresh_token, grant_type = GrantTypes.RefreshToken, responseType = ResponseTypes.AccessToken){
    constructor(authorization : Authorization, responseType : ResponseTypes? = null) : this(authorization.clientId, authorization.clientSecret, authorization.redirect, authorization.refresh_token) {
        this.grant_type = authorization.grant_type
        this.code = authorization.code
        this.access_token = authorization.access_token
        this.responseType = responseType ?: authorization.responseType
        this.userId = authorization.userId
        this.scopes = authorization.scopes
    }

    init {
        if(this.responseType == null) this.responseType = ResponseTypes.AccessToken
    }
}

class ClientAuthorization(redirect : RequestURL? = null) : Authorization(null, null, redirect = redirect, grant_type = GrantTypes.ClientAuthorization, responseType = ResponseTypes.Code){

    constructor(authorization : Authorization, responseType : ResponseTypes? = null) : this(authorization.redirect) {
        this.clientId = authorization.clientId
        this.clientSecret = authorization.clientSecret
        this.grant_type = authorization.grant_type
        this.code = authorization.code
        this.refresh_token = authorization.refresh_token
        this.access_token = authorization.access_token
        this.responseType = responseType ?: authorization.responseType
        this.userId = authorization.userId
        this.scopes = authorization.scopes
    }

    init {
        if(this.responseType == null) this.responseType = ResponseTypes.Code
    }
}

