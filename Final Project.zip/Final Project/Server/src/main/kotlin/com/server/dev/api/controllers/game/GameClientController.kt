package com.server.dev.api.controllers.game

import com.server.dev.api.constants.gameClients
import com.server.dev.api.game.GameClientData
import com.server.dev.api.game.GameClientInformation
import com.server.dev.api.responses.errors.ApiErrors
import com.server.dev.api.services.game.GameService
import com.server.dev.api.structures.ServerResponse
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping

@Controller()
@RequestMapping("/api/game/clients")
class GameClientController(val gameService : GameService) {
    @PostMapping(value = ["/connect"], consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun connect(@RequestBody data: GameClientData?): ResponseEntity<*> {
        var gameClientData : GameClientData = data ?: return ApiErrors.Game.EmptyGameClientData.entity()

        val result = gameService.clientsService.connect(gameClientData)
        if(result as? ServerResponse != null) return result.entity()
        return result as ResponseEntity<*>
    }

    @PostMapping(value = ["/disconnect"], consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun disconnect(@RequestBody gameClientInformation: GameClientInformation?): ResponseEntity<*> {
        var information : GameClientInformation = gameClientInformation ?: return ApiErrors.Game.EmptyGameClientInformation.entity()

        val result = gameService.clientsService.disconnect(information)

        if(result as? ServerResponse != null) return result.entity()
        return result as ResponseEntity<*>
    }

    @PostMapping(value = ["/get"], consumes = [MediaType.APPLICATION_JSON_VALUE])
    fun get() : ResponseEntity<*> {
        val body = gameClients

        return ResponseEntity(body, HttpStatus.OK)
    }
}