package com.server.dev.api.constants

import com.server.dev.api.game.GameClient

val gameClients: MutableList<GameClient> = mutableListOf()
