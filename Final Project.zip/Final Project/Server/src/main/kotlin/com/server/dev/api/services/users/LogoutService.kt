package com.server.dev.api.services.users

import org.springframework.stereotype.Service
import com.server.dev.api.utils.ServerResources
import org.springframework.web.servlet.view.RedirectView
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@Service
class LogoutService(){
    fun logout(request: HttpServletRequest, response: HttpServletResponse): RedirectView {
        return ServerResources.logoutUser(request, response)
    }


}